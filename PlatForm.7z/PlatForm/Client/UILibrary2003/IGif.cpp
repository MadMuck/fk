#include "StdAfx.h"
#include ".\igif.h"

IGif::IGif(void)
{
}

IGif::~IGif(void)
{
}
