#include "StdAfx.h"
#include "UserPower.h"