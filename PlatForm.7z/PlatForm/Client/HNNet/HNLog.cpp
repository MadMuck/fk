﻿#include "HNLog.h"
#include <tchar.h>
#include <stdio.h>
#include <string>
#include <stdarg.h>
#include <Windows.h>

namespace HN {

static const int MAX_LOG_LENGTH = 16*1024;

static void _log(const char *format, va_list args, HNLOG_LEVEL errorLevel)
{
	char buf[MAX_LOG_LENGTH];

	vsnprintf(buf, MAX_LOG_LENGTH-3, format, args);
	strcat(buf, "\n");

	printf("%s", buf);
	OutputDebugStringA(buf);
	fflush(stdout);
}

void HNLog::logDebug(const char* format, ...)
{
	va_list args;
	va_start(args, format);
	_log(format, args, HNLOG_LEVEL::LOG_DEBUG);
	va_end(args);
}

void HNLog::logError(const char* format, ...)
{
	va_list args;
	va_start(args, format);
	_log(format, args, HNLOG_LEVEL::LOG_ERROR);
	va_end(args);
}

void HNLog::logWarning(const char* format, ...)
{
	va_list args;
	va_start(args, format);
	_log(format, args, HNLOG_LEVEL::LOG_WARN);
	va_end(args);
}

void HNLog::logInfo(const char* format, ...)
{
	va_list args;
	va_start(args, format);
	_log(format, args, HNLOG_LEVEL::LOG_INFO);
	va_end(args);
}

}
