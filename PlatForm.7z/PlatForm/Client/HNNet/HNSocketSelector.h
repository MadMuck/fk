﻿#ifndef __HN_HNSocketSelector_H__
#define __HN_HNSocketSelector_H__

#include "HNCommonMarco.h"
#include <unordered_map>
#include <assert.h>
#include "HNSocketMessage.h"
#include <mutex>

namespace HN
{

	template <class KEY, class T>
	class HNSocketSelector
	{
		typedef typename std::unordered_map<KEY, T> SOCKET_OBSERVERS;
		typedef typename std::unordered_map<KEY, T>::iterator ITERATOR;

	public:
		HNSocketSelector()
		{
		}

		~HNSocketSelector()
		{
			clear();
		}

	public:
		void addSelector(KEY key, T selector)
		{
			HN_ASSERT(nullptr != selector, "selector is nullptr");
			_observers.insert(std::make_pair(key, selector));
		}

		void removeSelector(KEY key)
		{
			auto selector = _observers.find(key);
			if (selector != _observers.end())
			{
				_observers.erase(key);
			}
		}

		bool executeSelector(KEY key, HNSocketMessage* socketMessage)
		{
			if (_observers.empty())
			{
				return false;
			}
			auto selector = _observers.find(key);
			if (selector != _observers.end())
			{
				selector->second->doCallSelector(socketMessage);
			//	HN_SAFE_DELETE(selector->second);
			//	_observers.erase(key);
				return true;
			}
			return false;
		}

		ITERATOR begin()
		{
			return _observers.begin();
		}

		ITERATOR end()
		{
			return _observers.end();
		}

		bool empty()
		{
			return _observers.empty();
		}

		void clear() 
		{
			for (auto iter = _observers.begin(); iter != _observers.end(); ++ iter)
			{
				HN_SAFE_DELETE(iter->second);
			}
			_observers.clear();
		}
	private:
		SOCKET_OBSERVERS _observers;
	};
}

#endif	//__HN_HNSocketSelector_H__

