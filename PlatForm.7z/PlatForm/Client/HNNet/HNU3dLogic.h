#pragma once
#include "HNSocketLogic.h"

namespace HN{

class CHNU3dLogic : public HNSocketLogic
{
public:
	CHNU3dLogic(void);
	~CHNU3dLogic(void);
};

}


