﻿#include "HNSocketLogic.h"
#include "HNSocketThread.h"
#include "HNSocketMessageDelegate.h"
#include "HNLog.h"
#include "HNCommonMarco.h"

namespace HN
{
	HNSocketLogic::HNSocketLogic(ISocketMessageDelegate* delegate, const std::string& tag) : _delegate(delegate)
	{
		_socketThread = new HNSocketThread(this);
		_socketThread->setTag(tag);
		_selectorQueue = new HNSocketMessageSelectorHandler();
	}

	HNSocketLogic::~HNSocketLogic(void)
	{
		HN_SAFE_DELETE(_selectorQueue);
		HN_SAFE_DELETE(_socketThread);
	}

	bool HNSocketLogic::init() 
	{
		return true;
	}

	void HNSocketLogic::resetData()
	{
		_selectorQueue->clear();
	}

	bool HNSocketLogic::openWithIp(const CHAR* ip, INT port)
	{
		return _socketThread->openWithIp(ip, port);
	}

	bool HNSocketLogic::openWithHost(const CHAR* host, INT port)
	{
		return _socketThread->openWithHost(host, port);
	}

	bool HNSocketLogic::close()
	{		
		resetData();
		return _socketThread->close();
	}

	bool HNSocketLogic::connected() const
	{ 
		return _socketThread->connected(); 
	}

	INT HNSocketLogic::send(UINT MainID, UINT AssistantID, void* object, INT objectSize)
	{	
		return _socketThread->send(MainID, AssistantID, object, objectSize);
	}

	void HNSocketLogic::addEventSelector(UINT MainID, UINT AssistantID, SEL_SocketMessage selector)
	{
		assert(nullptr != selector);
		if (nullptr != selector)
		{
			CHAR messageKey[16] = {0};
			sprintf(messageKey, SELECTER_KEY_FORMAT, MainID, AssistantID);
			_selectorQueue->addSelector(messageKey, new HNSocketSelectorItem(selector));
		}
	}

	void HNSocketLogic::removeEventSelector(UINT MainID, UINT AssistantID)
	{
		CHAR messageKey[16] = {0};
		sprintf(messageKey, SELECTER_KEY_FORMAT, MainID, AssistantID);
		_selectorQueue->removeSelector(messageKey);
	}

	void HNSocketLogic::heartBeat(UINT MainID, UINT AssistantID, UINT CheckCode)
	{
		int ret = _socketThread->send(MainID, AssistantID, nullptr, 0);
		if (ret >= 0)
		{	
			HNLOG_WARNING("%s >> heartBeat", _socketThread->getTag().c_str());
		}
	}

	void HNSocketLogic::onReadSocketData(HNSocketMessage* socketMessage)
	{
		bool ret = _selectorQueue->executeSelector(socketMessage->getMessageKey(), socketMessage);
		if (!ret)
		{
			_delegate->onSocketMessage(socketMessage);
		}
	}

	void HNSocketLogic::onConnected(bool connect, emSocketStatus status)
	{
		_delegate->onConnected(connect, status);
	}

	void HNSocketLogic::onDisConnect()
	{
		_delegate->onDisConnect();
	}
}
