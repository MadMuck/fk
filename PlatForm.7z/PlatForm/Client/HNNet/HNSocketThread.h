﻿#ifndef __NH_SocketThread_H__
#define __NH_SocketThread_H__

#include <vector>
#include <list>
#include <deque>
#include <mutex>
#include <thread>

#include "HNBaseType.h"
#include "HNCommonMarco.h"

#define TCP_BUFSIZE_READ	16400

namespace HN {
	class ISocketEventDelegate;
	class HNSocketMessage;
	class HNSocket;

	template<typename _Type>
	class HNSocketDataCacheQueueT
	{
	public:
		HNSocketDataCacheQueueT(void) { _datas = new std::vector<_Type>(); }
		~HNSocketDataCacheQueueT(void) { HN_SAFE_DELETE(_datas); }

	public:
		void push(_Type* _value, INT size)
		{
			INT i = 0;
			CHAR* p = _value;
			while (i++ < size)
			{
				_datas->push_back(*p++);
			}
		}

		void pop(INT pos)
		{
			_datas->erase(_datas->begin(), _datas->begin() + pos);
		}

		size_t size()
		{
			return _datas->size();
		}

		_Type* front()
		{		
			return _datas->data();
		}

		void clear()
		{
			_datas->clear();
		}

	private:
		std::vector<_Type>* _datas;
	};

	class HNSocketThread
	{
		typedef std::deque<HNSocketMessage*>	HNSocketMessageQueue;
		typedef HNSocketDataCacheQueueT<CHAR>	HNSocketDataCacheQueue;

	public:
		HNSocketThread(ISocketEventDelegate* delegate);
		virtual ~HNSocketThread(void);

	public:
		HN_PROPERTY_PASS_BY_REF(std::string, Tag, tag)

		/*
		* 打开服务端连接
		*/
		bool openWithIp(const CHAR* ip, INT port);

		/*
		* 打开服务端连接
		*/
		bool openWithHost(const CHAR* host, INT port);

		/*
		* 关闭服务端连接
		*/
		bool close();

		/*
		* 发送服务端数据
		*/
		INT send(UINT MainID, UINT AssistantID, void* data, INT dataSize);
		
		/*
		*
		*/
		bool connected() const { return _connected; } 
		
	private:
		/*
		* 线程执行函数
		*/
		void onSocketThread();
		
		/*
		* 线程执行函数
		*/
		void onSocketConnect();

		void onHandleThread();

		void notifyUI(emSocketStatus status);

		void onRead(const CHAR* buffer, INT recvSize);

	private:
		/*
		* 网络消息通知处理函数 
		*/
		void socketDataDispatch();

		// 初始化socket
		bool initSocket();

		void clear();

	private:
		bool							_threadExit;

		bool							_threadHandleExit;

		std::mutex						_dataMutex;

		HNSocketDataCacheQueue*			_socketDataCacheQueue;

		HNSocket*						_socket;

		bool							_connected;

		HNSocketMessageQueue*			_socketMessageQueue;

		ISocketEventDelegate*			_delegate;

		emSocketStatus					_socketStatus;

		CHAR							_readBuffer[TCP_BUFSIZE_READ];

	private:
		std::thread*					_recvThread;
		std::thread*					_handleThread;
	};

};

#endif	//__NH_HNSocketThread_H__
