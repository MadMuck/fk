﻿#include "HNSocketProtocolData.h"

namespace HN {
	LLONG HNSocketProtocolData::PlatformCheckCode = INVALID_LLONG_VALUE;
	LLONG HNSocketProtocolData::GameCheckCode = INVALID_LLONG_VALUE;
}
