#include "HNUIGameLogic.h"
#include "HNCommonMarco.h"
#include "basemessage.h"
#include "HNLog.h"

namespace HN{

	static HNUIGameLogic* gHNPlatformLogic = nullptr;

	HNUIGameLogic* HNUIGameLogic::getInstance(bool bCreat/* =false */)
	{
		if (nullptr == gHNPlatformLogic && bCreat)
		{
			gHNPlatformLogic = new HNUIGameLogic();
			gHNPlatformLogic->init();
		}
		return gHNPlatformLogic;
	}

	HNUIGameLogic::HNUIGameLogic(void) 
		: m_iHeartBeatFrequency(0)
		, m_iOutTimeCount(0)
		, m_uTimerEventID(0)
		, m_bConnected(false)
		, m_iPort(INVALID_VALUE)
	{
		m_pSocketLogic = new HNSocketLogic(this, "platform");
	}

	HNUIGameLogic::~HNUIGameLogic(void)
	{
		HN_SAFE_DELETE(m_pSocketLogic);
	}

	bool HNUIGameLogic::init() 
	{
		return true;
	}

	bool HNUIGameLogic::BindU3dFun(u3d_gameinfo gameinfo, u3d_disconnect disconnect, u3d_gameframe gameframe, u3d_gamestation gamestation, u3d_gamenotify gamenotify)
	{
		bool brs = false;
		do
		{
			HNLog::logInfo("hnu3d........connecting");
			if (!m_pSocketLogic->openWithIp(PLATFORM_SERVER_ADDRESS, GAME_ROOM_PORT))
			{
				HNLog::logInfo("hnu3d........connect failed");
				break;
			}
			m_U3dGameInfo = gameinfo;
			m_U3dDisconnect = disconnect;
			m_U3dGameFrame = gameframe;
			m_U3dGameStation = gamestation;
			m_U3dGameNotify = gamenotify;
			HNLog::logInfo("hnu3d........reg gameinfo %d", (int)gameinfo);
			HNLog::logInfo("hnu3d........reg disconnect %d", (int)disconnect);
			HNLog::logInfo("hnu3d........reg gameframe %d", (int)gameframe);
			HNLog::logInfo("hnu3d........reg gamestation %d", (int)gamestation);
			HNLog::logInfo("hnu3d........reg gamenotify %d", (int)gamenotify);
			if (!m_U3dGameNotify)
			{
				HNLog::logInfo("hnu3d........u3d_gamenotify null");
			}
			m_pSocketLogic->addEventSelector(ipc_mainid_config, ipc_assid_config_serverinfo, HN_SOCKET_CALLBACK(HNUIGameLogic::onGameInfoMesssage, this));
		//	m_pSocketLogic->addEventSelector(ipc_mainid_socket, ipc_assid_socket_send, HN_SOCKET_CALLBACK(HNUIGameLogic::onU3DSocketMessage, this));
			m_pSocketLogic->addEventSelector(ipc_mainid_kernel, ipc_assid_kernel_heart, HN_SOCKET_CALLBACK(HNUIGameLogic::onU3DHeartBeat, this));
			brs = true;
		}while(0);

		return brs;
	}

	void HNUIGameLogic::onConnected(bool connect, emSocketStatus status)
	{
		if (!connect)
		{
			HNLog::logInfo("hnu3d........connect failed, statues=%d", status);
		}
		else
		{
			HNLog::logInfo("hnu3d........connect success");
		}		
	}

	void HNUIGameLogic::onDisConnect()
	{
		HNLog::logInfo("hnu3d..........disconnect....");
		if (m_U3dDisconnect)
		{
			HNLog::logInfo("hnu3d..........m_U3dDisconnect reg....");
			m_U3dDisconnect();
		}
		else
		{
			HNLog::logInfo("hnu3d..........m_U3dDisconnect not reg....");
		}
	}

	void HNUIGameLogic::onSocketMessage(HNSocketMessage* socketMessage)
	{
		onU3DSocketMessage(socketMessage);
	}

	INT HNUIGameLogic::SendData(UINT MainID, UINT AssistantID, void* object, INT objectSize)
	{
		return m_pSocketLogic->send(MainID, AssistantID, object, objectSize);
	}

	INT HNUIGameLogic::SendSocketData(UINT MainID, UINT AssistantID, void* object, INT objectSize)
	{
		UINT uHeadSize = sizeof(NetMessageHead);

		BYTE *pBuffer = new BYTE[uHeadSize+objectSize];

		NetMessageHead* pHead = (NetMessageHead*)pBuffer;
		pHead->bMainID = MainID;
		pHead->bAssistantID = AssistantID;
		pHead->uMessageSize = uHeadSize+objectSize;
		pHead->bHandleCode = 0;
		pHead->bReserve = 0;

		memcpy(pBuffer+uHeadSize, object, objectSize);

		INT iSendSize = 0;

		iSendSize = SendData(ipc_mainid_socket, ipc_assid_socket_send, pBuffer, pHead->uMessageSize);

		HN_SAFE_DELETE_ARRAY(pBuffer);

		return iSendSize;
	}

	bool HNUIGameLogic::onTransferMessage(U3DData& u3ddata, HNSocketMessage& hndata)
	{
		HNIpcMessageHead head = hndata.getMessageHead();
		u3ddata.messageHead.bMainID = head.uMainID;
		u3ddata.messageHead.bAssistantID = head.uAssID;
		u3ddata.messageHead.uMessageSize = head.uMessageSize;
		u3ddata.messageHead.bHandleCode = 0;
		u3ddata.messageHead.bReserve = 0;

		u3ddata.objectSize = hndata.GetDataSize();

		memcpy(u3ddata.object, hndata.GetData(), u3ddata.objectSize);

		return true;
	}

	bool HNUIGameLogic::onU3DHeartBeat(HNSocketMessage* socketMessage)
	{
		m_iOutTimeCount = 0;
		HNLog::logInfo("hnu3d..........recv heartbeat....");
		return true;
	}
	
	void CALLBACK HNUIGameLogic::TimerProc(HWND hwnd,UINT uMsg,UINT idEvent,DWORD dwTime)
	{
		HNUIGameLogic* pThis = getInstance();
		if (pThis)
		{
			if (pThis->m_iOutTimeCount++ > 5)
			{
				if (pThis->m_U3dDisconnect)
				{
					pThis->m_U3dDisconnect();
				}
				HN_SAFE_DELETE(pThis);

				HNLog::logInfo("hnu3d..........heartbeat out of time ....");
			}
			else
			{
				HNLog::logInfo("hnu3d..........send heartbeat....");
				pThis->SendData(ipc_mainid_kernel, ipc_assid_kernel_heart, nullptr, 0);
			}
		}	
	}

	bool HNUIGameLogic::onGameInfoMesssage(HNSocketMessage* socketMessage)
	{
		bool brs = false;

		HNIpcMessageHead head = socketMessage->getMessageHead();
		U3DData u3ddata = {0};

		onTransferMessage(u3ddata, *socketMessage);
		
		HNLog::logInfo("hnu3d..........getgameinfo, messagesize=%d, objectsize=%d, u3dgameinfosize=%d", head.uMessageSize, socketMessage->GetDataSize(), sizeof(U3DGameInfo));

		brs = m_U3dGameInfo(u3ddata);

		HNLog::logInfo("hnu3d..........u3dgameinfo fun rs=%d", brs?1:0);

		if (brs)
		{
		//	SetTimer(NULL, 1, 3*1000, TimerProc);

			struct MSG_GM_S_ClientInfo
			{
				BYTE	bEnableWatch;						///�����Թ�
			};
			MSG_GM_S_ClientInfo xx = {0};
			int iSize = SendSocketData(net_mainid_game_frame, net_assid_game_info, &xx, sizeof(xx));
			HNLog::logInfo("hnu3d..........get game station, size=%d", iSize);
		}

		return brs;
	}

	bool HNUIGameLogic::onU3DSocketMessage(HNSocketMessage* socketMessage)
	{
		bool brs = true;
		BYTE* pData = socketMessage->GetData();
		NetMessageHead* pHead = (NetMessageHead*)pData;

		UINT uHeadSize = sizeof(NetMessageHead);

		U3DData u3ddata = {0};
		u3ddata.messageHead = *pHead;
		u3ddata.objectSize = pHead->uMessageSize - uHeadSize;
		if (0 < u3ddata.objectSize)
		{
			memcpy(u3ddata.object, pData+uHeadSize, u3ddata.objectSize);
		}
		HNLog::logInfo("hnu3d..........onU3DSocketMessage.......mainid=%d, assid=%d, objectsize=%d", u3ddata.messageHead.bMainID, u3ddata.messageHead.bAssistantID, 
			u3ddata.objectSize);

		switch (pHead->bMainID)
		{
		case net_mainid_game_frame:
			{
				HNLog::logInfo("hnu3d..........framemessage");
				if (1 == pHead->bAssistantID)
				{
					if (m_U3dGameFrame)
					{
						HNLog::logInfo("hnu3d..........framemessage has register, begin to run");
						m_U3dGameFrame(u3ddata);
						HNLog::logInfo("hnu3d..........framemessage run finish");
					}
					else
					{
						HNLog::logInfo("hnu3d..........framemessage no register");
					}
				}
				else if (2 == pHead->bAssistantID)
				{
					if (m_U3dGameStation)
					{
						HNLog::logInfo("hnu3d..........gamestation has register, begin to run");
						m_U3dGameStation(u3ddata);
						HNLog::logInfo("hnu3d..........gamestation run finish");
					}
					else
					{
						HNLog::logInfo("hnu3d..........gamestation no register");
					}
				}
			}break;
		case net_mainid_game_notify:
			{
				if (m_U3dGameNotify)
				{
					m_U3dGameNotify(u3ddata);
				}
			}break;
		default:
			break;
		}
		return true;
	}
}
