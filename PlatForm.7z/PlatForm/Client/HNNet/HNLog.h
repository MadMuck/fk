﻿#ifndef __NH_HNLOG_H__
#define __NH_HNLOG_H__

#define LOG_YES 1
#define LOG_NO  0
#define LOG_NEED LOG_NO

// cocos2d debug
#if !defined(COCOS2D_DEBUG) || COCOS2D_DEBUG == 0
#define HNLOG_DEBUG(...)       do {} while (0)
#define HNLOG_ERROR(...)   do {} while (0)
#define HNLOG_INFO(...)  do {} while (0)
#define HNLOG_WARNING(...)   do {} while (0)

#elif (COCOS2D_DEBUG == 1 && LOG_NEED == LOG_YES)
#define HNLOG_DEBUG(format, ...)	HNLog::logDebug("Text >> " format, ##__VA_ARGS__)
#define HNLOG_ERROR(format,...)		HNLog::logError("Error >> " format, ##__VA_ARGS__)
#define HNLOG_INFO(format,...)		HNLog::logInfo("Information >> " format, ##__VA_ARGS__)
#define HNLOG_WARNING(format,...)	HNLog::logWarning("Warning >> " format, ##__VA_ARGS__)

#elif COCOS2D_DEBUG > 1
#define HNLOG_DEBUG(format, ...)	HNLog::logDebug("Text >> " format, ##__VA_ARGS__)
#define HNLOG_ERROR(format,...)		HNLog::logError("Error >> " format, ##__VA_ARGS__)
#define HNLOG_INFO(format,...)		HNLog::logInfo("Information >> " format, ##__VA_ARGS__)
#define HNLOG_WARNING(format,...)	HNLog::logWarning("Warning >> " format, ##__VA_ARGS__)
#else
#define HNLOG_DEBUG(format, ...)	
#define HNLOG_ERROR(format,...)		
#define HNLOG_INFO(format,...)		
#define HNLOG_WARNING(format,...)	
#endif // COCOS2D_DEBUG

#if (CC_PLATFORM_WIN32 == CC_TARGET_PLATFORM)// && LOG_NEED == LOG_YES)
#define HNLOG(format, ...) CCLOG("%s(%s:%d)  " format, __FILE__, __FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define HNLOG(format, ...)
#endif

namespace HN {

enum HNLOG_LEVEL
{
	LOG_DEBUG = 0,
	LOG_INFO,
	LOG_WARN,
	LOG_ERROR
};

class HNLog
{
public:
	static void logDebug(const char* format, ...);
	static void logError(const char* format, ...);
	static void logInfo(const char* format, ...);
	static void logWarning(const char* format, ...);
};

};

#endif		//__NH_HNLOG_H__
