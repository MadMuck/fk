﻿#include "HNSocketMessage.h"
#include "HNLog.h"
#include "HNMemoryPool.h"
#include "HNCommonMarco.h"

namespace HN {
	//////////////////////////////////////////////////////////////////////////
	HNMemPool gMemPool(sizeof(HNSocketMessage), 32, 1024);

	HNSocketMessage* HNSocketMessage::getMessage()
	{
		return new HNSocketMessage();
	}

	void HNSocketMessage::releaseMessage(HNSocketMessage* message)
	{
		HN_SAFE_DELETE(message);
	}

	HNSocketMessage::HNSocketMessage()
	{
		objectSize = 0;
		::memset(object, 0x0, sizeof(object));
		::memset(&messageHead, 0x0, sizeof(object));
	}

	HNSocketMessage::~HNSocketMessage()
	{

	}

	void *HNSocketMessage::operator new(std::size_t ObjectSize)
	{
		return gMemPool.get();
	}

	void HNSocketMessage::operator delete(void *ptrObject)
	{
		gMemPool.release(ptrObject);
	}

	void HNSocketMessage::setMessage(const HNIpcMessageHead& head, CHAR* data, INT dataSize)
	{
		messageHead = head;
		objectSize = dataSize;
		memcpy(object, data, dataSize);
		CHAR buf[16] = {0};
		sprintf(buf, "%u_%u", messageHead.uMainID, messageHead.uAssID);
		strKey.assign(buf);
	}

	HNIpcMessageHead& HNSocketMessage::getMessageHead()
	{
		return messageHead;
	}

	BYTE* HNSocketMessage::GetData()
	{
		return object;
	}

	UINT HNSocketMessage::GetDataSize()
	{
		return objectSize;
	}

	std::string& HNSocketMessage::getMessageKey() 
	{
		return strKey;
	}
}
