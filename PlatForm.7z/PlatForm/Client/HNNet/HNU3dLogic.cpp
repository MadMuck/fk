#include "HNU3dLogic.h"

namespace HN{

CHNU3dLogic::CHNU3dLogic(void)
{
}


CHNU3dLogic::~CHNU3dLogic(void)
{
}

}
