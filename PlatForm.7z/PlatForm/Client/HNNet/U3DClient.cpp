#include "U3DClient.h"
#include "HNUIGameLogic.h"
#include "basemessage.h"
#include "HNLog.h"

extern "C" AFX_API bool Init(HN::u3d_gameinfo gameinfo, HN::u3d_disconnect disconnect, HN::u3d_gameframe gameframe, HN::u3d_gamestation gamestation, HN::u3d_gamenotify gamenotify)
{
	bool brs = false;
	do
	{
		InitMinDump();
		HN::HNUIGameLogic* pGameLogic = HN::HNUIGameLogic::getInstance(true);
		if (pGameLogic)
		{
			HN::HNLog::logInfo("hnu3d........Init.....pGameLogic address=%d", (int)pGameLogic);
			brs = pGameLogic->BindU3dFun(gameinfo, disconnect, gameframe, gamestation, gamenotify);
		}
	}while(0);

	return brs;
}

extern "C" AFX_API void UnInit()
{
	HN::HNUIGameLogic* pGameLogic = HN::HNUIGameLogic::getInstance();
	if (nullptr != pGameLogic)
	{
		HN::HNLog::logInfo("hnu3d........UnInit.....pGameLogic address=%d", (int)pGameLogic);
		HN_SAFE_DELETE(pGameLogic);
	}
}

extern "C" AFX_API INT SendPlatformData(UINT MainID, UINT AssistantID, void* data, INT dataSize)
{
	INT iSendSize = 0;
	HN::HNUIGameLogic* pGameLogic = HN::HNUIGameLogic::getInstance();
	if (pGameLogic)
	{
		iSendSize = pGameLogic->SendData(MainID, AssistantID, data, dataSize);
	}
	return iSendSize;
}

extern "C" AFX_API INT SendServerData(U3DData u3ddata)
{
	HN::HNLog::logInfo("hnu3d........SendServerData...begin");

	HN::HNLog::logInfo("hnu3d........SendServerData...datasize=%d", u3ddata.objectSize);

	UINT uHeadSize = sizeof(NetMessageHead);

	UINT uBufLen = uHeadSize+u3ddata.objectSize;
	BYTE *pBuffer = new BYTE[uBufLen];

	NetMessageHead* pHead = (NetMessageHead*)pBuffer;
	pHead->bMainID = u3ddata.messageHead.bMainID;
	pHead->bAssistantID = u3ddata.messageHead.bAssistantID;
	pHead->uMessageSize = uBufLen;
	pHead->bHandleCode = 0;
	pHead->bReserve = 0;

	if (0 < u3ddata.objectSize)
	{
		memcpy(pBuffer+uHeadSize, u3ddata.object, u3ddata.objectSize);
	}

	INT iSendSize = 0;
	HN::HNUIGameLogic* pGameLogic = HN::HNUIGameLogic::getInstance();
	if (pGameLogic)
	{
		iSendSize = pGameLogic->SendData(ipc_mainid_socket, ipc_assid_socket_send, pBuffer, pHead->uMessageSize);
	}

	HN::HNLog::logInfo("hnu3d........SendServerData....mainid=%d, assid=%d, messagesize=%d, datasize=%d, sendsize=%d", 
		u3ddata.messageHead.bMainID, u3ddata.messageHead.bAssistantID, pHead->uMessageSize, u3ddata.objectSize, iSendSize);

	HN_SAFE_DELETE_ARRAY(pBuffer);

	HN::HNLog::logInfo("hnu3d........SendServerData...end");

	return iSendSize;
}
