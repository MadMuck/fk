﻿#ifndef __HN_HNSocketProtocolData_H__
#define __HN_HNSocketProtocolData_H__

#include "HNBaseType.h"
#include "room_game_msg.h"
#include "HNCommonMarco.h"
#include "HNLog.h"
#include <Strsafe.h>

namespace HN {

	class HNSocketProtocolData
	{
	public:
		HNSocketProtocolData() : _objectSize(0)
		{
			::memset(_object, 0x0, sizeof(_object));
			::memset(&_messageHead, 0x0, sizeof(HNIpcMessageHead));
		}

		bool createPackage(UINT MainID, UINT AssistantID, void* object = nullptr, INT objectSize = 0)
		{
			UINT messageHeadSize = sizeof(HNIpcMessageHead);
			_objectSize = messageHeadSize + objectSize; 

			assert(_objectSize < CACHE_BUFFER_SIZE);

			bool ret = false;
			do
			{
				if (_objectSize <= CACHE_BUFFER_SIZE)
				{
					_messageHead.uMessageSize = _objectSize;
					_messageHead.uMainID = MainID;
					_messageHead.uAssID = AssistantID;
					::memcpy(_object, &_messageHead, messageHeadSize);
					if (nullptr != object)
					{
						::memcpy(_object + messageHeadSize, object, _objectSize);
					}
					ret = true;
				}
			} while (0);

			return ret;
		}

		CHAR* getPackage()
		{
			return _object;
		}

		INT getPackageSize() const
		{
			return _objectSize;
		}

		void Description() 
		{
# if defined(_DEBUG) || defined(DEBUG)
			CHAR buf[512] = {0};
			sprintf(buf, "HNIpcMessageHead = {uMessageSize = %d bMainID = %d bAssistantID = %d bHandleCode = %d bReserve = %d buffer = %x size = %d}", 
				_messageHead.uMessageSize, 
				_messageHead.bMainID,
				_messageHead.bAssistantID,
				_messageHead.bHandleCode,
				_messageHead.bReserve, 
				_object, 
				_objectSize);
			HNLOG_DEBUG(buf);
#endif	//_DEBUG || DEBUG
		}

	public:
		const static UINT CACHE_BUFFER_SIZE = 1024*10;
		static LLONG PlatformCheckCode;
		static LLONG GameCheckCode;

	private:
		HNIpcMessageHead	_messageHead;
		CHAR			_object[CACHE_BUFFER_SIZE];
		INT				_objectSize;
	};
}

#endif	//__HN_HNSocketProtocolData_H__

