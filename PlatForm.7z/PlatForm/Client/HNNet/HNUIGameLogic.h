#pragma once
#include "HNSocketMessageDelegate.h"
#include "HNSocketLogic.h"

namespace HN{

class HNUIGameLogic : public ISocketMessageDelegate
{
public:
	HNUIGameLogic(void);
	~HNUIGameLogic(void);

public:
	static HNUIGameLogic* getInstance(bool bCreat=false);

public:
	bool init();

	bool BindU3dFun(u3d_gameinfo gameinfo, u3d_disconnect disconnect, u3d_gameframe gameframe, u3d_gamestation gamestation, u3d_gamenotify gamenotify);

public:

	virtual void onConnected(bool connect, emSocketStatus status) override;

	virtual void onDisConnect() override;

	virtual void onSocketMessage(HNSocketMessage* socketMessage) override;

	virtual INT SendData(UINT MainID, UINT AssistantID, void* object, INT objectSize);

	virtual INT SendSocketData(UINT MainID, UINT AssistantID, void* object, INT objectSize);
private:
	static void CALLBACK TimerProc(HWND hwnd,UINT uMsg,UINT idEvent,DWORD dwTime);

	bool onTransferMessage(U3DData& u3ddata, HNSocketMessage& hndata);
	bool onGameInfoMesssage(HNSocketMessage* socketMessage);
	bool onU3DSocketMessage(HNSocketMessage* socketMessage);
	bool onU3DHeartBeat(HNSocketMessage* socketMessage);

private:
	
	HNSocketLogic*	m_pSocketLogic;

	bool			m_bConnected;

	INT				m_iHeartBeatFrequency;

	INT				m_iOutTimeCount;

	UINT			m_uTimerEventID;

	std::string		m_strIPAddress;

	INT				m_iPort;

	u3d_disconnect  m_U3dDisconnect;

	u3d_gameinfo	m_U3dGameInfo;

	u3d_gameframe	m_U3dGameFrame;

	u3d_gamestation	m_U3dGameStation;

	u3d_gamenotify	m_U3dGameNotify;
};

}


