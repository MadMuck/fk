﻿#ifndef __NH_HNSocketMessage_H__
#define __NH_HNSocketMessage_H__

#include "HNBaseType.h"
#include "room_game_msg.h"
#include <functional>
#include <string>
#include <wtypes.h>

namespace HN {

	#define SELECTER_KEY_FORMAT		"%u_%u"

	class HNSocketMessage;

	typedef std::function<bool(HNSocketMessage* socketMessage)> SEL_SocketMessage;

	#define HN_SOCKET_CALLBACK(__selector__,__target__, ...) std::bind(&__selector__,__target__, std::placeholders::_1, ##__VA_ARGS__)

	class SocketMessage
	{
	public:
		HNIpcMessageHead messageHead;
		UINT objectSize;
		BYTE object[4096];
	};

	typedef void (CALLBACK *u3d_disconnect)();
	typedef bool (CALLBACK *u3d_gameinfo)(U3DData data);
	typedef void (CALLBACK *u3d_gameframe)(U3DData data);
	typedef BYTE (CALLBACK *u3d_gamestation)(U3DData data);
	typedef int (CALLBACK *u3d_gamenotify)(U3DData data);

	class HNSocketMessage : public SocketMessage
	{
		public:
			static HNSocketMessage* getMessage();
			static void releaseMessage(HNSocketMessage* message);

		public:
			void setMessage(const HNIpcMessageHead& head, CHAR* data, INT dataSize);

			HNIpcMessageHead& getMessageHead();

			BYTE* GetData();

			UINT  GetDataSize();

		private:
			HNSocketMessage();
			~HNSocketMessage();

 			void *operator new(std::size_t ObjectSize);
 			void operator delete(void *ptrObject);

		public:
			std::string& getMessageKey();
						
		private:
			std::string strKey;
	};

	class HNSocketSelectorItem
	{
	public:
		HNSocketSelectorItem(SEL_SocketMessage selector) : _selector(selector)
		{
		}

	public:
		bool doCallSelector(HNSocketMessage* socketMessage)
		{ 
			return (_selector)(socketMessage);
		}

	private:
		SEL_SocketMessage	_selector;
	};
};

#endif	//__NH_HNSocketMessage_H__
