#pragma once
#include "resource.h"
#include "BirdHttp.h"
#include "Socket32.h"
#include "../DuiLib/Utils/WinImplBase.h"

using namespace DuiLib;

class CUpdateWnd : public WindowImplBase
{
public:
	explicit CUpdateWnd(void);

	virtual LPCTSTR GetWindowClassName() const
	{
		return _T("UpdateWnd");
	}

	virtual CDuiString GetSkinFile()
	{
		return _T("UpdateWnd.xml");
	}

	virtual CDuiString GetSkinFolder()
	{
		return _T("skin\\");
	}

	//virtual LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual void InitWindow();

	virtual LRESULT ResponseDefaultKeyEvent(WPARAM wParam);

	virtual LRESULT HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnClose(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LPCTSTR GetResourceID() const
	{
		return MAKEINTRESOURCE(IDR_ZIPRES1);
	}

	virtual UILIB_RESOURCETYPE GetResourceType() const
	{
		return UILIB_ZIPRESOURCE;
	}

public:
	void ParseRecvData();

protected:
	CTextUI		*m_pTxtStatus;
	CProgressUI  *m_pProgress;

private:
	CBirdHttp	 m_birdhttp;
	CSocket32    m_hSocket; // �ʹ���ͨ�ŵ�socket
	CStringArray m_arrayFile;
	DWORD        m_dwTotalSize;
	CString      m_strFileName;
	CString      m_strLastTime;
};

