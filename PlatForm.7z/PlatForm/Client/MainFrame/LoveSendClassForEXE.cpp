// LoveSendClassForExe.cpp : ʵ���ļ�


#include "StdAfx.h"
#include "LoveSendClassForEXE.h"
#include "MainRoomEx.h"

// CLoveSendClassForEXE

void DebugPrintf(const char *p, ...)
{
	char szFilename[256];
	sprintf( szFilename, "E:\\HN\\DebugInfo\\DevForExe.txt" );
	va_list arg;
	va_start( arg, p );
	FILE *fp = fopen( szFilename, "a" );
	if (NULL == fp)
	{
		return;
	}
	fprintf(fp,"[%s]--", CTime::GetCurrentTime().Format("%Y-%m-%d %H:%M:%S"));
	vfprintf(fp, p, arg );
	fprintf(fp,"\n");
	fclose(fp);
}

IMPLEMENT_DYNAMIC(CLoveSendClassForEXE, CDialog)

CLoveSendClassForEXE::CLoveSendClassForEXE(void)
{
	m_bIsGameStarting = false;
	m_hWndChannel = NULL;
	m_bWatchMode=true;
	m_bWatchOther=false;

    // PengJiLin, 2010-6-29, ��ս��ʱ���Ƿ�
    m_bTimeOut = false;

	m_iSocketID = INVALID_SOCKET;
	m_pService = NULL;
	m_pSocket = NULL;
}

CLoveSendClassForEXE::~CLoveSendClassForEXE(void)
{
}

BEGIN_MESSAGE_MAP(CLoveSendClassForEXE, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_COPYDATA()
	ON_WM_DESTROY()
	ON_WM_TIMER()
END_MESSAGE_MAP()

// ��ʼ�����˳�ǰ��EXE����
int CLoveSendClassForEXE::OnInitDialog()
{
	// ��ʼ������������Ϣ������е��ٽ���
	//InitializeCriticalSection(&m_csForIPCMessage);
	m_lstIPCMessage.clear();
	InitIPC();
	StartGameClient();
	ShowWindow(SW_HIDE);
	return 0;
}
void CLoveSendClassForEXE::OnDestroy()
{
	StopGameClient();
	DestroyIPC();
	// ��ʼ������������Ϣ������е��ٽ���
	//DeleteCriticalSection(&m_csForIPCMessage);
}

//============================================================================\\
// ���������������Ϣ

//���ͺ���
int CLoveSendClassForEXE::SendGameData(void * pData, UINT uBufLen, BYTE bMainID, BYTE bAssistantID, BYTE bHandleCode)
{
	if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO==255) 
		return 0;
	return m_pGameInfo->pISocketSend->SendGameData(pData,uBufLen,bMainID,bAssistantID,bHandleCode);
}
//���ͺ���
int CLoveSendClassForEXE::SendGameData(BYTE bMainID, BYTE bAssistantID, BYTE bHandleCode)
{
	return m_pGameInfo->pISocketSend->SendGameData(bMainID,bAssistantID,bHandleCode);
}
// ���������������Ϣ
//============================================================================//



//----------------------------------------------------------------------------\\
// ��IFrameInterface�ӿڼ̳еĴ��麯��

//��ʼ��
bool CLoveSendClassForEXE::InitFrame(GameInfoStruct * pGameInfo, CWnd * pGameRoom)
{
	m_pGameInfo=pGameInfo;
	TranslateGameInfo();
	m_pGameRoom=pGameRoom;
	m_pGameRoom->SendMessage(IDM_GET_ROOMNAME,0,(LPARAM)&(m_szGameRoomName[0]));
	return true;
}

//��������
bool CLoveSendClassForEXE::AFCCreateFrame()
{
	if (m_lstIPCMessage.size() > 0)
	{
		m_lstIPCMessage.clear();
	}

	if (GetSafeHwnd()==NULL) 
	{
		AfxSetResourceHandle(GetModuleHandle(FACE_DLL_NAME));
		Create(IDD_NULL, m_pGameRoom);
		AfxSetResourceHandle(GetModuleHandle(NULL));
	}
	else
	{
		StartGameClient();
	}

	return false;
}
//�رմ���
bool CLoveSendClassForEXE::AFCCloseFrame()
{
	StopGameClient();

	if ((m_pGameInfo != NULL) && (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS))
	{
		if (m_pGameRoom != NULL)
			((CGameRoomEx*)m_pGameRoom)->SetBkMusic(true);
	}
	//DestroyIPC();
	if (GetSafeHwnd()!=NULL) 
	{
		ShowWindow (SW_HIDE);
		//DestroyWindow();
	}
	//CWnd * winApp=AfxGetApp()->m_pMainWnd;
	//if(winApp && winApp->m_hWnd)
	//	winApp->PostMessage(WM_USER+100,3,0);
	m_bIsGameStarting = false;
	return false;
}
//��ʾ����
void CLoveSendClassForEXE::AFCShowFrame(int nShow)
{
	// ֪ͨ�ͻ���EXE������ʾ
	ShowWindow(SW_HIDE);
	return;
}
//����windows��Ϣ
LRESULT CLoveSendClassForEXE::SendWindowMessage(UINT msg,WPARAM wParam,LPARAM lParam)
{
	//---------�˴�Ӧ��֪ͨ�ͻ���EXE����
	////�����˵��ߺ󣬵��߸���
	if((msg>WM_USER+150) && (msg<WM_USER+155))
	{
		SendPlayerData(this->m_pGameInfo->pMeUserInfo);
		SendGlbData();
		return 0;
	}
	if (msg==WM_BRING_GAMEWND_TO_TOP)
	{
		SendBringToTopData();
	}

	////�ڵ������ʹ���˵���
	//if(msg==WM_USER+152)
	//{
	//	UsePropItem(wParam);
	//	return 0;
	//}
	return SendMessage(msg,wParam,lParam);
}
//ɾ������
void CLoveSendClassForEXE::DeleteFrame()
{
	StopGameClient();
	if (GetSafeHwnd() != NULL)
		OnCancel();
	delete this;
}

//������Ϣ�����Խ����ڲ������ĵ��ã���CGameRoomExͨ���ӿ�ָ����ã�pControlData����ܴ���ָ��
//�����Ȱ�ָ��������ȡ����������EXE���̣���������
UINT CLoveSendClassForEXE::OnControlMessage(UINT uControlCode, void * pControlData, UINT uDataSize)
{
// 	if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS)
// 	{
// 		return OnControlMessageU3D(uControlCode, pControlData, uDataSize);
// 	}

	int nBufferLen = 0;
	BYTE *pBuffer = NULL;
	//��������
	switch (uControlCode)
	{
	case CM_U3D_GAMEBASEINFO:
		{
			OnControlMessageU3D(uControlCode, pControlData, uDataSize);
			break;
		}
	case CM_U3D_APPLICATION_QUIT:
		{
			OnControlMessageU3D(uControlCode, pControlData, uDataSize);
			break;
		}
	case CM_U3D_SENDUSERINFO:
		{
			OnControlMessageU3D(uControlCode, pControlData, uDataSize);
			break;
		}
	case CM_USER_SEND_TIMES_MONEY: // �û��������
		{
			//send to game talking
			// ���ݽṹ��Ҳ��ָ�룬����ֱ�Ӵ�����͵�EXE����
			int nBufferLen = sizeof(UINT) + sizeof(CM_UserState_Send_Times_Money_For_Exe);
			BYTE *pBuffer = new BYTE[nBufferLen];

			memcpy(pBuffer, &uControlCode, sizeof(UINT) );
			CM_UserState_Send_Times_Money_For_Exe *pDes = (CM_UserState_Send_Times_Money_For_Exe *)(pBuffer + sizeof(UINT));
			CM_UserState_Send_Times_Money *pSrc = (CM_UserState_Send_Times_Money*)pControlData;
			pDes->dwUserID = pSrc->dwUserID;

            pDes->dwGetMoney = pSrc->dwGetMoney;
            pDes->dwMoneyOnTimes = pSrc->dwMoneyOnTimes;
            pDes->dwMoneyOnCounts = pSrc->dwMoneyOnCounts;
            pDes->dwTimesNeed = pSrc->dwTimesNeed;
            pDes->dwCountsNeed = pSrc->dwCountsNeed;

			FlushMessage();
			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			SendCopyData.SendData(IPC_MAIN_USER, IPC_SUB_USER_SCORE, (void*)pBuffer, (WORD)nBufferLen);

			delete [] pBuffer;
			pBuffer = NULL;
			break;
		}
	case CM_USER_STATE:		//�û�״̬�ı�
		{
			// ���ݽṹ�ﺬ��ָ�룬�����Ȱ�ָ��������ȡ�������ٴ�����͵�EXE����
			//Ч������
			if (uDataSize!=sizeof(CM_UserState_Change)) return 1;
			CM_UserState_Change * pStateChange=(CM_UserState_Change *)pControlData;
			// ʵ��Ҫ����������һ���ṹ
			int nBufferLen = sizeof(UINT) + sizeof(CM_UserState_Change_ForExe);
			BYTE *pBuffer = new BYTE[nBufferLen];
			CM_UserState_Change_ForExe *p = (CM_UserState_Change_ForExe *)(pBuffer + sizeof(UINT));
			UINT *pControlCode = (UINT*)pBuffer;
			*pControlCode =uControlCode;
			p->bActionCode = pStateChange->bActionCode;
			p->bDeskStation = pStateChange->bDeskStation;

			if (pStateChange->pUserItem != NULL)
			{
				// ��֪ͨEXE��Ϸ����
				memcpy( &p->uisUserItem, pStateChange->pUserItem, sizeof(UserItemStruct) );
			}
			// ������Լ�����Ϣ
			if (p->uisUserItem.GameUserInfo.dwUserID == m_pGameInfo->pMeUserInfo->GameUserInfo.dwUserID)
			{
				// �Լ���������Ϣ������Ҫ����
				// ��GameRoomEx.cpp���յ��û���Ϣʱ���Ѿ���bActionCode�������¸�ֵ����������ΪACT_XXX�ĺ�
				if ((p->bActionCode == ACT_USER_UP)
					||(p->bActionCode == ACT_WATCH_UP)
					||(p->bActionCode == ACT_USER_CUT))
				{
					delete [] pBuffer;
					pBuffer = NULL;
					break;
				}

			}
			/// ����ͻ��˻�û��������ɣ���Ӧ���������Ϣ�ݴ�����
			if (NULL == m_hWndChannel)
			{
				/// �������Ϸû�������������򲻱ش洢
				if (m_bIsGameStarting)
				{
					MessageToSendStruct msg;
					msg.ipcMain = IPC_MAIN_USER;
					msg.ipcSub = IPC_SUB_USER_STATUS;
					msg.pBuffer = pBuffer;
					msg.wSize = nBufferLen;
					m_lstIPCMessage.push_back(msg);
				}
			}
			else /// ��Ϸ�ͻ����Ѿ�������ɣ���ֱ�ӷ�����Ϣ
			{
				FlushMessage();
				CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
				SendCopyData.SendData(IPC_MAIN_USER, IPC_SUB_USER_STATUS, (void*)pBuffer, (WORD)nBufferLen);

				delete [] pBuffer;
				pBuffer = NULL;
			}
			break;			
		}
	case CM_USER_PROP:
		{
			FlushMessage();
			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			SendCopyData.SendData(IPC_USER_PROP_RESULT, 0, (void*)pControlData, (WORD)uDataSize);

		}
		break;
	case CM_USER_TROTTING:
		{
			//��Ϸ����������Ϣ
			FlushMessage();
			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			SendCopyData.SendData(IPC_TROTTING, 0, (void*)pControlData, (WORD)uDataSize);
			
		}
		break;

	case CM_EX_SKIN:
		{
			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			SendCopyData.SendData(IPC_EX_SKIN, 0,pControlData,uDataSize);
		}
		break;
	default:
		break;
	}
	return 0;
}
//�����ȡ��Ϣ
bool CLoveSendClassForEXE::OnSocketReadEvent(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO==255) 
	{
		return true;
	}

	switch (pNetHead->bMainID)
	{
	case MDM_GM_GAME_FRAME:		//�����Ϣ
		{
			OnFrameMessage(pNetHead,pNetData,uDataSize,pClientSocket);
			break;
		}
	case MDM_GM_GAME_NOTIFY:
		{
			SendU3dMessage(pNetHead->bMainID,pNetHead->bAssistantID,pNetData,uDataSize);
		}
		break;
	case MDM_GR_PROP:
		{
			OnPropMessage(pNetHead,pNetData,uDataSize,pClientSocket);
			break;
		}
	case MDM_GR_MONEY:	///< �������е���Ϣ���Ѿ���GameRoomX�������ˣ�ֻ��ת������Ϸ���̣�����Ҫ�ٴδ���
		{
			SendU3dMessage(pNetHead,pNetData,uDataSize,pClientSocket);
			break;
		}
    case MDM_GR_ROOM:   //��ս��ʱ�䵽
        {
            if(ASS_GR_BATTLEROOM_RESULT == pNetHead->bAssistantID)
            {
                m_bTimeOut = true;
                return true;    // ��������Ϣ��һ����ֱ�ӷ���
            }
			SendU3dMessage(pNetHead,pNetData,uDataSize,pClientSocket);
			break;
        }
	case MDM_GR_USER_ACTION:
	case MDM_GR_NETSIGNAL:
	case MDM_GR_POINT:
	case MDM_GR_MESSAGE:
		{
			SendU3dMessage(pNetHead,pNetData,uDataSize,pClientSocket);

			break;
		}
	default:
		break;
	}
	// �����������Ϣ�����涼��ʵʵ���ڵ����ݣ�����Ҫ������\
	ֱ�Ӱ�pNetHead��pNetData�ϲ���ͨ��IPCת������
	int nBufferLen = sizeof(NetMessageHead) + uDataSize;
	BYTE *pBuffer = new BYTE[nBufferLen];

	memcpy( pBuffer, pNetHead, sizeof(NetMessageHead) );
	memcpy( pBuffer + sizeof(NetMessageHead), pNetData, uDataSize );

	//ͨ���ܵ���GameLauncher������Ϣ
	SendIPCMessage( pBuffer, nBufferLen );

	return true;
}
//�����Ϣ������������Ҫ�ı�m_pGameInfo��״̬
bool CLoveSendClassForEXE::OnFrameMessage(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	ASSERT(pNetHead->bMainID==MDM_GM_GAME_FRAME);
	switch (pNetHead->bAssistantID)
	{
	case ASS_GM_GAME_INFO:		//��Ϸ��Ϣ
		{
			//Ч������
			MSG_GM_S_GameInfo * pGameInfo=(MSG_GM_S_GameInfo *)pNetData;

			//��������
			m_bWatchOther=(pGameInfo->bWatchOther==TRUE);
			m_bWaitTime=pGameInfo->bWaitTime;
			m_bWatchMode=(m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState==USER_WATCH_GAME);
			SetStationParameter(pGameInfo->bGameStation);

			MSG_GM_S_GameInfo tGameInfo = {0};
			tGameInfo.bGameStation = pGameInfo->bGameStation;
			tGameInfo.bReserve = pGameInfo->bReserve;
			tGameInfo.bWaitTime = pGameInfo->bWaitTime;
			tGameInfo.bWatchOther = pGameInfo->bWatchOther;
			int len = strlen(pGameInfo->szMessage);
			memcpy(tGameInfo.szMessage,pGameInfo->szMessage,len);
			//memset(&tGameInfo.szMessage+len+1,0,1000-len);
			
			//����Ϣת������ϷEXE
			SendU3dMessage(pNetHead->bMainID,pNetHead->bAssistantID,&tGameInfo,sizeof(tGameInfo));

			return true;
		}
	case ASS_GM_GAME_STATION:
		{			
			if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO != 255)
			{
				//SendDeskUsers(m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO);
			}
			//����Ϣת������ϷEXE
			SendU3dMessage(pNetHead->bMainID,pNetHead->bAssistantID,pNetData,uDataSize);
			return true;
		}
	case ASS_GM_NORMAL_TALK:
		{		
			SendU3dMessage(pNetHead->bMainID, pNetHead->bAssistantID, pNetData, uDataSize);
			return true;
		}
	}
	return false;
}
//������Ϣ
bool CLoveSendClassForEXE::OnPropMessage(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	switch(pNetHead->bAssistantID)
	{
	case ASS_PROP_USEPROP:
		return OnUsePropResult(pNetHead,pNetData,uDataSize,pClientSocket);
	default:
		break;
	}
	return true;
}
//����������Ϣ
bool CLoveSendClassForEXE::OnUsePropResult(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	if(pNetHead->bHandleCode!=DTK_GR_PROP_USE_SUCCEED)
		return true;
	if(sizeof(_TAG_USINGPROP)!= uDataSize)
		return false;
	_TAG_USINGPROP * usingProp = (_TAG_USINGPROP *)pNetData;
	UserItemStruct *pUserInfo =m_pGameInfo->pIFindUser->FindOnLineUser(usingProp->dwTargetUserID);
	UserItemStruct *pUserInfoUsed =m_pGameInfo->pIFindUser->FindOnLineUser(usingProp->dwUserID);
	if(pUserInfo == NULL)
		return true;

	int attribAction=usingProp->nPropActionAttrib;
	int attribValue=usingProp->nPropValueAttrib;

	FlushMessage();
	SendPlayerData(pUserInfo);
	// ������Լ�
	if ((pUserInfoUsed->GameUserInfo.dwUserID==m_pGameInfo->pMeUserInfo->GameUserInfo.dwUserID)
		||(pUserInfo->GameUserInfo.dwUserID==m_pGameInfo->pMeUserInfo->GameUserInfo.dwUserID))
	{
		SendGlbData();
	}
	this->GetParent()->BringWindowToTop();
	return true;
}

//������Ϸ������Ϣ
void CLoveSendClassForEXE::ShowMsgInGame(TCHAR * szMsg, BYTE bNewOrSys, UINT uSize, TCHAR * szFontName,TCHAR *Title)
{
	MsgInGameStruct msg;
	// ��Ϣ��������Ϊ��
	if (NULL == szMsg)
	{
		return;
	}
	_tcscpy(msg.szMsg, szMsg);
	msg.bIsFontValid = false;
	msg.bIsTitleValid = false;
	if (NULL != szFontName)
	{
		msg.bIsFontValid = true;
		_tcscpy(msg.szFontName, szFontName);
	}
	if (NULL != Title)
	{
		msg.bIsTitleValid = true;
		_tcscpy(msg.szTitle, Title);
	}
	msg.bNewOrSys	= bNewOrSys;
	msg.uSize		= uSize;
	FlushMessage();
	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	SendCopyData.SendData(IPC_MAIN_CONCTROL, IPC_SUB_SHOW_MSG_IN_GAME, (void*)&msg, sizeof(msg));
}

//��������Ϣ
void CLoveSendClassForEXE::ShowMsgDudu(TCHAR * szSendName,
									   TCHAR * szTargetName,
									   TCHAR * szCharString,
									   COLORREF crTextColor,
									   bool bShowTime,
									   UINT uSize,
									   TCHAR * szFontName,
									   int iDuduType)
{
	MsgDuduStruct msgDudu;
	msgDudu.bIsFontValid = false;
	_tcscpy(msgDudu.szSendName, szSendName);
	_tcscpy(msgDudu.szTargetName, szTargetName);
	_tcscpy(msgDudu.szCharString, szCharString);
	msgDudu.crTextColor = crTextColor;
	msgDudu.bShowTime = bShowTime;
	msgDudu.uSize = uSize;
	msgDudu.iDuduType = iDuduType;
	if (NULL != szFontName)
	{
		msgDudu.bIsFontValid = true;
		_tcscpy(msgDudu.szFontName, szFontName);
	}
	FlushMessage();
	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	SendCopyData.SendData(IPC_MAIN_CONCTROL, IPC_SUB_SHOW_DUDU, (void*)&msgDudu, sizeof(msgDudu));
	
}

//����������Ϣ
void CLoveSendClassForEXE::SendShortMessage(MSG_GR_RS_NormalTalk *pShortMessage)
{
}


//��ȡ��Ϸ�Ƿ�����
bool CLoveSendClassForEXE::GetGameIsStarting()
{
	return m_bIsGameStarting;
}

//----------------------------------------------------------------------------//


//============================================================================\\
//IPC֧�֡�
//========
// ����IPC
bool CLoveSendClassForEXE::DestroyIPC()
{
	UnmapViewOfFile(m_pShareMemory);
	CloseHandle(m_hShareMemory);
	m_hShareMemory = NULL;
	KillTimer(TIMER_HEART_BEAT);

	if (m_pSocket != NULL) delete m_pSocket;
	m_pSocket = NULL;

	if (m_pService != NULL) delete m_pService;
	m_pService = NULL;

	return true;
}
//��ʼ��IPC
bool CLoveSendClassForEXE::InitIPC()
{
	//���������ڴ�(������Ը��������������Ϸ��ID,������IP,�˿ڵ���Ϊ�ļ���ʶ��)
	DWORD dwTick = GetTickCount();
	sprintf(m_szShareName,"0x%s%d%d%d", IPCFILENAME, dwTick, rand()%100, GetMeUserInfo()->dwUserID);
	m_hShareMemory=(HANDLE)CreateFileMapping((HANDLE)0xFFFFFFFFFFFF,NULL,PAGE_READWRITE,0,sizeof(tagShareMemory),m_szShareName);

	if (m_hShareMemory==NULL) 
	{
		AfxMessageBox("�����ڴ��ļ�ʧ��!");
		if(GetLastError()==ERROR_ALREADY_EXISTS)
			AfxMessageBox("�ڴ��ļ��Ѿ�����!");

		return false;
	}

	m_pShareMemory=(tagShareMemory *)MapViewOfFile(m_hShareMemory,FILE_MAP_ALL_ACCESS,0,0,0);

	//���ù����ڴ�
	memset(m_pShareMemory,0,sizeof(tagShareMemory));
	m_pShareMemory->wDataSize=sizeof(tagShareMemory);
	m_pShareMemory->hWndGamePlaza	=	m_hWnd;
	m_pShareMemory->hWndGameServer	=	m_hWnd;

	if (m_IPCRecvCopyData.SetChannelMessageSink(this)==false) 
		return false;

	TRACE("���������ڴ� [%s]  ��ɡ�",m_szShareName );

	m_pService = new CServerSocketSelect();
	m_pService->SetChannel(this);
	m_pSocket = new CTCPServerSocket(m_pService);

// 	if(m_pSocket && (m_GameInfo.dwRoomRule & GRR_GAME_U3D || m_GameInfo.dwRoomRule & GRR_GAME_COCOS))
// 	{
// 		TCHAR szFilePath[MAX_PATH];
// 		GetCurrentDirectory(MAX_PATH,szFilePath);
// 		CString proPath;
// 		proPath.Format("%s\\%d\\Socket.ini",szFilePath,m_GameInfo.uNameID);
// 		
// 		CFile fsockconfg;
// 		CFileException ex;
// 		if(!fsockconfg.Open(proPath,CFile::modeCreate | CFile::modeReadWrite,&ex))
// 		{
// 			TRACE(_T("file could not be opened %d\n"),ex.m_cause);
// 		}
// 		CString cs;
// 		cs.Format("[Set]\nPort=%d",m_pSocket->GetSocketPort());
// 		fsockconfg.Write(cs,cs.GetLength());	
// 		fsockconfg.Close();
// 	}

	return true;
}

// IPC�ص��ӿ�
bool __cdecl CLoveSendClassForEXE::OnChannelMessage(const IPC_Head * pHead, const void * pIPCBuffer, WORD wDataSize, HWND hWndSend)
{
	m_dwIPCHeartBeatTick = 0;//GetTickCount();
	switch (pHead->wMainCmdID)
	{
	case IPC_MAIN_IPC_KERNEL:		//�ں���Ϣ
		{
			return OnIPCKernel(pHead,pIPCBuffer,wDataSize,hWndSend);
		}
	case IPC_MAIN_SOCKET:			//�����¼�
		{
			return OnIPCSocket(pHead,pIPCBuffer,wDataSize,hWndSend);
		}
	case IPC_MAIN_USER:
		{
			return OnIPCUserInfo(pHead,pIPCBuffer,wDataSize,hWndSend);
		}
	case IPC_MAIN_CONFIG:
		{
			// ����ǰ���е���Ϣ����ʱ����
			FlushMessage();
			// ��Glb()��Ĳ������ݣ����û�������Ϣ����ַ����Ϣ���ͳ�ȥ
			// �յ�EXE�������Ļظ�����֪ͨ��Ϸ�����Ѿ�����
			if (IPC_SUB_SERVER_INFO == pHead->wSubCmdID)
			{
				// ��������Ϸ
				AfxGetApp()->m_pMainWnd->PostMessage(WM_USER+100,2,0);
				m_pGameRoom->PostMessage(WM_GAME_LAUNCHED, 0, 0);
			}

			return true;
		}
	case IPC_MAIN_PROP:
		{
			return OnIPCUseProp(pHead,pIPCBuffer,wDataSize,hWndSend);
		}
	case IPC_PROP_BUY_VIP:
		{
			return OnIPCBuyVIP(pHead,pIPCBuffer,wDataSize,hWndSend);
		}
	case IPC_FRIEND:
		{
			if (pHead->wSubCmdID == IPC_ASS_CHECKFRIEND)
			{
				int _id = *((int*)pIPCBuffer);
				HTREEITEM htiUser= GetMainRoom()->m_pGameListWnd->m_IMList.FindUserITEM(_id+1000);
				int b = GetMainRoom()->m_pGameListWnd->m_IMList.GetParentItem(htiUser) == GetMainRoom()->m_pGameListWnd->m_IMList.htiFamilier;
				CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
				SendCopyData.SendData(IPC_FRIEND, IPC_ASS_CHECKFRIEND, &b, sizeof(int));
			}
			else if (pHead->wSubCmdID == IPC_ASS_ADDFRIEND)
			{
				MSG_IM_C_ADDREQUEST* msg = (MSG_IM_C_ADDREQUEST*)pIPCBuffer;
				GetMainRoom()->SendData(msg, msg->cbSize, MDM_GP_IM,ASS_IMC_ADDREQUEST,0);
			}
			else if (pHead->wSubCmdID == IPC_ASS_GETFRIENDLIST)
			{
				CIMMain *pIMList = &(GetMainRoom()->m_pGameListWnd->m_IMList);
				HTREEITEM htiFriend = pIMList->htiFamilier;
				if (pIMList->ItemHasChildren(htiFriend))
				{
					HTREEITEM hNextItem;
					HTREEITEM hChildItem = pIMList->GetChildItem(htiFriend);

					CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
					SendCopyData.SendData(IPC_FRIEND, IPC_ASS_GETFRIENDLIST);

					while (hChildItem != NULL)
					{
						hNextItem = pIMList->GetNextItem(hChildItem, TVGN_NEXT);

						MSG_IM_C_GETFRIENDLIST friendList;
						friendList.dwUserID = GetMainRoom()->m_pGameListWnd->m_IMList.GetItemData(hChildItem);
						if(friendList.dwUserID<1000)
							continue;
						friendList.dwUserID-=1000;
						CString sname=GetMainRoom()->m_pGameListWnd->m_IMList.GetItemText(hChildItem);
						strcpy(friendList.sNickName, sname);
						SendCopyData.SendData(IPC_FRIEND, IPC_ASS_GETFRIENDLIST, &friendList, sizeof(MSG_IM_C_GETFRIENDLIST));

						hChildItem = hNextItem;
					}
				}
			}
			return true;
		}
	case IPC_EMENY:    // ��������Ϣ 
		{
			if (pHead->wSubCmdID == IPC_ASS_CHECKEMENY)
			{
				int _id = *((int*)pIPCBuffer);
				HTREEITEM htiUser = GetMainRoom()->m_pGameListWnd->m_IMList.FindUserITEM(_id + 1000);
				int b = GetMainRoom()->m_pGameListWnd->m_IMList.GetParentItem(htiUser) == GetMainRoom()->m_pGameListWnd->m_IMList.htiFamilier;
				CIPCSendCopyData SendCopyData(m_hWndChannel, m_hWnd);
				SendCopyData.SendData(IPC_EMENY, IPC_ASS_CHECKEMENY, &b, sizeof(int));
			}
			else if (pHead->wSubCmdID == IPC_ASS_ADDEMENY)
			{
				MSG_IM_C_SETGROUP * pCmd = (MSG_IM_C_SETGROUP *)pIPCBuffer;
				if (pCmd == NULL)
				{
					return true;
				}


				GetMainRoom()->m_pGameListWnd->m_IMList.SetUserGroup(pCmd->dwRemoteUserID, NULL, pCmd->groupID);

				HTREEITEM htiUser = GetMainRoom()->m_pGameListWnd->m_IMList.FindUserITEM(pCmd->dwRemoteUserID + 1000);
				CString strName = GetMainRoom()->m_pGameListWnd->m_IMList.GetItemText(htiUser);

				CString strMsg("");
				CBcfFile fMsg(CBcfFile::GetAppPath()+"ClientMessage.bcf");
				strMsg.Format(fMsg.GetKeyVal("IMDlg","MoveOneToBadList","���[%s]�Ѿ����뵽��ĺ�������"), strName);

				bool bGameOpen = false;
				for(int i = 0; i < MAX_GAME_ROOM; i ++)
				{
					if(GetMainRoom()->m_RoomInfo[i].bAccess)
					{
						// �ر���Ϸ����
						CGameRoomEx* pGameRoomEx = static_cast<CGameRoomEx*>(GetMainRoom()->m_RoomInfo[i].pGameRoomWnd);
						if (NULL != pGameRoomEx)
						{
							if (pGameRoomEx->m_IGameFrame != NULL && pGameRoomEx->m_IGameFrame->GetGameIsStarting())
							{
								bGameOpen = true;
								pGameRoomEx->InsertSystemMessageWithGame(strMsg);
							}
						}
					}
				}
				if (!bGameOpen)
				{
					DUIMessageBox(m_hWnd,MB_ICONINFORMATION|MB_OK,fMsg.GetKeyVal("IMDlg","Tip","��ʾ"),strMsg);
				}
			}
			
			return true;
		}
	default:
		break;
	}

	
	return false;
}

void char2Wchar(char* pchar,wchar_t* wchar)
{
	int nwLen = ::MultiByteToWideChar(CP_ACP,0,pchar,-1,NULL,0);
	MultiByteToWideChar(CP_ACP,0,pchar,-1,wchar,nwLen);
}

//IPC�ں�����
bool CLoveSendClassForEXE::OnIPCKernel(const IPC_Head * pHead, const void * pIPCBuffer, WORD wDataSize, HWND hWndSend)
{
	ASSERT(pHead->wMainCmdID==IPC_MAIN_IPC_KERNEL);
	switch (pHead->wSubCmdID)
	{
	case IPC_SUB_IPC_CLIENT_CONNECT:	//������Ϣ
		{
			m_iSocketID = int(hWndSend);
			TRACE("IPC_SUB_IPC_CLIENT_CONNECT");

			//���ñ���
			m_hWndChannel=hWndSend;			//��ȡ�ͻ���channel���ھ��

			// ����������ʱ��
			SetTimer(TIMER_HEART_BEAT, HEART_BEAT_SECOND*1000, NULL);

			TranslateGameInfo();
			// ����Ϸ���ڳ�ʼ����ص����ݷ��ͳ�ȥ������б�
			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			SendCopyData.SendData(IPC_MAIN_CONFIG, IPC_SUB_SERVER_INFO, &m_GameInfo, sizeof(m_GameInfo));

			if (m_GameInfo.dwRoomRule & GRR_GAME_U3D || m_GameInfo.dwRoomRule & GRR_GAME_COCOS) {
				
				
				if (m_GameInfo.uNameID == 30311800) {
				
					::memset(&m_GameInfoXzkp, 0, sizeof(UserItemStructX));

					//------------------С���������ݷ���---------------------------
					m_GameInfoXzkp.bMatchUser					= m_GameInfo.uisMeUserInfo.bMatchUser;
					m_GameInfoXzkp.dwLogonTime					= m_GameInfo.uisMeUserInfo.dwLogonTime;
					m_GameInfoXzkp.uConnection					= m_GameInfo.uisMeUserInfo.uConnection;
					m_GameInfoXzkp.uSortIndex					= m_GameInfo.uisMeUserInfo.uSortIndex;

					m_GameInfoXzkp.GameUserInfo.bBoy			= m_GameInfo.uisMeUserInfo.GameUserInfo.bBoy;
					m_GameInfoXzkp.GameUserInfo.bDeskNO			= m_GameInfo.uisMeUserInfo.GameUserInfo.bDeskNO;
					m_GameInfoXzkp.GameUserInfo.bDeskStation	= m_GameInfo.uisMeUserInfo.GameUserInfo.bDeskStation;
					m_GameInfoXzkp.GameUserInfo.bLogoID			= m_GameInfo.uisMeUserInfo.GameUserInfo.bLogoID;
					m_GameInfoXzkp.GameUserInfo.bUserState		= m_GameInfo.uisMeUserInfo.GameUserInfo.bUserState;
					m_GameInfoXzkp.GameUserInfo.dwUserID		= m_GameInfo.uisMeUserInfo.GameUserInfo.dwUserID;
					m_GameInfoXzkp.GameUserInfo.dwUserIP		= m_GameInfo.uisMeUserInfo.GameUserInfo.dwUserIP;
					m_GameInfoXzkp.GameUserInfo.i64Bank			= m_GameInfo.uisMeUserInfo.GameUserInfo.i64Bank;
					m_GameInfoXzkp.GameUserInfo.i64ContestScore	= m_GameInfo.uisMeUserInfo.GameUserInfo.i64ContestScore;
					m_GameInfoXzkp.GameUserInfo.i64Money		= m_GameInfo.uisMeUserInfo.GameUserInfo.i64Money;
					m_GameInfoXzkp.GameUserInfo.iContestCount	= m_GameInfo.uisMeUserInfo.GameUserInfo.iContestCount;
					m_GameInfoXzkp.GameUserInfo.isVirtual		= m_GameInfo.uisMeUserInfo.GameUserInfo.isVirtual;
					m_GameInfoXzkp.GameUserInfo.iVipTime		= m_GameInfo.uisMeUserInfo.GameUserInfo.iVipTime;
					char2Wchar(m_GameInfo.uisMeUserInfo.GameUserInfo.nickName, m_GameInfoXzkp.GameUserInfo.nickName); 
					char2Wchar(m_GameInfo.uisMeUserInfo.GameUserInfo.szSignDescr, m_GameInfoXzkp.GameUserInfo.szSignDescr);
					m_GameInfoXzkp.GameUserInfo.uCutCount		= m_GameInfo.uisMeUserInfo.GameUserInfo.uCutCount;
					m_GameInfoXzkp.GameUserInfo.uLostCount		= m_GameInfo.uisMeUserInfo.GameUserInfo.uLostCount;
					m_GameInfoXzkp.GameUserInfo.uMidCount		= m_GameInfo.uisMeUserInfo.GameUserInfo.uMidCount;
					m_GameInfoXzkp.GameUserInfo.uWinCount		= m_GameInfo.uisMeUserInfo.GameUserInfo.uWinCount;
			
				} else {
					
					OutputDebugString("flow CLoveSendClassForEXE::OnIPCKernel IPC_SUB_IPC_CLIENT_CONNECT �����齫");
					u3dSGameBaseInfo gamebaseinfo;
					gamebaseinfo.iDeskPeople		= m_pGameInfo->uDeskPeople;
					gamebaseinfo.iLessExperience	= m_pGameInfo->uLessPoint;
					gamebaseinfo.iPower				= m_pGameInfo->iBasePoint;
					gamebaseinfo.lRoomRule			= m_pGameInfo->dwRoomRule;
					gamebaseinfo.iGameNameID		= m_pGameInfo->uNameID;
					char2Wchar(m_pGameInfo->szGameRoomName, gamebaseinfo.szGameRoomName);
					gamebaseinfo.iContestType		= m_pGameInfo->uComType;
					gamebaseinfo.iDeskNO			= m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO;

				}
			
				int nEncryptType = Glb().m_CenterServerPara.m_nEncryptType;
				SendCopyData.SendData(IPC_MAIN_CONFIG, IPC_SUB_ENCRYPT_TYPE, &nEncryptType, sizeof(int));
				
				SendGlbData();
				FlushMessage();
				m_dwIPCHeartBeatTick = 0;//GetTickCount();

			} else {

				int nEncryptType = Glb().m_CenterServerPara.m_nEncryptType;
				SendCopyData.SendData(IPC_MAIN_CONFIG, IPC_SUB_ENCRYPT_TYPE, &nEncryptType, sizeof(int));


				SendGlbData();
				FlushMessage();
				m_dwIPCHeartBeatTick = 0;//GetTickCount();
			}
			return true;
		}
	case IPC_SUB_IPC_CLIENT_CLOSE:		//��EXE���������Ĺر���Ϣ
		{
			m_iSocketID = INVALID_SOCKET;
			// �ͻ��������Ͽ�
			ExeClientShutDown();
		
			char cKey[10];
			CString sPath=CBcfFile::GetAppPath();/////����·��
			CBcfFile fsr( sPath + "SpecialRule.bcf");
			sprintf(cKey, "%d", m_GameInfo.uNameID);
			int iResult = fsr.GetKeyVal (_T("ForceQuitAsAuto"), cKey, 0);

			if (iResult)
			{
				if (m_pGameInfo->pMeUserInfo!=NULL && m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState == USER_PLAY_GAME)
				{
					//Mod-�����й����⴦��
					m_pGameRoom->PostMessage(IDM_QUIT_ROOM_MSG,0,0);
				}
			}

            //����ǻ�ս������ʱ�䵽�ˣ��رմ�����
            if(true == m_bTimeOut)
            {
                m_pGameRoom->PostMessage(WM_GAME_TIMEOUT, 0, 0);
            }
			if (m_pGameInfo->dwRoomRule& GRR_CONTEST || m_pGameInfo->dwRoomRule& GRR_TIMINGCONTEST)
			{
				m_pGameRoom->PostMessage(IDM_QUIT_ROOM_MSG, 0, 0);
			}

			return true;
		}
	case IPC_SUB_CLOSE_FRAME:	// ƽ̨������EXE�ͻ���ʱ����EXE��Ӧ����Ϣ
		{
			AfxGetApp()->m_pMainWnd->PostMessage(WM_USER+100,3,0);
			break;
		}
	case IPC_SUB_GAMEFRAME_INITED:
		{
			//��Ϸ��ܳ�ʼ����ɺ󣬶Ծ���ϷID������˳���ť��Ϊ����
			UINT uRoomID = *((UINT*)pIPCBuffer);
			CMainRoomEx* pMainRoom = GetMainRoom();
			RoomInfoStruct* pRoomInfo = NULL;

			if(pMainRoom) 
			{
				if(pMainRoom->GetRoomInfoStruct(&pRoomInfo))
				{
					for (BYTE i = 0; i < MAX_GAME_ROOM; i++)
					{
						if (pRoomInfo[i].bAccess && (pRoomInfo[i].pComRoomInfo.uRoomID == uRoomID))
						{
							CGameRoomEx* pGameRoom = (CGameRoomEx*)pRoomInfo[i].pGameRoomWnd;
							pGameRoom->SetEnableExitRoomBtn();
							pGameRoom->SetFastEnterBtn(FALSE);
							return true;
						}
					}
				}
			}

			break;
		}
	}
	return false;
}
//����ָ��
bool CLoveSendClassForEXE::OnIPCSocket(const IPC_Head * pHead, const void * pIPCBuffer, WORD wDataSize, HWND hWndSend)
{
	struct SendGameDataStruct 
	{
		BYTE bMainID;
		BYTE bAssistantID;
		BYTE bHandleCode;
	};
	ASSERT(pHead->wMainCmdID==IPC_MAIN_SOCKET);
	switch (pHead->wSubCmdID)
	{
	case IPC_SUB_SOCKET_SEND:	//������Ϣ
		{
			// ����Ϸͬ�⿪ʼ��Ϸ������ǻ�ս������ʱ�䵽�ˣ��رմ�����
			if(true == m_bTimeOut)
            {
                SendGameDataStruct *pMsg = (SendGameDataStruct *)pIPCBuffer;
                if(ASS_GM_AGREE_GAME == pMsg->bAssistantID)
                {
                    m_pGameRoom->PostMessage(WM_GAME_TIMEOUT, 0, 0);
                }
            }
			
			SendGameDataStruct *pMsg = (SendGameDataStruct *)pIPCBuffer;

			if (pMsg != NULL && pMsg->bAssistantID == ASS_GM_AGREE_GAME && pMsg->bHandleCode == 1)
			{
				UINT uRoomID = m_pGameInfo->uRoomID;
			
				CMainRoomEx* pMainRoom = GetMainRoom();
				RoomInfoStruct* pRoomInfo = NULL;

				if(pMainRoom) 
				{
					if(pMainRoom->GetRoomInfoStruct(&pRoomInfo))
					{
						for (BYTE i = 0; i < MAX_GAME_ROOM; i++)
						{
							if (pRoomInfo[i].bAccess && (pRoomInfo[i].pComRoomInfo.uRoomID == uRoomID))
							{
								CGameRoomEx* pGameRoom = (CGameRoomEx*)pRoomInfo[i].pGameRoomWnd;
								if (pGameRoom != NULL && pGameRoom->IsQueueGameRoom())
								{
									pGameRoom->m_bContinueExit = true;
									return true;
								}
							}
						}
					}
				}
			}
			//Ч�����ݺ�ת����������
			if (sizeof(SendGameDataStruct)==wDataSize)
			{
				m_pGameInfo->pISocketSend->SendGameData(pMsg->bMainID,
					pMsg->bAssistantID,
					pMsg->bHandleCode);
			}
			else
			{
				void *pData = (BYTE*)pIPCBuffer + sizeof(SendGameDataStruct);
				m_pGameInfo->pISocketSend->SendGameData(pData,
					wDataSize-sizeof(SendGameDataStruct),
					pMsg->bMainID,
					pMsg->bAssistantID,
					pMsg->bHandleCode);
			}

			return true;
		}
	case TIMER_HEART_BEAT:
		{
			// ��¼ʱ��
			m_dwIPCHeartBeatTick = 0;
			return true;
		}
	}
	return false;
}

void CLoveSendClassForEXE::SendDeskUsers(int bDeskNo)
{
	CIPCSendCopyData SendUserData(m_hWndChannel,m_hWnd);
	//���º�����Ϸ����Ƥ����ʼ����Ϣ
	SendUserData.SendData(IPC_EX_SKIN, 0, &(::GetMainRoom()->m_PlaceUserInfo), sizeof(MSG_GP_R_LogonResult));
	CPtrArray PlayUser,WatchUser;
	if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS) 
	{
		m_pGameInfo->pIFindUser->FindOnLineUser(bDeskNo,PlayUser,WatchUser);
	}
	else
	{
		m_pGameInfo->pIFindUser->FindOnLineUser(bDeskNo,PlayUser,WatchUser);
	}

	// UserItemStruct�ĳ���ͦ�����ּ��δ�ȥ��ÿ�δ������ṹ
	FlushMessage();
	
	for (INT_PTR i=0;i<PlayUser.GetCount();i++)
	{
		UserItemStruct * pUserItem=(UserItemStruct *)PlayUser.GetAt(i);
		if (pUserItem!=NULL)
		{

			if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS) 
			{
				;
			}
			else 
			{
				SendUserData.SendData(IPC_MAIN_USER, IPC_SUB_REPLY_USER_LIST, (void*)pUserItem, sizeof(UserItemStruct));
			}
		}
	}
	
	// �����ԹۺͲμ���Ϸ����EXE�˸���pUserItem->GameUserInfo.bUserState���ж����Թۻ��ǲ���
	for (INT_PTR i=0;i<WatchUser.GetCount();i++)
	{
		UserItemStruct * pUserItem=(UserItemStruct *)WatchUser.GetAt(i);
		if (pUserItem!=NULL) 
		{
			if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS) 
			{
				;
			} 
			else 
			{

				SendUserData.SendData(IPC_MAIN_USER, IPC_SUB_REPLY_USER_LIST, (void*)pUserItem, sizeof(UserItemStruct));
			}
		}
	}
	m_bIsGameValid = true;
}

//����ָ��
bool CLoveSendClassForEXE::OnIPCUserInfo(const IPC_Head * pHead, const void * pIPCBuffer, WORD wDataSize, HWND hWndSend)
{
	ASSERT(pHead->wMainCmdID==IPC_MAIN_USER);
	switch (pHead->wSubCmdID)
	{
	case IPC_SUB_ASK_USER_LIST:	//�����嵥��Ϣ
		{
			// ���ݴ��������ţ���ȡͬ������嵥
			BYTE bDeskNo = *(BYTE*)pIPCBuffer;
			if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO != 255)
			{
				SendDeskUsers(bDeskNo);
			}
			m_bIsGameValid = true;
			return true;
		}
		//////////////////////////////////////////////////////////////////////////
	case IPC_SUB_GAME_START:	// ����Ϸ�������ĸı���Ϸ״̬����Ϣ
		{
			BYTE bStation = *(BYTE*)pIPCBuffer;
			if (m_hWndChannel!=NULL)
			{
				SetStationParameter(bStation);
			}
			break;
		}
		//////////////////////////////////////////////////////////////////////////
    case IPC_SUB_ACTIVE_TO_ROOM:    //������Ϣ
        {
            //������Ϣ, �ֹ�ȡ������
			BYTE bActive = *(BYTE*)pIPCBuffer;
            GetMainRoom()->SetActiveToMainRoom(bActive);
			return true;
        }
		break;
	case IPC_SUB_SCREEN_SIZE_CHANGE:
		{
			GetMainRoom()->m_TopDuWnd->OnHitMin();
			return true;
		}
		break;
	}
	return false;
}

bool CLoveSendClassForEXE::OnIPCBuyVIP(const IPC_Head * pHead, const void * pIPCBuffer, WORD wDataSize, HWND hWndSend)
{
	ASSERT(pHead->wMainCmdID==IPC_PROP_BUY_VIP);
	switch (pHead->wSubCmdID)
	{
	case IPC_ASS_BUY_VIP:	//������崫�ص���VIP
		{
			BYTE *pBuffer = (BYTE*)pIPCBuffer;
			_TAG_PROP_BUY_VIP *pMsgVIP = (_TAG_PROP_BUY_VIP *)pBuffer;
			GetMainRoom()->SendData(pMsgVIP,sizeof(_TAG_PROP_BUY_VIP),MDM_GP_PROP,ASS_PROP_BUY_VIP,0);
			return true;
		}
	case IPC_ASS_GIVE_VIP:	// ������崫�ص�����VIP
		{

		}
	default:
		break;
	}
	return true;
}
//����ָ��
bool CLoveSendClassForEXE::OnIPCUseProp(const IPC_Head * pHead, const void * pIPCBuffer, WORD wDataSize, HWND hWndSend)
{
	ASSERT(pHead->wMainCmdID==IPC_MAIN_PROP);
	switch (pHead->wSubCmdID)
	{
	case IPC_SUB_BROADCAST_BIG:	//�㲥�����ִ�С����С��pIPCBuffer���ж�
		{
			BYTE *pBuffer = (BYTE*)pIPCBuffer;
			_TAG_BOARDCAST *pBroad = (_TAG_BOARDCAST *)pBuffer;
			int nBroadcastType = *((int*)(pBuffer + sizeof(_TAG_BOARDCAST)));
			// �������ͣ�������Ӧ����
			if (nBroadcastType == BRD_MSG_BIG)
			{
				GetMainRoom()->SendData(pBroad,sizeof(_TAG_BOARDCAST),MDM_GP_PROP,ASS_PROP_BIG_BOARDCASE,0);
			}
			else
			{
				SendGameData(pBroad,sizeof(_TAG_BOARDCAST),MDM_GR_PROP,ASS_PROP_SMALL_BOARDCASE,0);
			}
			return true;
		}
	case IPC_SUB_BUY_PROP:	// �����
		{
			if (wDataSize != sizeof(_TAG_PROP_BUY))
			{
				return false;
			}
			_TAG_PROP_BUY *pPropBuy = (_TAG_PROP_BUY *)pIPCBuffer;
			GetMainRoom()->SendData(pPropBuy, wDataSize, MDM_GP_PROP, ASS_PROP_BUY, 0);
			return true;
		}
    case IPC_SUB_BUY_PROP_NEW:  // PengJiLin, 2010-10-13, �̵���ߵļ�ʱ������
        {
            if (wDataSize != sizeof(_TAG_PROP_BUY))
            {
                return false;
            }

            // 0��ʾ�ڷ��乺��1��ʾ����Ϸ�˹���
            _TAG_PROP_BUY *pPropBuy = (_TAG_PROP_BUY *)pIPCBuffer;
            GetMainRoom()->SendData(pPropBuy, wDataSize, MDM_GP_PROP, ASS_PROP_BUY_NEW, 1);
            return true;
        }
	case IPC_SUB_PRESENT_PROP:	// �͵��߸�����
		{
			if (wDataSize != sizeof(_TAG_PROP_GIVE))
			{
				return false;
			}
			_TAG_PROP_GIVE *pPropGive = (_TAG_PROP_GIVE *)pIPCBuffer;
			GetMainRoom()->SendData(pPropGive, sizeof(_TAG_PROP_GIVE), MDM_GP_PROP, ASS_PROP_GIVE, 0);
			return true;
		}
	}
	return false;
}
// ����IPC��Ϣ
bool CLoveSendClassForEXE::SendIPCMessage(void * pIPCBuffer, WORD wDataSize)
{
	// ����ͻ��˻�û����������Ӧ���������Ϣ�ݴ�����
	if ( !m_bIsGameValid || NULL == m_hWndChannel)
	{
		MessageToSendStruct msg;
		msg.ipcMain = IPC_MAIN_SOCKET;
		msg.ipcSub = IPC_SUB_SOCKET_SEND;
		msg.pBuffer = (BYTE*)pIPCBuffer;
		msg.wSize = wDataSize;
		m_lstIPCMessage.push_back(msg);
		return false;
	}
	else
	{

		if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS) {
		
			FlushMessage();

			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			MessageToSendStruct msg;
			msg.ipcMain = IPC_MAIN_SOCKET;
			msg.ipcSub = IPC_SUB_SOCKET_SEND;
			msg.pBuffer = (BYTE*)pIPCBuffer;
			msg.wSize = wDataSize;
			NetMessageHead *p = (NetMessageHead *)(pIPCBuffer);
		} 
		else 
		{

			FlushMessage();
			CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
			SendCopyData.SendData(IPC_MAIN_SOCKET, IPC_SUB_SOCKET_SEND, pIPCBuffer, wDataSize);
			delete [] pIPCBuffer;
			pIPCBuffer = NULL;
		}

		return true;
	}
}
// 
BOOL CLoveSendClassForEXE::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct)
{
	if (m_IPCRecvCopyData.OnCopyData(pWnd->GetSafeHwnd(), pCopyDataStruct)==true) 
		return TRUE;

	return CWnd::OnCopyData(pWnd, pCopyDataStruct);
}

//�˳�����ʱ��Ҫ֪ͨ������������Ѿ������˿ͻ��˳��򣬻���Ҫ��EXE����ص�
void CLoveSendClassForEXE::OnCancel()
{
	/// �ж��Ƿ��������Ϸ
	char cKey[10];
	CString sPath=CBcfFile::GetAppPath();
	CBcfFile fsr( sPath + "SpecialRule.bcf");
	sprintf(cKey, "%d", m_GameInfo.uNameID);
	int iResult = fsr.GetKeyVal (_T("BJLType"), cKey, 0);
	if (iResult != 0)
	{
		m_pGameRoom->PostMessage(WM_COLSE_ROOM_WITH_MSG, 0, 0);
		return;
	}


	if(!(m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS))
	{
		if (m_pGameInfo->dwRoomRule & GRR_QUEUE_GAME)
		{
			if (m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState >= 20 && m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState < 23)
			{
				SendGameData(MDM_GM_GAME_FRAME,ASS_GM_FORCE_QUIT,0);
				m_pGameRoom->PostMessage(WM_COLSE_ROOM_WITH_MSG, 0, 0);
				return;
			}
			else
			{
				if (m_pGameInfo) 
				{
					if (m_pGameInfo->pMeUserInfo) 
					{
						if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO!=255) 
						{
							SendGameData(MDM_GR_USER_ACTION,ASS_GR_USER_UP,0);
						}
					}
				}
				m_pGameRoom->PostMessage(WM_QUEUEROOM_EXIT, 0, 0);
				return;
			}
		}
	}
	
	//��������Ϸ�˳�����Ҫ����޸���԰�������Ϸ�˳�������������
	// ������Ϣ, �ֹ�����
	//��ѯ״̬
	if ((!m_bWatchMode)&&GetStationParameter() >= 20 && GetStationParameter() < 23)//!CanLeftDesk())
	{
		SendGameData(MDM_GM_GAME_FRAME,ASS_GM_FORCE_QUIT,0);
	}

	if (m_pGameInfo) {
		if (m_pGameInfo->pMeUserInfo) {
			if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO!=255) 
			{
				SendGameData(MDM_GR_USER_ACTION,ASS_GR_USER_UP,0);
			}
		}
	}

	return;
}

/// ֹͣEXE����
int CLoveSendClassForEXE::StopGameClient()
{
	if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS)
	{
		if (m_pSocket != NULL)
		{
			SendU3dMessage(ipc_action_cut,ipc_assid_closegame,NULL,0);
			m_pSocket->CloseSocket();
		}
	}
	if (NULL ==m_hWndChannel)
		return -1;

	m_bIsGameValid = false;
	//�رտͻ��˳���ͨ��������Ϣ
	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	SendCopyData.SendData(IPC_MAIN_CONCTROL,IPC_SUB_CLOSE_FRAME);
	
	// ���ԭ���
	m_hWndChannel = NULL;

	return 0;
}

// ����EXE����
int CLoveSendClassForEXE::StartGameClient()
{
	ASSERT(m_pShareMemory!=NULL);		//�ж��Ƿ��Ѿ�����
	if( NULL != m_hWndChannel )
	{
		return -1;
	}
	
	if (m_bIsGameStarting)	/// ��Ϸ������������������
	{
		return -1;
	}
	m_bIsGameStarting = true;
	TranslateGameInfo();
	
	//����������
	CString strCommonLine;
	if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D )
	{
		m_hWnd = NULL;
		strCommonLine.Format(TEXT("u3d\\launcher.exe  %d  %d  %s"),m_pSocket->GetSocketPort(), m_pGameInfo->uNameID,Glb().m_CenterServerPara.m_strDownLoadUpdatepADDR);
	}
	else if(m_pGameInfo->dwRoomRule & GRR_GAME_COCOS)
	{
		m_hWnd = NULL;
		strCommonLine.Format(TEXT("%d\\%d.exe  %d"),m_pGameInfo->uNameID,m_pGameInfo->uNameID,m_pSocket->GetSocketPort());
	}
	else
	{
		strCommonLine.Format(TEXT("%d/%s /RoomToken:%s"),
			//m_pGameInfo->szProcessName,
			m_pGameInfo->uNameID,
			"��Ϸ������.exe",
			m_szShareName);	// ����Ϸ��Ϣ����EXE�����������
	}
	
	//������Ϸ�ͻ���
	STARTUPINFO StartInfo;
	memset(&StartInfo,0,sizeof(StartInfo));
	StartInfo.cb=sizeof(StartInfo);
	StartInfo.wShowWindow=SW_SHOWMAXIMIZED;
	BOOL bSuccess=CreateProcess(NULL,strCommonLine.GetBuffer(),NULL,NULL,FALSE,CREATE_DEFAULT_ERROR_MODE,NULL,NULL,&StartInfo,&m_GameProcessInfo);
	strCommonLine.ReleaseBuffer();
	if (bSuccess==FALSE)
	{
		memset(&m_GameProcessInfo,0,sizeof(m_GameProcessInfo));
		return SM_CREATE_ERROR;
	}
	return 0;
}

void CLoveSendClassForEXE::TranslateGameInfo(void)
{
	m_GameInfo.bDeskOnwer		= m_pGameInfo->bDeskOnwer;
	m_GameInfo.bGameStation		= m_pGameInfo->bGameStation;						//��Ϸ״̬
	if (m_pGameInfo->pMeUserInfo) {
		memcpy(&m_GameInfo.uisMeUserInfo, m_pGameInfo->pMeUserInfo, sizeof(m_GameInfo.uisMeUserInfo));//�����Ϣ
	}
	m_GameInfo.dwGamePower		= m_pGameInfo->dwGamePower;						//�û�Ȩ��
	m_GameInfo.dwMasterPower	= m_pGameInfo->dwMasterPower;					//����Ȩ��
	m_GameInfo.dwRoomRule		= m_pGameInfo->dwRoomRule;						//���ù���
	m_GameInfo.bEnableSound		= m_pGameInfo->bEnableSound;						//��������
	m_GameInfo.bEnableWatch		= m_pGameInfo->bEnableWatch;						//�����Թ�
	m_GameInfo.bShowUserInfo	= m_pGameInfo->bShowUserInfo;					//��ʾ����
	m_GameInfo.bEnableBackSound = m_pGameInfo->bEnableBackSound;					//��������
	m_GameInfo.uDeskPeople		= m_pGameInfo->uDeskPeople;						//��Ϸ����
	m_GameInfo.uRoomID			= m_pGameInfo->uRoomID;							//�����ʾ
	m_GameInfo.dwGameMSVer		= m_pGameInfo->dwGameMSVer;						//���汾��
	m_GameInfo.dwGameLSVer		= m_pGameInfo->dwGameLSVer;						//���汾��
	m_GameInfo.uComType			= m_pGameInfo->uComType;							//��Ϸ����
	m_GameInfo.uNameID			= m_pGameInfo->uNameID;							//���ֱ�ʾ
	m_GameInfo.uLessPoint		= m_pGameInfo->uLessPoint;						//���پ���ֵ
	m_GameInfo.pOrderName		= NULL;											//�ȼ�������EXE�˱�����ã������в���
	m_GameInfo.bIsInRecord = m_pGameInfo->bIsInRecord;
	_tcscpy(m_GameInfo.szProcessName, m_pGameInfo->szProcessName);				//�������֣��硰zjh.exe��
	_tcscpy(m_GameInfo.szGameName, m_pGameInfo->szGameName);						//��Ϸ���֣��硰���𻨡�
	
	//����ר��
	m_GameInfo.iLowCount = m_pGameInfo->iLowCount;
	m_GameInfo.i64Chip = m_pGameInfo->i64Chip;
	m_GameInfo.i64TimeStart = m_pGameInfo->i64TimeStart;
	m_GameInfo.i64TimeEnd =m_pGameInfo->i64TimeEnd;
	m_GameInfo.i64LowChip = m_pGameInfo->i64LowChip;
	m_GameInfo.iBasePoint = m_pGameInfo->iBasePoint;
	strcpy(m_GameInfo.szGameRoomName,m_pGameInfo->szGameRoomName);
}

// ����Ϣ������������ȷ���ȥ
void CLoveSendClassForEXE::FlushMessage(void)
{
	if (!m_bIsGameValid)
	{
		return;
	}
	
	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	if (m_lstIPCMessage.size()==0)
	{
		return;
	}
	try
	{
		std::list<MessageToSendStruct>::iterator it = m_lstIPCMessage.begin();
		while (it!=m_lstIPCMessage.end())
		{
			CM_UserState_Change_ForExe *p = (CM_UserState_Change_ForExe *)(it->pBuffer + sizeof(UINT));
			UINT *pTemp = (UINT*)(it->pBuffer);
			if (pTemp) 
			{
				if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS) 
				{
					MessageToSendStruct msg;
					msg.ipcMain = IPC_MAIN_SOCKET;
					msg.ipcSub = IPC_SUB_SOCKET_SEND;
					msg.pBuffer = (BYTE*)it->pBuffer;
					msg.wSize = it->wSize;
					NetMessageHead *p = (NetMessageHead *)(it->pBuffer);
					delete [] it->pBuffer;
					it->pBuffer = NULL;
				}
				else 
				{

					SendCopyData.SendData(it->ipcMain, it->ipcSub, it->pBuffer, it->wSize);
					NetMessageHead* _p = (NetMessageHead*)(it->pBuffer);
					delete [] it->pBuffer;
					it->pBuffer = NULL;
				}
			}
			m_lstIPCMessage.pop_front();
			it = m_lstIPCMessage.begin();
			int nSize = m_lstIPCMessage.size();
			if (nSize<=0)
			{
				break;
			}
		}
	}
	catch (...)
	{
		DebugPrintf("FlushMessageʱ�쳣", __LINE__);
		return;
	}
}
void CLoveSendClassForEXE::SendGlbData(void)
{
	// �����м���������Ҫ���� \\
	1������\
	2����ҳ\
	3����ַ

	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	// ȡ����������ݣ��Ǹ�ָ�����飬��Ҫ���������ٷ���
	int nPropCount = Glb().userPropLibrary.GetCount();
	if (nPropCount>0)
	{
		// ��Glb()�л�ȡ����ָ�룬��������
		_TAG_USERPROP *userProp=NULL;
		for (int curPropIndex=0; curPropIndex<nPropCount; ++curPropIndex)
		{
			userProp=Glb().userPropLibrary.GetAt(curPropIndex);
			if (userProp)
			{
				SendCopyData.SendData(IPC_MAIN_PROP, IPC_SUB_INIT_PROP, userProp, sizeof(_TAG_USERPROP));
			}
		}
	}
	MsgGlbData gd;
	memset( &gd, 0, sizeof(MsgGlbData));
	gd.m_nEncryType = Glb().m_CenterServerPara.m_nEncryptType;
	_tcscpy(gd.m_NewUrl, Glb().m_NewUrl.GetBuffer());
	_tcscpy(gd.m_szToken, Glb().m_TML_SN.GetBuffer());
	SendCopyData.SendData(IPC_MAIN_PROP, IPC_SUB_INIT_PROP_FINISH, &gd, sizeof(MsgGlbData)); // ��ʾ���ͽ���
	return;
}
void CLoveSendClassForEXE::SendBringToTopData(void)
{
	// ��ͬ��ĳ��������ٴδ��͹�ȥ����Ϊ��ʹ�õ��ߵ�ʱ��������ݻ��б仯
	FlushMessage();
	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	SendCopyData.SendData(IPC_MAIN_CONCTROL, IPC_SUB_JOIN_IN_GAME, 0, 0);
	return;
}
void CLoveSendClassForEXE::SendPlayerData(UserItemStruct *pUserInfo)
{
	// ��ͬ��ĳ��������ٴδ��͹�ȥ����Ϊ��ʹ�õ��ߵ�ʱ��������ݻ��б仯
	FlushMessage();
	CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
	SendCopyData.SendData(IPC_MAIN_USER, IPC_SUB_USER_COME, pUserInfo, sizeof(UserItemStruct));
	return;
}
void CLoveSendClassForEXE::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_HEART_BEAT:
		{
			if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS)
			{
				SendU3dMessage(ipc_mainid_kernel, ipc_assid_kernel_heart, nullptr, 0);
				break;
			}
			if (NULL==m_hWndChannel)
			{
				KillTimer(TIMER_HEART_BEAT);
				return;
			}
			++m_dwIPCHeartBeatTick; 
			DWORD dwThisTick = GetTickCount();
			
			if(m_dwIPCHeartBeatTick>HEART_BEAT_DELAY)
			{
				//��ʾEXE���Ѿ�ֹͣ�ˣ����������ִ���������ģ����ߣ�ģ��EXE�ͻ��������ر�
				//������ģ��EXE�������˷��͹ر���Ϣ
				SendGameData(MDM_GM_GAME_FRAME,ASS_GM_FORCE_QUIT,0);
				ExeClientShutDown();
				this->SetStationParameter(0);

				char cKey[10];
				CString sPath=CBcfFile::GetAppPath();/////����·��
				CBcfFile fsr( sPath + "SpecialRule.bcf");
				sprintf(cKey, "%d", m_GameInfo.uNameID);
				int iResult = fsr.GetKeyVal (_T("ForceQuitAsAuto"), cKey, 0);

				if (iResult)
				{
					if (m_pGameInfo->pMeUserInfo!=NULL && m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState == USER_PLAY_GAME)
					{
						//Mod-�����й����⴦��
						m_pGameRoom->PostMessage(IDM_QUIT_ROOM_MSG,0,0);
					}
				}
			}
			else
			{
				if (m_pGameInfo->dwRoomRule & GRR_GAME_U3D || m_pGameInfo->dwRoomRule & GRR_GAME_COCOS)
				{
					SendU3dMessage(ipc_mainid_kernel, ipc_assid_kernel_heart, nullptr, 0);
				}
				else
				{
					CIPCSendCopyData SendCopyData(m_hWndChannel,m_hWnd);
					SendCopyData.SendData(IPC_MAIN_SOCKET, IPC_SUB_IPC_HEART_BEAT, NULL, 0);

					FlushMessage();
				}				
			}
			break;
		}
	default:
		break;
	}
}

void CLoveSendClassForEXE::ExeClientShutDown()
{
	BZSoundPlay(this, "music/�ر���.mp3", 0);
	// ���ԭ���
	if (NULL != m_hWndChannel)
	{
		m_hWndChannel = NULL;

		// �����Ϣ�����������
		std::list<MessageToSendStruct>::iterator itBegin = m_lstIPCMessage.begin();
		std::list<MessageToSendStruct>::iterator itEnd = m_lstIPCMessage.end();
		std::list<MessageToSendStruct>::iterator it = m_lstIPCMessage.begin();
		for (; it != m_lstIPCMessage.end(); ++it)
		{
			if (it->pBuffer) {
				delete []it->pBuffer;
				it->pBuffer = NULL;
			}
		}
		m_lstIPCMessage.clear();
	}
	m_bIsGameStarting = false;

	// ��������������������Ϣ
	OnCancel();
	AfxGetApp()->m_pMainWnd->PostMessage(WM_USER+100,3,0);
	KillTimer(TIMER_HEART_BEAT);
}

bool __cdecl CLoveSendClassForEXE::OnChannelMessageU3D(const HNIpcMessageHead* pHead, const void* pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	m_dwIPCHeartBeatTick = 0;
	bool brs = false;
	m_iSocketID = int(hWndSend);
	switch (pHead->uMainID)
	{
	case ipc_u3d_mainid_state:
		{
			brs = OnUserStateChange(pHead,pIPCBuffer,uDataSize,hWndSend);
		}
		break;
	case ipc_mainid_kernel:
		{
			brs = OnIPCKernelU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	case ipc_mainid_config:
		{
			brs = OnIPCConfigU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	case ipc_mainid_socket:
		{
			brs = OnIPCSocketU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	case ipc_mainid_user:
		{
			brs = OnIPCUserU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	case net_mainid_game_frame:
		{
			brs = OnIPCGameFrameMessageU3D(pHead,pIPCBuffer,uDataSize,hWndSend);
		}
		break;
	case net_mainid_game_notify:
		{
			brs = OnGameNotifyMessage(pHead,pIPCBuffer,uDataSize,hWndSend);
			break;
		}
	case MDM_GR_USER_ACTION:
	case MDM_GR_MONEY:
	case MDM_GR_MESSAGE:
	case MDM_GR_PROP:
	case MDM_GR_POINT:
		{
			brs = MessageFromU3D_COCOS((NetMessageHead*)pHead,pIPCBuffer,uDataSize);
		}
		break;
	default:	
		break;
	}

	return brs;
}

//IPC�ں�����
bool CLoveSendClassForEXE::OnIPCKernelU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	bool brs = false;
	switch (pHead->uAssID)
	{
	case ipc_assid_kernel_connect:		//������Ϣ
		{
			brs = OnIPCKernelConnectU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	case ipc_assid_kernel_close:		//��EXE���������Ĺر���Ϣ
		{
			//brs = 0;
			brs = OnIPCKernelCloseU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
			brs = true;
		}
	case ipc_assid_kernel_heart:
		{
			brs = OnIPCSocketHeartU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	default:	break;
	}
	return brs;
}

bool CLoveSendClassForEXE::OnIPCKernelConnectU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	//��������SOCKET
	m_iSocketID = int(hWndSend);

	// ����������ʱ��
	SetTimer(TIMER_HEART_BEAT, HEART_BEAT_SECOND*1000, NULL);
	U3DGameInfoEx u3dgameinfo;
	memset(&u3dgameinfo,0,sizeof(u3dgameinfo));
	TranslateU3DGameInfo(u3dgameinfo);
	int reit = SendU3dMessage(ipc_mainid_gameinfo, ipc_assid_gameinfo, &u3dgameinfo, sizeof(u3dgameinfo));
	return true;
}

bool CLoveSendClassForEXE::OnIPCKernelCloseU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	m_iSocketID = INVALID_SOCKET;
	// �ͻ��������Ͽ�
	ExeClientShutDown();

	char cKey[10];
	CString sPath=CBcfFile::GetAppPath();
	CBcfFile fsr( sPath + "SpecialRule.bcf");
	sprintf(cKey, "%d", m_GameInfo.uNameID);
	int iResult = fsr.GetKeyVal (_T("ForceQuitAsAuto"), cKey, 0);

	if (iResult)
	{
		if (m_pGameInfo->pMeUserInfo!=NULL && m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState == USER_PLAY_GAME)
		{
			m_pGameRoom->PostMessage(IDM_QUIT_ROOM_MSG,0,0);
		}
	}

	return true;
}

bool CLoveSendClassForEXE::OnIPCConfigU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	bool brs = false;
	switch (pHead->uAssID)
	{
	case ipc_assid_config_serverinfo:
		{
			brs = OnIPCConfigServerInfoU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	default:	break;
	}

	return brs;
}

bool CLoveSendClassForEXE::OnIPCConfigServerInfoU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	//֪ͨ������Ϸ�������
	m_pGameRoom->PostMessage(WM_GAME_LAUNCHED, 0, 0);

	return true;
}

bool CLoveSendClassForEXE::OnIPCSocketU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	bool brs = false;
	switch (pHead->uAssID)
	{
	case ipc_assid_socket_send:
		{
			brs = OnIPCSocketSendU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;	
	default:	break;
	}

	return brs;
}

bool CLoveSendClassForEXE::OnIPCSocketSendU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	NetMessageHead *pMsg = (NetMessageHead *)pIPCBuffer;
	UINT uHeadSize = sizeof(NetMessageHead);
	if (sizeof(NetMessageHead)==uDataSize)
	{
		m_pGameInfo->pISocketSend->SendGameData(pMsg->bMainID,
			pMsg->bAssistantID,
			pMsg->bHandleCode);
	}
	else
	{
		void *pData = (BYTE*)pIPCBuffer + uHeadSize;
		m_pGameInfo->pISocketSend->SendGameData(pData,
			uDataSize-uHeadSize,
			pMsg->bMainID,
			pMsg->bAssistantID,
			pMsg->bHandleCode);
	}

	return true;
}

bool CLoveSendClassForEXE::OnIPCSocketHeartU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	m_dwIPCHeartBeatTick = 0;

	return true;
}

bool CLoveSendClassForEXE::OnGameNotifyMessage(const HNIpcMessageHead * pHead,const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	((CGameRoomEx*)m_pGameRoom)->SendData((void*)pIPCBuffer,uDataSize,pHead->uMainID,pHead->uAssID,pHead->bHandleCode);
	return true;
}

bool CLoveSendClassForEXE::MessageFromU3D_COCOS(const NetMessageHead * pHead,const void * pBuffer, UINT uDataSize)
{
	if (m_pGameRoom)
	{
		((CGameRoomEx*)m_pGameRoom)->SendData((void*)pBuffer,uDataSize,pHead->bMainID,pHead->bAssistantID,pHead->bHandleCode);
	}
	return true;
}

bool CLoveSendClassForEXE::OnUserStateChange(const HNIpcMessageHead *pHead,const void *pIPCBuffer,UINT uDataSize,HWND hWndSend)
{
	assert( pHead->uMainID == ipc_u3d_mainid_state);

	switch(pHead->uAssID)
	{
	case ipc_u3d_assid_state:
		{
			if(uDataSize != sizeof(U3D_GameQuitState))
			{
				break;
			}
			U3D_GameQuitState *pUserState = (U3D_GameQuitState*)pIPCBuffer;
			if(!pUserState)
				break;
			if(pUserState->byUserState<=4)
			{
				SendGameData(MDM_GR_USER_ACTION,ASS_GR_USER_UP,0);
			}
			else
			{
				SendGameData(MDM_GR_USER_ACTION,ASS_GR_USER_CUT,0);
			}
		}
		break;
	default:
		break;
	}
	return true;
}

bool CLoveSendClassForEXE::OnIPCGameFrameMessageU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	bool brs = false;
	switch(pHead->uAssID)
	{
	case net_assid_game_info:
		{
			if(uDataSize != sizeof(U3D_MSG_GM_S_ClientInfo))
			{
				brs = false;
			}
			U3D_MSG_GM_S_ClientInfo *pInfo =(U3D_MSG_GM_S_ClientInfo*)pIPCBuffer;
			if(pInfo)
			{
				m_iSocketID = int(hWndSend);
				((CGameRoomEx*)m_pGameRoom)->OnSendUserSitMsg();	//����������Ϣ
				MSG_GM_S_ClientInfo tClientInfo;					//�������������Ϸ��Ϣ
				tClientInfo.bEnableWatch = pInfo->bCanWatch;
				SendGameData(&tClientInfo,sizeof(MSG_GM_S_ClientInfo),MDM_GM_GAME_FRAME,ASS_GM_GAME_INFO,0);
				brs = true;
			}
		}
		break;
	/*case net_assid_game_station:
	case net_assid_FORCE_QUIT:
	case net_assid_NORMAL_TALK:
	case net_assid_HIGH_TALK:
	case net_assid_WATCH_SET:
	case net_assid_CLEAN_USER:
	case net_assid_USE_KICK_PROP:
	case net_assid_USE_ANTI_KICK_PROP:
	case net_assid_SET_VIDEOADDR:*/
	{
		((CGameRoomEx*)m_pGameRoom)->SendData((void*)pIPCBuffer, uDataSize, pHead->uMainID, pHead->uAssID, pHead->bHandleCode);
		return true;
	}
	}
	return brs;
}

bool CLoveSendClassForEXE::OnIPCUserU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	bool brs = false;
	switch (pHead->uAssID)
	{
	case ipc_assid_user_list:
		{
			brs = OnIPCUserListU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	case ipc_assid_user_status:
		{
			brs = OnIPCUserStatusU3D(pHead, pIPCBuffer, uDataSize, hWndSend);
		}break;
	default:	break;
	}
	return brs;
}

bool CLoveSendClassForEXE::OnIPCUserListU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	BYTE bDeskNo = *(BYTE*)pIPCBuffer;
	if (m_pGameInfo->pMeUserInfo->GameUserInfo.bDeskNO != 255)
	{
		CPtrArray PlayUser,WatchUser;
		m_pGameInfo->pIFindUser->FindOnLineUser(bDeskNo,PlayUser,WatchUser);

		for (INT_PTR i=0;i<PlayUser.GetCount();i++)
		{
			UserItemStruct * pUserItem=(UserItemStruct *)PlayUser.GetAt(i);
			if (pUserItem!=NULL)
			{
				SendU3dMessage(pHead->uMainID, pHead->uAssID, (void*)pUserItem, sizeof(UserItemStruct));
			}
		}

		for (INT_PTR i=0;i<WatchUser.GetCount();i++)
		{
			UserItemStruct * pUserItem=(UserItemStruct *)WatchUser.GetAt(i);
			if (pUserItem!=NULL) 
			{
				SendU3dMessage(pHead->uMainID, pHead->uAssID, (void*)pUserItem, sizeof(UserItemStruct));
			}
		}
	}
	m_bIsGameValid = true;

	return true;
}

bool CLoveSendClassForEXE::OnIPCUserStatusU3D(const HNIpcMessageHead * pHead, const void * pIPCBuffer, UINT uDataSize, HWND hWndSend)
{
	return true;
}

int CLoveSendClassForEXE::SendU3dMessage(UINT bMainID, UINT bAssistantID, void * pData, UINT uSize)
{
	if (m_pSocket != NULL && m_iSocketID != INVALID_SOCKET)
	{
		
		return m_pSocket->SendData(m_iSocketID, pData, uSize, bMainID, bAssistantID);
	}
	return 0;
}

int CLoveSendClassForEXE::SendU3dMessage(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	if (m_pSocket != NULL && m_iSocketID != INVALID_SOCKET)
	{
		return m_pSocket->SendData(m_iSocketID, pNetData, uDataSize, pNetHead->bMainID,pNetHead->bAssistantID,pNetHead->bHandleCode);
	}
	return 0;
}

int CLoveSendClassForEXE::SendU3dSocketMsg(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	UINT uHeadSize = sizeof(NetMessageHead);
	UINT uBufLen = uHeadSize + uDataSize;
	BYTE *pBuffer = new BYTE[uBufLen];

	memcpy( pBuffer, pNetHead, uHeadSize);
	memcpy( pBuffer+uHeadSize, pNetData, uDataSize);
	INT iSendSize = 0;
	iSendSize = SendU3dMessage(ipc_mainid_socket, ipc_assid_socket_send, pBuffer, uBufLen);
	SafeDeleteArray(pBuffer);

	return iSendSize;
}

bool CLoveSendClassForEXE::OnU3DSocketReadEvent(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	switch (pNetHead->bMainID)
	{
	case MDM_GM_GAME_FRAME:
		{
			OnU3dFrameMessage(pNetHead, pNetData, uDataSize, pClientSocket);
		}break;
	case MDM_GR_NETSIGNAL:
		{

		}break;
	default:
		{
			SendU3dSocketMsg(pNetHead, pNetData, uDataSize, pClientSocket);
		}break;
	}
	return true;
}

bool CLoveSendClassForEXE::OnU3dFrameMessage(NetMessageHead * pNetHead, void * pNetData, UINT uDataSize, CTCPClientSocket * pClientSocket)
{
	switch (pNetHead->bAssistantID)
	{
	case ASS_GM_GAME_INFO:
		{
			MSG_GM_S_GameInfo * pGameInfo=(MSG_GM_S_GameInfo *)pNetData;

			m_bWatchOther=(pGameInfo->bWatchOther==TRUE);
			m_bWaitTime=pGameInfo->bWaitTime;
			m_bWatchMode=(m_pGameInfo->pMeUserInfo->GameUserInfo.bUserState==USER_WATCH_GAME);
			SetStationParameter(pGameInfo->bGameStation);

			U3DGameStation gamestation = {0};
			gamestation.bGameStation = pGameInfo->bGameStation;
			pNetHead->uMessageSize = sizeof(NetMessageHead) + sizeof(U3DGameStation);
			SendU3dSocketMsg(pNetHead, &gamestation, sizeof(gamestation), pClientSocket);
		}break;
	case ASS_GM_GAME_STATION:
		{
			SendU3dSocketMsg(pNetHead, pNetData, uDataSize, pClientSocket);
		}break;
	default:	break;
	}

	return true;
}

void CLoveSendClassForEXE::TranslateU3DGameInfo(U3DGameInfoEx& u3dgameinfo)
{
// 	u3dgameinfo.bGameStation = m_pGameInfo->bGameStation;
// 	u3dgameinfo.dwRoomRule = m_pGameInfo->dwRoomRule;
// 	u3dgameinfo.uDeskPeople = m_pGameInfo->uDeskPeople;
// 	u3dgameinfo.uNameID = m_pGameInfo->uNameID;
// 	u3dgameinfo.uRoomID = m_pGameInfo->uRoomID;
// 	memcpy(u3dgameinfo.szGameName, m_pGameInfo->szGameName, sizeof(m_pGameInfo->szGameName));
// 	memcpy(u3dgameinfo.szGameRoomName, m_pGameInfo->szGameRoomName, sizeof(m_pGameInfo->szGameRoomName));
// 	TranslateU3DGameUser(u3dgameinfo.userinfo, m_pGameInfo->pMeUserInfo);
	u3dgameinfo.bDeskOnwer = m_GameInfo.bDeskOnwer;
	u3dgameinfo.bGameStation = m_GameInfo.bGameStation;
	u3dgameinfo.dwGamePower = m_GameInfo.dwGamePower;
	u3dgameinfo.dwMasterPower = m_GameInfo.dwMasterPower;
	u3dgameinfo.dwRoomRule = m_GameInfo.dwRoomRule;
	u3dgameinfo.pOrderName = NULL;
	u3dgameinfo.bEnableSound = m_GameInfo.bEnableSound;
	u3dgameinfo.bEnableWatch = m_GameInfo.bEnableWatch;
	u3dgameinfo.bShowUserInfo = m_GameInfo.bShowUserInfo;
	memcpy(u3dgameinfo.szProcessName,m_GameInfo.szProcessName,sizeof(u3dgameinfo.szProcessName));
	u3dgameinfo.uDeskPeople = m_GameInfo.uDeskPeople;
	u3dgameinfo.uRoomID = m_GameInfo.uRoomID;
	u3dgameinfo.dwGameMSVer = m_GameInfo.dwGameMSVer;
	u3dgameinfo.dwGameLSVer = m_GameInfo.dwGameLSVer;
	u3dgameinfo.uComType = m_GameInfo.uComType;
	u3dgameinfo.uNameID = m_GameInfo.uNameID;
	memcpy(u3dgameinfo.szGameName,m_GameInfo.szGameName,sizeof(u3dgameinfo.szGameName));
	u3dgameinfo.uLessPoint = m_GameInfo.uLessPoint;
	u3dgameinfo.iBasePoint = m_GameInfo.iBasePoint;
	u3dgameinfo.uUserType = 0;
	u3dgameinfo.iLowCount = m_GameInfo.iLowCount;
	u3dgameinfo.i64Chip = m_GameInfo.i64Chip;
	u3dgameinfo.i64LowChip = m_GameInfo.i64LowChip;
	u3dgameinfo.iRankNum = 0;
	memset(u3dgameinfo.ArrAwards,0,sizeof(u3dgameinfo.ArrAwards));
	memcpy(u3dgameinfo.szGameRoomName,m_GameInfo.szGameRoomName,sizeof(u3dgameinfo.szGameRoomName));


	memcpy(&u3dgameinfo.uisMeUserInfo,&m_GameInfo.uisMeUserInfo,sizeof(m_GameInfo.uisMeUserInfo));

}

void CLoveSendClassForEXE::TranslateU3DGameUser(U3DUserInfo& u3duserinfo, UserItemStruct* pUserItem)
{
	u3duserinfo.bDeskNO = pUserItem->GameUserInfo.bDeskNO;
	u3duserinfo.bDeskStation = pUserItem->GameUserInfo.bDeskStation;
	u3duserinfo.bUserState = pUserItem->GameUserInfo.bUserState;
	u3duserinfo.dwUserID = pUserItem->GameUserInfo.dwUserID;
	u3duserinfo.llMoney = pUserItem->GameUserInfo.i64Money;
	u3duserinfo.llBank = pUserItem->GameUserInfo.i64Bank;
	memcpy(u3duserinfo.szNick, pUserItem->GameUserInfo.nickName, sizeof(pUserItem->GameUserInfo.nickName));
}

UINT CLoveSendClassForEXE::OnControlMessageU3D(UINT uControlCode, void * pControlData, UINT uDataSize)
{
	#pragma region comment
	#pragma endregion comment
	switch(uControlCode)
	{
	case CM_USER_STATE:
		{
			SendU3dMessage(ipc_mainid_socket,net_assid_game_station,pControlData,uDataSize);
		}
		break;
	case CM_USER_AGRESS:
		{
			SendU3dMessage(net_mainid_game_notify,net_assid_game_info,pControlData,uDataSize);
		}
		break;
	case CM_U3D_SENDUSERINFO:
		{
			if(uDataSize != sizeof(UserInfoStruct))
				return 1;

			SendU3dMessage(ipc_mainid_user_pc2u3d,ipc_assid_user_status_pc2u3d,pControlData,uDataSize);
		}
		break;
	case CM_U3D_SEND_GAMEINFO:
		{
			if(uDataSize != sizeof(u3dGameInfoEx_ToGame))
				return 1;

			u3dGameInfoEx_ToGame *pGameInfo = (u3dGameInfoEx_ToGame*)pControlData;
			if(!pGameInfo)
				return 1;

			SendU3dMessage(net_mainid_game_frame,net_assid_game_info,pGameInfo,sizeof(u3dGameInfoEx_ToGame));
		}
		break;
	}
	

	return 0;
}

UINT CLoveSendClassForEXE::TransferActionCode(UINT uActionCode)
{
	UINT rsCode = ipc_action_null;
	switch (uActionCode)
	{
	case ACT_USER_SIT:
		{
			rsCode = ipc_action_sit;
		}break;
	case ACT_USER_UP:
		{
			rsCode = ipc_action_stand;
		}break;
	case ACT_USER_CUT:
		{
			rsCode = ipc_action_cut;
		}break;
	case ACT_USER_AGREE:
		{
			rsCode = ipc_action_agree;
		}break;
	case ACT_GAME_BEGIN:
		{
			rsCode = ipc_action_begin;
		}break;
	case ACT_GAME_END:
		{
			rsCode = ipc_action_end;
		}break;
	default:	break;
	}
	return rsCode;
}