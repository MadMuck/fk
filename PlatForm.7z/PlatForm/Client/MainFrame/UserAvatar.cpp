#include "Stdafx.h"
#include "UserAvatar.h"
#include "Resource.h"


CUserAvatar::CUserAvatar() : CDialog(CUserAvatar::IDD)
{
}

CUserAvatar::~CUserAvatar()
{
}

void CUserAvatar::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CUserAvatar, CDialog)
END_MESSAGE_MAP()


// CUserAvatar ��Ϣ��������
