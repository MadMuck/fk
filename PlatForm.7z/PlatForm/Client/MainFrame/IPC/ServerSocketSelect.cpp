#include "StdAfx.h"

#include "room_game_msg.h"
#include ".\serversocketselect.h"
#include "IPCControls.h"


CServerSocketSelect::CServerSocketSelect(void)
{
}

CServerSocketSelect::~CServerSocketSelect(void)
{
}


bool CServerSocketSelect::OnSocketAccept(SOCKET iSocket)
{
	HNIpcMessageHead in = {0};
	in.uMainID = ipc_mainid_kernel;
	in.uAssID = ipc_assid_kernel_connect;
	in.uMessageSize = 0;
	return m_pIChannelMessageSink->OnChannelMessageU3D(&in, NULL, 0, HWND(iSocket));
}
//�����ȡ��Ϣ
bool CServerSocketSelect::OnSocketReadEvent(SOCKET iSocket, void* pNetData, UINT uDataSize)
{
	UINT uHeadSize = sizeof(HNIpcMessageHead);
	HNIpcMessageHead *pNetHead = (HNIpcMessageHead*)pNetData;
	UINT8* pData = NULL;
	pData  = (UINT8*)pNetData + uHeadSize;

	return m_pIChannelMessageSink->OnChannelMessageU3D(pNetHead, pData, pNetHead->uMessageSize-uHeadSize, HWND(iSocket));
}

//����ر���Ϣ
bool CServerSocketSelect::OnSocketCloseEvent(SOCKET iSocket)
{
	HNIpcMessageHead in = {0};	
	in.uMainID = ipc_mainid_kernel;
	in.uAssID = ipc_assid_kernel_close;
	in.uMessageSize = 0;
	m_pIChannelMessageSink->OnChannelMessageU3D(&in, NULL, 0, HWND(iSocket));
	return true;
}
