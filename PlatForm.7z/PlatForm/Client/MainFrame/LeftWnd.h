#pragma once
#include "GameListUI.h"
#include <queue>
#include "FinanceWnd.h"
#include "LogoChangeDlg.h"
#include "UserInfoWnd.h"

#define WM_SHOW_IM WM_USER+1

class CLeftWnd : public WindowImplBase
{
public:
	CLeftWnd(void);
	~CLeftWnd(void);

protected:
	virtual LPCTSTR GetSkinFolder()
	{
		return "";
	}

	virtual LPCTSTR GetSkinFile()
	{
		return "Left/LeftWnd.xml";
	}
	virtual LPCTSTR GetWindowClassName(void) const
	{
		return "LeftWnd";
	}

	void InitWindow();

	void Notify(BzDui::TNotifyUI& msg);

	LRESULT HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

public:

	void HandleKindData(ComKindInfo* pKindInfoPtr, int iCount);

	void HandleNameData(ComNameInfo* pNameInfoPtr, int iCount);

	void HandleRoomData(ComRoomInfo * pRoomInfoPtr, int iCount, UINT uKindID, UINT uNameID);

	//��ȡ��������
	bool GetProcessName(CAFCRoomItem * pGameRoomItem, TCHAR * szProcessName, UINT uBufferSize);
	//��ȡ��Ϸ����
	bool GetGameName(CAFCRoomItem * pGameRoomItem, TCHAR * szGameName, UINT uBufferSize);

	bool HandleNameOnLineData(DL_GP_RoomListPeoCountStruct * pOnLineCountPtr, UINT uCount);

	bool HandleRoomOnLineData(DL_GP_RoomListPeoCountStruct * pOnLineCountPtr, UINT uCount);

	ComRoomInfo* FindContestRoomItem(CAFCRoomItem * pRoomItem, int iRoomID);

	ComNameInfo* FindNameInfo(UINT uNameID, UINT uKindID);
	
	void UpdatePeopleCount();

	void UnInit();

	//����ͷ��
	void SetLogo(UINT bLogoID);
	//�����ʼ�
	void AddMail(TMailItem mail);
	void OnMailClick();
	void OnUserInfo();
	void OnIMList();
	void OnFacExchange();
	void OnLogoClick();
	void OnShowFinance();
	void OnHideFinance();
	void OnBtnCopyClick();

	//�����û���Ϣ
	void  SetUserInfoWnd(MSG_GP_R_LogonResult *logoResult);
	
	CUserInfoWnd* GetUserInfoWnd(){return m_pUserInfoWnd;}

	CFinanceWnd* GetFinanceWnd(){return m_pFinanceWnd;}

	map<UINT, ComKindInfo*> m_mapKindInfo;

	map<UINT, Node*> m_mapNameNode;

	map<UINT, Node*> m_mapRoomNode;

	vector<UINT> m_vecKindID;

	std::queue<TMailItem>				m_Mails;//�ʼ���Ϣ

	CFinanceWnd*					m_pFinanceWnd;		//����״������
	CLogoChangeDlg*					m_pLogoChangeWnd;	//����ͷ��
	CUserInfoWnd*					m_pUserInfoWnd;		//�û����Ϲ�����

protected:
	
	CGameListUI* m_pGameList;

	BzDui::CHorizontalLayoutUI* m_pHorOpt;

	BzDui::CTextUI* m_pTxtOnlineCount;
};
