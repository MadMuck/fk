#include "StdAfx.h"
#include "UserInfoSimplifyWnd.h"
#include "GamePlaceMessage.h"
#include "MainRoomEx.h"
#include "IPC/common.h"

using namespace BzDui;
#define MSG_SET_LOGO	WM_USER+1314

CUserInfoSimplifyWnd::CUserInfoSimplifyWnd(CGameListWnd *pCGameListWnd)
{
	m_pCGameListWnd = pCGameListWnd;
	m_Mails.empty();
	m_pFinanceWnd = NULL;
	m_pLogoChangeWnd = NULL;
	m_pUserInfoWnd = NULL;

	//��ʼ�û����Ͽ�ʡ�ݳ��й�ϵ
	//JianGK 20111107
	CUserInfoWnd::InitAreaMap();
}


CUserInfoSimplifyWnd::~CUserInfoSimplifyWnd(void)
{
	if(m_pLogoChangeWnd != NULL)
	{
		delete m_pLogoChangeWnd;
		m_pLogoChangeWnd = NULL;
	}
	if(m_pFinanceWnd)
	{
		delete m_pFinanceWnd;
		m_pFinanceWnd = NULL;
	}
}

LPCTSTR CUserInfoSimplifyWnd::GetWindowClassName() const 
{ 
	return _T("UIFrame");
};

UINT CUserInfoSimplifyWnd::GetClassStyle() const 
{ 
	return UI_CLASSSTYLE_DIALOG;
};

void CUserInfoSimplifyWnd::OnFinalMessage(HWND hWnd) 
{ 
	m_pm.RemovePreMessageFilter(this);
};

LRESULT CUserInfoSimplifyWnd::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LONG styleValue = ::GetWindowLong(*this, GWL_STYLE);
	styleValue &= ~WS_CAPTION;
	::SetWindowLong(*this, GWL_STYLE, styleValue | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);

	m_pm.Init(m_hWnd);
	m_pm.AddPreMessageFilter(this);
	CDialogBuilder builder;
	CControlUI* pRoot = builder.Create(_T("left\\UserinfoWnd.xml"), (UINT)0, NULL, &m_pm);
	ASSERT(pRoot && "Failed to parse XML");
	m_pm.AttachDialog(pRoot);
	m_pm.AddNotifier(this);

	Init();
	return 0;
}

LRESULT CUserInfoSimplifyWnd::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	return 0;
}

LRESULT CUserInfoSimplifyWnd::OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if( ::IsIconic(*this) ) bHandled = FALSE;
	return (wParam == 0) ? TRUE : FALSE;
}

LRESULT CUserInfoSimplifyWnd::OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CUserInfoSimplifyWnd::OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CUserInfoSimplifyWnd::OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	POINT pt; pt.x = GET_X_LPARAM(lParam); pt.y = GET_Y_LPARAM(lParam);
	::ScreenToClient(*this, &pt);

	RECT rcClient;
	::GetClientRect(*this, &rcClient);

	RECT rcCaption = m_pm.GetCaptionRect();
	if( pt.x >= rcClient.left + rcCaption.left && pt.x < rcClient.right - rcCaption.right \
		&& pt.y >= rcCaption.top && pt.y < rcCaption.bottom ) 
	{
		CControlUI* pControl = static_cast<CControlUI*>(m_pm.FindControl(pt));
		if( pControl && _tcscmp(pControl->GetClass(), _T("ButtonUI")) != 0 )
			return HTCAPTION;
	}

	return HTCLIENT;
}

LRESULT CUserInfoSimplifyWnd::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CUserInfoSimplifyWnd::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{	
	LRESULT lRes = 0;
	BOOL bHandled = TRUE;
	switch(uMsg) 
	{
	case WM_CREATE:
		{
			lRes = OnCreate(uMsg, wParam, lParam, bHandled); 
		}
		break;

	case WM_TIMER:
		{
			lRes = OnTimer(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_DESTROY:       
		{
			lRes = OnDestroy(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCACTIVATE:    
		{
			lRes = OnNcActivate(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCCALCSIZE:    
		{
			lRes = OnNcCalcSize(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCPAINT:       
		{
			lRes = OnNcPaint(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCHITTEST:     
		{
			lRes = OnNcHitTest(uMsg, wParam, lParam, bHandled);
		}
		break;
	case WM_MOUSEMOVE:
		{			
			lRes = OnMouseMove(uMsg, wParam, lParam, bHandled);
		}
		break;
	case MSG_SET_LOGO:
		{
			lRes = OnSetLogo(uMsg, wParam, lParam, bHandled);
		}
		break;
	default:
		{
			bHandled = FALSE;
		}
	}

	if(bHandled)
	{
		return lRes;
	}

	if(32769!=uMsg && m_pm.MessageHandler(uMsg,wParam,lParam,lRes))
	{
		return lRes;
	}

	return CWindowWnd::HandleMessage(uMsg, wParam, lParam);
}

LRESULT CUserInfoSimplifyWnd::OnMouseMove(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = TRUE;
	
	POINT pt; 
	pt.x = GET_X_LPARAM(lParam); 
	pt.y = GET_Y_LPARAM(lParam);

	static bool bshow = false;
	CControlUI *pTemp = m_pm.FindControl(pt);
	if (pTemp && (pTemp->GetName() == _T("money_but")))
	{
		if (!bshow)
		{
			OnShowFinance();
		}
		bshow = true;	
		return TRUE;
	}

	bshow = false;
	OnHideFinance();
	
	bHandled = FALSE;
	return FALSE;
}

LRESULT CUserInfoSimplifyWnd::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if( uMsg == WM_KEYDOWN ) 
	{
		if( wParam == VK_RETURN ) 
		{
			return true;
		}
		else if( wParam == VK_ESCAPE ) 
		{
			return true;
		}
	}
	return false;
}

void CUserInfoSimplifyWnd::Init()
{
	m_pLogoChangeWnd = new CLogoChangeDlg();
	m_pLogoChangeWnd->Create(m_hWnd,NULL,UI_WNDSTYLE_DIALOG,0,0,0,0,0,NULL);
	m_pLogoChangeWnd->CenterWindow();
	m_pLogoChangeWnd->ShowWindow(false);

	m_pBut_mail = static_cast<CButtonUI*>(m_pm.FindControl(_T("but1")));//�ʼ���ť
	m_pBut_info = static_cast<CButtonUI*>(m_pm.FindControl(_T("but2")));//����
	m_pBut_friend = static_cast<CButtonUI*>(m_pm.FindControl(_T("but3")));//����
	m_pBut_fascx = static_cast<CButtonUI*>(m_pm.FindControl(_T("but4")));//����ֵ��ť

	m_pBut_logo = static_cast<CButtonUI*>(m_pm.FindControl(_T("logo_but")));//����ͷ��ť
	
	m_pControl_logo = static_cast<CControlUI*>(m_pm.FindControl(_T("logo_Control")));//����ͷ��ť
	//m_pBut_finance = static_cast<CButtonUI*>(m_pm.FindControl(_T("money_but")));//����״����ť
	m_text_NickName = static_cast<CTextUI*>(m_pm.FindControl(_T("text1")));
	m_text_UserID = static_cast<CTextUI*>(m_pm.FindControl(_T("text2")));

	if (m_pLogoChangeWnd == NULL
		||!IsWindow(m_pLogoChangeWnd->GetHWND())
		|| m_pBut_mail == NULL
		|| m_pBut_info == NULL
		|| m_pBut_friend == NULL
		|| m_pBut_fascx == NULL
		|| m_pBut_logo == NULL
		|| m_pControl_logo == NULL
		//|| m_pBut_finance == NULL
		|| m_text_NickName == NULL
		|| m_text_UserID == NULL)
	{
		DUIMessageBox(m_hWnd,MB_ICONINFORMATION|MB_OK,"ϵͳ��ʾ","�û���Ϣ�򻯴��ڼ���ʧ�ܣ�");
		if(!m_pLogoChangeWnd)
		{
			delete m_pLogoChangeWnd;
			m_pLogoChangeWnd = NULL;
		}
		Close();
		return;
	}
}

void CUserInfoSimplifyWnd::Notify(TNotifyUI& msg)
{
	if (msg.sType == _T("click"))
	{
		if (msg.pSender->GetName() == _T("but1"))
		{
			//::PostMessage(m_pm.GetPaintWindow(), MSG_SET_LOGO,1, 0);
			OnMailClick();
		}
		else if (msg.pSender->GetName() == _T("but2"))
		{
			OnUserInfo();
		}
		else if (msg.pSender->GetName() == _T("but3"))
		{
			OnIMList();
		}
		else if (msg.pSender->GetName() == _T("but4"))
		{
			OnFacExchange();
		}
		else if (msg.pSender->GetName() == _T("logo_but"))
		{
			OnLogoClick();
		}
	
	}	
}



LRESULT CUserInfoSimplifyWnd::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

//����ͷ��
void CUserInfoSimplifyWnd::SetLogo(UINT bLogoID)
{
	TCHAR str[MAX_PATH];
	wsprintf(str, TEXT("..\\..\\log\\UserLogos\\Logo_%d.png"), bLogoID<0?0:bLogoID);
	m_pControl_logo->SetBkImage(str);
}

void CUserInfoSimplifyWnd::AddMail(TMailItem mail)
{
	m_Mails.push(mail);
	if (m_Mails.size() > 0)
	{
		//m_btMail.SetFlicker(true);
		CString s;
		s.Format("%d", m_Mails.size());
		//m_btMail.EnableToShowText(s, true);
		//m_btMail.Invalidate(FALSE);
	}
}

void CUserInfoSimplifyWnd::OnMailClick()
{
	if (m_Mails.size() > 0)
	{
		TMailItem it = m_Mails.front();

		//AFCMessageBox(it.szMsg);
		DUIMessageBox(m_hWnd,MB_ICONINFORMATION|MB_OK,"ϵͳ��ʾ",it.szMsg);

		m_Mails.pop();

		CString s;
		s.Format("%d", m_Mails.size());
		//m_btMail.EnableToShowText(s, true);
		if (m_Mails.size() <= 0)
		{
			//m_btMail.EnableToShowText(s, false);
			//m_btMail.SetFlicker(false);
		}
		//m_btMail.Invalidate(FALSE);
	}
	else
	{
		if (GetMainRoom()->m_TopDuWnd != NULL)
		{
			GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(false);
		}
		DUIOkeyMsgBox(m_hWnd,"����ǰû�ж���Ϣ");
		if (GetMainRoom()->m_TopDuWnd != NULL)
		{
			GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(true);
		}
	}
}

//��ʾ���˲�����Ϣ
void CUserInfoSimplifyWnd::OnShowFinance()
{
	if(NULL != m_pFinanceWnd)
	{
		return;
	}
	
	m_pFinanceWnd = new CFinanceWnd();
	m_pFinanceWnd->Create(m_hWnd,NULL,UI_WNDSTYLE_DIALOG,0,0,0,0,0,NULL);
	if(m_pFinanceWnd && IsWindow(m_pFinanceWnd->GetHWND()))
	{
		m_pFinanceWnd->ShowWindow(SW_SHOW);
		m_pFinanceWnd->setLifeTime();
		POINT pt;
		GetCursorPos(&pt);
		RECT rc2;
		::GetWindowRect(m_hWnd, &rc2);
		int iX = rc2.left + m_pBut_finance->GetPos().left - 10;
		int iY = rc2.top + m_pBut_finance->GetPos().top;
		RECT rc;
		::GetClientRect(m_pFinanceWnd->GetHWND(),&rc);
		::MoveWindow(m_pFinanceWnd->GetHWND(),iX,
			iY - (rc.bottom - rc.top),rc.right - rc.left,rc.bottom - rc.top,true);
	}
	
	GetMainRoom()->SendData(MDM_GP_BANK,ASS_GP_BANK_FINANCE_INFO,0);
}

//���ظ��˲�����Ϣ
void CUserInfoSimplifyWnd::OnHideFinance()
{
	if (NULL != m_pFinanceWnd)
	{
		m_pFinanceWnd->killShowTimer();
		m_pFinanceWnd->ShowWindow(SW_HIDE);
		m_pFinanceWnd->Close();
		m_pFinanceWnd = NULL;
	}
}

// ������   : CGamePlaceDlg::OnUserInfo
// ˵��     : �û���Ϣ�޸Ŀ���ʾ
// ��������     : void 
// ����		: JianGK 2011-10-30
void CUserInfoSimplifyWnd::OnUserInfo()
{
	if (m_pUserInfoWnd)
	{
		return;
	}

	m_pUserInfoWnd = new CUserInfoWnd();
	if(!m_pUserInfoWnd)
	{
		return;
	}
	if (GetMainRoom()->m_TopDuWnd != NULL)
	{
		GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(false);
	}
	m_pUserInfoWnd->SetPlaceUserInfo(m_pCGameListWnd->m_PlaceUserInfo);
	m_pUserInfoWnd->Create(m_hWnd,NULL,UI_WNDSTYLE_DIALOG,0,0,0,0,0,NULL);
	m_pUserInfoWnd->CenterWindow();
	m_pUserInfoWnd->ShowModal();

	delete m_pUserInfoWnd;
	m_pUserInfoWnd = NULL;

	if (GetMainRoom()->m_TopDuWnd != NULL)
	{
		GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(true);
	}
	return;
}

void CUserInfoSimplifyWnd::OnIMList()
{
	m_pCGameListWnd->OnIMList();
}

void CUserInfoSimplifyWnd::OnFacExchange()
{
	GetMainRoom()->ShowCharmPannel();
}

void CUserInfoSimplifyWnd::OnLogoClick()
{
	if (!m_pLogoChangeWnd)
		return;

	m_pLogoChangeWnd->SetIndex(m_pCGameListWnd->m_PlaceUserInfo->bLogoID);
	m_pLogoChangeWnd->CenterWindow();
	m_pLogoChangeWnd->ShowWindow(SW_SHOW);

	POINT pt;
	GetCursorPos(&pt);
	int iX = pt.x - 10;
	int iY = pt.y;
	RECT rc;
	::GetClientRect(m_pLogoChangeWnd->GetHWND(),&rc);
	::MoveWindow(m_pLogoChangeWnd->GetHWND(),iX, iY+4,rc.right - rc.left,rc.bottom - rc.top,true);
}

LRESULT CUserInfoSimplifyWnd::OnSetLogo(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	int iIndex = wParam;
	if (0 > iIndex)
		return 0;	
	if (m_pLogoChangeWnd)
	{
		m_pLogoChangeWnd->ShowWindow(SW_HIDE);
	}
	//�����û�ͷ��
	if (iIndex == m_pCGameListWnd->m_PlaceUserInfo->bLogoID)
	{
		return 0;
	}
	m_pCGameListWnd->m_PlaceUserInfo->bLogoID = iIndex;
	SetUserInfoWnd(m_pCGameListWnd->m_PlaceUserInfo);
	//�������ϴ���������
	GetMainRoom()->SendSetLogoInfo(m_pCGameListWnd->m_PlaceUserInfo->dwUserID, iIndex);

	bHandled = true;
	return 0;
}

//�����û���Ϣ
void  CUserInfoSimplifyWnd::SetUserInfoWnd(MSG_GP_R_LogonResult * logoResult)
{
	if(logoResult == NULL)
		return ;

	TCHAR str[MAX_PATH];
	SetLogo(logoResult->bLogoID);

	wsprintf(str, TEXT("%s"),
		logoResult->nickName);
	m_text_NickName->SetText(str);

	wsprintf(str, TEXT("%ld"),
		logoResult->dwUserID);
	m_text_UserID->SetText(str);

	return ;
}