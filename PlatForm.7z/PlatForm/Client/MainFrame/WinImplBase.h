#ifndef WIN_IMPL_BASE_HPP
#define WIN_IMPL_BASE_HPP

class WindowImplBase : 
	public BzDui::CWindowWnd,
	public BzDui::INotifyUI,
	public BzDui::IMessageFilterUI
{
public:
	WindowImplBase();
	virtual ~WindowImplBase();
	virtual void InitWindow();
	virtual void OnFinalMessage( HWND hWnd );
	virtual void Notify(BzDui::TNotifyUI& msg);

protected:
	virtual LPCTSTR GetSkinFolder() = 0;
	virtual LPCTSTR GetSkinFile() = 0;
	virtual LPCTSTR GetWindowClassName(void) const = 0 ;
	virtual LRESULT ResponseDefaultKeyEvent(WPARAM wParam);

public:

	virtual HWND CreateDuiWindow( HWND hwndParent, LPCTSTR pstrWindowName,DWORD dwStyle =0, DWORD dwExStyle =0 );

	virtual UINT GetClassStyle() const;

	virtual LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	virtual LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

	virtual LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);

	virtual LRESULT HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

protected:

	BzDui::CPaintManagerUI m_PaintManager;
	CSkinMgr               m_skinmgr;
};

#endif // WIN_IMPL_BASE_HPP
