#include "StdAfx.h"
#include "LeftWnd.h"
#include "MainRoomEx.h"
#include  <io.h>

using namespace BzDui;

extern string GetAppPath();

CLeftWnd::CLeftWnd(void)
{
	m_Mails.empty();
	m_pFinanceWnd = NULL;
	m_pLogoChangeWnd = NULL;
	m_pUserInfoWnd = NULL;

	CUserInfoWnd::InitAreaMap();
}


CLeftWnd::~CLeftWnd(void)
{
	UnInit();
	if(m_pLogoChangeWnd != NULL)
	{
		delete m_pLogoChangeWnd;
		m_pLogoChangeWnd = NULL;
	}
	if(m_pFinanceWnd)
	{
		delete m_pFinanceWnd;
		m_pFinanceWnd = NULL;
	}
}

void CLeftWnd::InitWindow()
{
	m_pHorOpt = static_cast<CHorizontalLayoutUI*>(m_PaintManager.FindControl(_T("Hor_Opt")));
	m_pGameList = static_cast<CGameListUI*>(m_PaintManager.FindControl(_T("GameList")));
	m_pTxtOnlineCount =static_cast<CTextUI*>(m_PaintManager.FindControl(_T("Txt_People")));

	m_pLogoChangeWnd = new CLogoChangeDlg();
	m_pLogoChangeWnd->Create(m_hWnd,NULL,UI_WNDSTYLE_DIALOG,0,0,0,0,0,NULL);
	if(IsWindow(m_pLogoChangeWnd->GetHWND()))
	{
		m_pLogoChangeWnd->CenterWindow();
		m_pLogoChangeWnd->ShowWindow(false);
	}
	else
	{
		delete m_pLogoChangeWnd;
		m_pLogoChangeWnd = NULL;
	}
	

	UnInit();
}
#define MS_GET_ROOM						2							//��ȡ����
void CLeftWnd::Notify(TNotifyUI& msg)
{
	if (msg.sType == _T("click"))
	{
		CString strName = msg.pSender->GetName();
		if (strName == _T("Btn_GameName"))
		{
			Node* pNode = (Node*)msg.pSender->GetTag();
			if (pNode && pNode->data().uDataType == GLK_GAME_NAME)
			{
				ComNameInfo* pNameInfo = (ComNameInfo*)pNode->data().GetData();
				if (!pNameInfo)
				{
					return;
				}
				if ((pNode->data().m_uUpdateTime+60) <= time(NULL) && 
					GetMainRoom()->AddMission(MS_GET_ROOM, pNameInfo->uKindID, pNameInfo->uNameID))
				{
					pNode->data().m_uUpdateTime = (LONG)time(NULL);
				}
				if (m_pGameList->CanExpand(pNode))
				{
					m_pGameList->SetChildVisible(pNode, !pNode->data().child_visible_);
				}

				//����ҳ
				static UINT uNameID = 0;
				if(uNameID != pNameInfo->uNameID)
				{
					CString url;
					url.Format("%s/Download/Detail/%d",Glb().m_CenterServerPara.m_strHomeADDR,pNameInfo->uNameID);
					GetMainRoom()->IE(url);
					uNameID = pNameInfo->uNameID;
				}
			}
		}
		else if (strName == _T("Btn_Join"))
		{
			Node* pNode = (Node*)msg.pSender->GetTag();
			if (pNode && pNode->data().uDataType == GLK_GAME_ROOM)
			{
				CAFCRoomItem* pRoomItem = (CAFCRoomItem*)pNode->data().GetData();
				if (pRoomItem)
				{
					if (pRoomItem->m_bIsContest)
					{
						GetMainRoom()->OnGetRoomInfo(pRoomItem);
					}
					else
					{
						GetMainRoom()->OnCentranceGameRoom(pRoomItem);//��Ϸ����,,�����·�
					}
				}
			}
		}
		else if (strName == _T("Btn_Email"))
		{
			//::PostMessage(m_PaintManager.GetPaintWindow(), MSG_SET_LOGO,1, 0);
			OnMailClick();
		}
		else if (strName == _T("Btn_Info"))
		{
			OnUserInfo();
		}
		else if (strName == _T("Btn_Friend"))
		{
			OnIMList();
		}
		else if (strName == _T("Btn_Charm"))
		{
			OnFacExchange();
		}
		else if (strName == _T("Btn_Logo"))
		{
			OnLogoClick();
		}
		else if (strName == _T("btn_copyInform"))
		{
			OnBtnCopyClick();
		}
	}
	else if (msg.sType == _T("selectchanged"))
	{
		if (msg.pSender->GetName() == _T("Opt_GameKind"))
		{
			ComKindInfo* pKindInfo = (ComKindInfo*)msg.pSender->GetTag();
			int iShowIndex = -1;
			if (pKindInfo)
			{
				iShowIndex = pKindInfo->uKindID;
			}
			m_pGameList->ShowNameItems(iShowIndex);
		}
		ComKindInfo *pKindInfo = (ComKindInfo*)msg.pSender->GetTag();
		int ishowindex = -1;
		if(pKindInfo)
			ishowindex = pKindInfo->uKindID;

		if(m_pGameList)
			m_pGameList->ShowNameItems(ishowindex);
	}
}
void CLeftWnd::OnBtnCopyClick()
{
	//OutputDebugString("chs ���ư�ť�����");
	char buffer[500]  = {0};
	int iLen = sprintf(buffer,"�û���:%s\t�û�ID:%ld",GetMainRoom()->m_PlaceUserInfo.nickName,GetMainRoom()->m_PlaceUserInfo.dwUserID	);
	HANDLE hGlobalMemory = GlobalAlloc(GHND,iLen+1);
	LPBYTE lpGlobalMemory = (LPBYTE)GlobalLock(hGlobalMemory);
	for (int i = 0;i<iLen;++i)
	{
		*lpGlobalMemory++ = buffer[i];
	}
	::OpenClipboard(m_hWnd);
	::EmptyClipboard();
	::SetClipboardData(CF_TEXT,hGlobalMemory);
	::CloseClipboard();

	DUIMessageBox(m_hWnd,MB_OK|MB_ICONINFORMATION,"ϵͳ��ʾ","�û�ID���ǳ������Ѹ���!");
}

LRESULT CLeftWnd::HandleCustomMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	switch (uMsg)
	{
	case MSG_SET_LOGO:
		{
			int iIndex = wParam;
			if (0 > iIndex)
				return 0;	
			if (m_pLogoChangeWnd)
			{
				m_pLogoChangeWnd->ShowWindow(SW_HIDE);
			}
			//�����û�ͷ��
			if (iIndex == GetMainRoom()->m_PlaceUserInfo.bLogoID)
			{
				return 0;
			}
			GetMainRoom()->m_PlaceUserInfo.bLogoID = iIndex;
			SetUserInfoWnd(&GetMainRoom()->m_PlaceUserInfo);
			//�������ϴ���������
			GetMainRoom()->SendSetLogoInfo(GetMainRoom()->m_PlaceUserInfo.dwUserID, iIndex);
		}break;
	case WM_MOUSEMOVE:
		{
			POINT pt; 
			pt.x = GET_X_LPARAM(lParam); 
			pt.y = GET_Y_LPARAM(lParam);

			static bool bshow = false;
			CControlUI *pTemp = m_PaintManager.FindControl(pt);
			if (pTemp && (pTemp->GetName() == _T("Btn_Finance")))
			{
				if (!bshow)
				{
					OnShowFinance();
				}
				bshow = true;	
				return TRUE;
			}

			bshow = false;
			OnHideFinance();
		}break;
	default:
		break;
	}
/*	*/

	return 0;
}

//��ʾ���˲�����Ϣ
void CLeftWnd::OnShowFinance()
{
	if(NULL != m_pFinanceWnd)
	{
		return;
	}
	CControlUI *pCtrlFinance = m_PaintManager.FindControl("Btn_Finance");
	if (!pCtrlFinance)
	{
		return;
	}
	m_pFinanceWnd = new CFinanceWnd();
	if(m_pFinanceWnd)
	{
		m_pFinanceWnd->Create(m_hWnd,NULL,UI_WNDSTYLE_DIALOG,0,0,0,0,0,NULL);
		if(m_pFinanceWnd && IsWindow(m_pFinanceWnd->GetHWND()))
		{
			m_pFinanceWnd->ShowWindow(SW_SHOW);
			m_pFinanceWnd->setLifeTime();
			POINT pt;
			GetCursorPos(&pt);
			RECT rc2;
			::GetWindowRect(m_hWnd, &rc2);
			int iX = rc2.left + pCtrlFinance->GetPos().left - 10;
			int iY = rc2.top + pCtrlFinance->GetPos().top;
			RECT rc;
			::GetClientRect(m_pFinanceWnd->GetHWND(),&rc);
			::MoveWindow(m_pFinanceWnd->GetHWND(),iX,
				iY - (rc.bottom - rc.top),rc.right - rc.left,rc.bottom - rc.top,true);
		}
	}
	
	GetMainRoom()->SendData(MDM_GP_BANK,ASS_GP_BANK_FINANCE_INFO,0);
}

//���ظ��˲�����Ϣ
void CLeftWnd::OnHideFinance()
{
	if (NULL != m_pFinanceWnd)
	{
		m_pFinanceWnd->killShowTimer();
		m_pFinanceWnd->ShowWindow(SW_HIDE);
		m_pFinanceWnd->Close();
		m_pFinanceWnd = NULL;
	}
}

void CLeftWnd::HandleKindData(ComKindInfo* pKindInfoPtr, int iCount)
{
	ComKindInfo* pKindInfo = NULL;
	for (UINT i=0;i<iCount&&i<3;i++)
	{
		pKindInfo = pKindInfoPtr + i;
		if (pKindInfo && pKindInfo->uKindID != 999)
		{
			ComKindInfo* pNewKindInfo = m_mapKindInfo[pKindInfo->uKindID];
			if (!pNewKindInfo)
			{
				pNewKindInfo = new ComKindInfo;
				memcpy(pNewKindInfo, pKindInfo, sizeof(ComKindInfo));
				m_mapKindInfo[pKindInfo->uKindID] = pNewKindInfo;
				if (m_pHorOpt)
				{
					CControlUI* pCtrl = m_pHorOpt->GetItemAt(i+1);
					if (pCtrl)
					{
						pCtrl->SetText(pNewKindInfo->szKindName);
						pCtrl->SetTag((UINT_PTR)pNewKindInfo);
						m_vecKindID.push_back(pNewKindInfo->uKindID);
					}
				}
			}
		}
	}

	if (m_pHorOpt)
	{
		for (int i=2;i>=iCount;i--)
		{
			CControlUI* pCtrl = m_pHorOpt->GetItemAt(i+1);
			if (pCtrl)
			{
				pCtrl->SetVisible(false);
			}
		}

		int interspace = (272 - 50*(iCount+1))/(iCount+2);

		RECT rect;
		rect.top = 7;
		rect.left = interspace;
		rect.bottom = 7;
		rect.right = interspace;

		m_pHorOpt->SetInset(rect);
		m_pHorOpt->SetChildPadding(interspace);
	}

}

void CLeftWnd::HandleNameData(ComNameInfo* pNameInfoPtr, int iCount)
{
	int iKindIndex = 0;
	ComNameInfo *pNameInfo = NULL;

	CString strFile;
	CString strImg = GetAppPath().c_str();

	for (int i=0; i<iCount; ++i)
	{
		pNameInfo = pNameInfoPtr + i;

		if (!pNameInfo)
		{
			continue;
		}
		strFile.Format(_T("%s\\image\\game\\%d.png"), strImg, pNameInfo->uNameID);
		if ((_access( strFile, 0 )) == -1)
		{
			continue;
		}
		for (int j=0; j<m_vecKindID.size(); ++j)
		{
			if (m_vecKindID[j] == pNameInfo->uKindID)
			{
				iKindIndex = j+1;
				break;
			}
		}
		if (m_pGameList)
		{
			Node* pNode = m_pGameList->AddGameNode(pNameInfo, iKindIndex);
			m_mapNameNode[pNameInfo->uNameID] = pNode;
		}
	}	
}

void CLeftWnd::HandleRoomData(ComRoomInfo * pRoomInfoPtr, int iCount, UINT uKindID, UINT uNameID)
{
	ComRoomInfo* pRoomInfo = NULL;
	for (int i=0; i<iCount; ++i)
	{
		pRoomInfo = pRoomInfoPtr + i;
		if (!pRoomInfo)
		{
			continue;
		}

		if (pRoomInfo->dwRoomRule & GRR_GAME_BUY)
		{
			continue;
		}

		Node* pNode = m_mapNameNode[uNameID];
		if (!pNode)
		{
			continue;
		}
		bool bExist = false;
		Node* pChild = NULL;
		for (int i=0; i!=pNode->num_children(); ++i)
		{
			pChild = pNode->child(i);
			if (pChild)
			{
				CAFCRoomItem* pExistRoomItem = (CAFCRoomItem*)pChild->data().GetData();
				if (pExistRoomItem && pExistRoomItem->m_RoomInfo.uRoomID == pRoomInfo->uRoomID)
				{
					bExist = true;
					break;
					
				}	
				else if(pExistRoomItem && 
					(pExistRoomItem->m_bIsContest && 
					pExistRoomItem->m_iContestID==pRoomInfo->iContestID)&&
					(pRoomInfo->dwRoomRule & GRR_CONTEST ||pRoomInfo->dwRoomRule & GRR_TIMINGCONTEST))
				{
					bExist = true;
					pExistRoomItem->m_RoomContest.push_back(*pRoomInfo);
					break;
				}
			}
		}
		if (!bExist)
		{
			Node* pRoomNode = m_pGameList->AddRoomNode(pRoomInfo, pNode);
			if (pRoomNode)
			{
				m_mapRoomNode[pRoomInfo->uRoomID] = pRoomNode;
			}
		}
	}
}

//���ұ�����������
ComRoomInfo * CLeftWnd::FindContestRoomItem(CAFCRoomItem * pRoomItem, int iRoomID)
{
	if (pRoomItem != NULL && pRoomItem->m_bIsContest)
	{
		for (int i = 0; i < pRoomItem->m_RoomContest.size(); i++)
		{
			if (pRoomItem->m_RoomContest[i].uRoomID == iRoomID)
				return &(pRoomItem->m_RoomContest[i]);
		}
	}
	return NULL;
}

ComNameInfo* CLeftWnd::FindNameInfo(UINT uNameID, UINT uKindID)
{
	ComNameInfo* pNameInfo = NULL;

	do
	{
		Node* pNode = m_mapNameNode[uNameID];
		if (!pNode)
		{
			break;
		}
		pNameInfo = (ComNameInfo*)(pNode->data().GetData());
	}while(0);
	
	return pNameInfo;	
}

bool CLeftWnd::HandleNameOnLineData(DL_GP_RoomListPeoCountStruct * pOnLineCountPtr, UINT uCount)
{
	for (UINT i=0;i<uCount;i++)
	{
		Node* pNode = m_mapNameNode[(pOnLineCountPtr+i)->uID];
		if (!pNode)
		{
			continue;
		}
		ComNameInfo* pNameInfo = (ComNameInfo*)pNode->data().GetData();
		if (!pNameInfo)
		{
			continue;
		}
		pNameInfo->m_uOnLineCount = (pOnLineCountPtr+i)->uOnLineCount;
	}	
	return true;
}

bool CLeftWnd::HandleRoomOnLineData(DL_GP_RoomListPeoCountStruct * pOnLineCountPtr, UINT uCount)
{
	Node* pRoomNode = NULL;
	CAFCRoomItem* pRoomItem = NULL;
	for (UINT i=0;i<uCount;i++)
	{
		pRoomNode = m_mapRoomNode[(pOnLineCountPtr+i)->uID];
		if (!pRoomNode)
		{
			continue;
		}
		pRoomItem = (CAFCRoomItem*)pRoomNode->data().GetData();
		if (pRoomItem!=NULL)
		{
			if (!pRoomItem->m_bIsContest)
			{
				pRoomItem->m_RoomInfo.uPeopleCount=(pOnLineCountPtr+i)->uOnLineCount;
				CRoomElementUI* pEle = static_cast<CRoomElementUI*>(pRoomNode->data().list_elment_);
				if (pEle)
				{
					pEle->Refresh();
				}
			}
			else
			{
				ComRoomInfo* pRoomInfo = FindContestRoomItem(pRoomItem, (pOnLineCountPtr+i)->uID);
				if (pRoomInfo)
				{
					pRoomInfo->uPeopleCount = (pOnLineCountPtr+i)->uOnLineCount;
				}
			}
		}
	}	
	return true;
}

bool CLeftWnd::GetProcessName(CAFCRoomItem * pGameRoomItem, TCHAR * szProcessName, UINT uBufferSize)
{
	if (!pGameRoomItem)
	{
		return false;
	}
	Node* pNode = m_mapNameNode[pGameRoomItem->m_RoomInfo.uNameID];
	if (pNode)
	{
		ComNameInfo* pNameInfo = (ComNameInfo*)pNode->data().GetData();
		if (pNameInfo)
		{
			CString GameProcessName;
			GameProcessName.Format("%d.exe",pNameInfo->uNameID);
			CopyMemory(szProcessName,GameProcessName.GetBuffer(),__min(uBufferSize,sizeof(GameProcessName.GetLength())));
			szProcessName[uBufferSize/sizeof(TCHAR)-1]=0;
			return true;
		}
	}
	return false;
}

bool CLeftWnd::GetGameName(CAFCRoomItem * pGameRoomItem, TCHAR * szGameName, UINT uBufferSize)
{
	if (!pGameRoomItem)
	{
		return false;
	}
	Node* pNode = m_mapNameNode[pGameRoomItem->m_RoomInfo.uNameID];
	if (pNode)
	{
		ComNameInfo* pNameInfo = (ComNameInfo*)pNode->data().GetData();
		if (pNameInfo)
		{
			CopyMemory(szGameName, pNameInfo->szGameName,__min(uBufferSize,sizeof(pNameInfo->szGameName)));
			szGameName[uBufferSize/sizeof(TCHAR)-1]=0;
			return true;
		}
	}
	return false;
}

void CLeftWnd::UpdatePeopleCount()
{
	if (m_pTxtOnlineCount)
	{
		CString str;
		str.Format("��������(%d)", GetMainRoom()->GetonlineUserCount());
		m_pTxtOnlineCount->SetText(str);
	}
}

void CLeftWnd::UnInit()
{
	m_mapNameNode.clear();

	m_mapRoomNode.clear();

	if (m_pGameList)
	{
		m_pGameList->RemoveAll();
	}
}

//����ͷ��
void CLeftWnd::SetLogo(UINT bLogoID)
{
	CControlUI* pCtrlLogo = m_PaintManager.FindControl(_T("Btn_Logo"));
	if (pCtrlLogo)
	{
		TCHAR str[MAX_PATH];
		wsprintf(str, TEXT("..\\..\\log\\UserLogos\\Logo_%d.png"), bLogoID<0?0:bLogoID);
		pCtrlLogo->SetBkImage(str);
	}	
}
void CLeftWnd::AddMail(TMailItem mail)
{
	m_Mails.push(mail);
	if (m_Mails.size() > 0)
	{
		//m_btMail.SetFlicker(true);
		CString s;
		s.Format("%d", m_Mails.size());
		//m_btMail.EnableToShowText(s, true);
		//m_btMail.Invalidate(FALSE);
	}
}

void CLeftWnd::OnMailClick()
{
	if (m_Mails.size() > 0)
	{
		TMailItem it = m_Mails.front();

		DUIMessageBox(m_hWnd,MB_ICONINFORMATION|MB_OK,"ϵͳ��ʾ",it.szMsg);

		m_Mails.pop();

		CString s;
		s.Format("%d", m_Mails.size());
	}
	else
	{
		if (GetMainRoom()->m_TopDuWnd != NULL)
		{
			GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(false);
		}
		DUIOkeyMsgBox(m_hWnd,"����ǰû�ж���Ϣ");
		if (GetMainRoom()->m_TopDuWnd != NULL)
		{
			GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(true);
		}
	}
}

void CLeftWnd::OnUserInfo()
{
	if (m_pUserInfoWnd)
	{
		return;
	}

	m_pUserInfoWnd = new CUserInfoWnd();
	if(!m_pUserInfoWnd)
	{
		return;
	}
	if (GetMainRoom()->m_TopDuWnd != NULL)
	{
		GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(false);
	}
	m_pUserInfoWnd->SetPlaceUserInfo(&GetMainRoom()->m_PlaceUserInfo);
	m_pUserInfoWnd->Create(m_hWnd,NULL,UI_WNDSTYLE_DIALOG,0,0,0,0,0,NULL);
	m_pUserInfoWnd->CenterWindow();
	m_pUserInfoWnd->ShowModal();

	delete m_pUserInfoWnd;
	m_pUserInfoWnd = NULL;

	if (GetMainRoom()->m_TopDuWnd != NULL)
	{
		GetMainRoom()->m_TopDuWnd->SetMaxOrRestoreBtn(true);
	}
	return;
}

void CLeftWnd::OnIMList()
{
	::PostMessage(GetParent(m_hWnd), WM_SHOW_IM, 0, 0);
}

void CLeftWnd::OnFacExchange()
{
	GetMainRoom()->ShowCharmPannel();
}

void CLeftWnd::OnLogoClick()
{
	if (!m_pLogoChangeWnd)
		return;

	m_pLogoChangeWnd->SetIndex(GetMainRoom()->m_PlaceUserInfo.bLogoID);
	m_pLogoChangeWnd->CenterWindow();
	m_pLogoChangeWnd->ShowWindow(SW_SHOW);

	POINT pt;
	GetCursorPos(&pt);
	int iX = pt.x - 10;
	int iY = pt.y;
	RECT rc;
	::GetClientRect(m_pLogoChangeWnd->GetHWND(),&rc);
	::MoveWindow(m_pLogoChangeWnd->GetHWND(),iX, iY+4,rc.right - rc.left,rc.bottom - rc.top,true);
}

void  CLeftWnd::SetUserInfoWnd(MSG_GP_R_LogonResult * logoResult)
{
	if(logoResult == NULL)
		return ;

	TCHAR str[MAX_PATH];
	SetLogo(logoResult->bLogoID);

	wsprintf(str, TEXT("%s"), logoResult->nickName);
	CControlUI *pCtrl = m_PaintManager.FindControl(_T("Txt_Name"));
	if (pCtrl)
	{
		pCtrl->SetText(str);
	}

	wsprintf(str, TEXT("%ld"), logoResult->dwUserID);
	pCtrl = m_PaintManager.FindControl(_T("Txt_ID"));
	if (pCtrl)
	{
		pCtrl->SetText(str);
	}
}

