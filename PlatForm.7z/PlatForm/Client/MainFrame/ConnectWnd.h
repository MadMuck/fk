#pragma once

#include "BaseRoom.h"
class CBaseRoom;
class CConnectDlg : 
	public BzDui::CWindowWnd,
	public BzDui::INotifyUI,
	public BzDui::IMessageFilterUI
{
public:
	CConnectDlg(void);
	~CConnectDlg(void);

	LPCTSTR GetWindowClassName() const;

	UINT GetClassStyle() const;

	void OnFinalMessage(HWND hWnd);

	void Init();

	void Notify(BzDui::TNotifyUI& msg);

public:

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);

protected:

	BzDui::CPaintManagerUI m_pm;




public:
	//�˳���ť
	void OnQuit();

	//������Ϣ��ʾ
	bool SetMessageText(const TCHAR * szMessage);

	//��ʾ���ض���
	void ShowProgress(bool bShow, CBaseRoom *pBaseRoom = NULL);
private:
	BzDui::CControlUI *m_pProgress;//������
	bool m_bStart;//����

	CBaseRoom *m_pBaseRoom;//����ָ��
	CSkinMgr   m_skinmgr;
};

