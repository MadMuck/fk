#include "StdAfx.h"
#include "GRoomManagerWnd.h"
#include "DUITopWnd.h"
#include "GameRoomEx.h"

using namespace BzDui;
CGRoomManagerWnd::CGRoomManagerWnd(CWnd* pParent, long int dwUserID, MSG_GR_GRM_UpData* Updata)
{	
	m_ShowAI = false;
	m_pGameRoom = pParent;
	m_bSeletPond = false;//�Ƿ�����������
	m_bSeletWinProb = false;//�Ƿ��������Ӯ��������
	m_uRoomID = 0;
	m_dwUserID = dwUserID;
	memset(&m_GRM_Updata, 0 , sizeof(m_GRM_Updata));
	ClearProbListRepetitionUserID();//�����б�����
	if (Updata != NULL)
	{
		CopyMemory(&m_GRM_Updata,Updata,sizeof(m_GRM_Updata));
	}

	if (m_GRM_Updata.bAIWinAndLostAutoCtrl == 1)
	{
		m_bSeletPond = true;
	}

	if (m_GRM_Updata.bWinProbCtrl == 1)
	{
		m_bSeletWinProb = true;
	}

	//ÿ�δ򿪴���Ӧ��ʵʱ��������
	CGameRoomEx* pGameRoomEx = (CGameRoomEx*)m_pGameRoom;
	if (NULL == pGameRoomEx)
		return;
	pGameRoomEx->SendData(NULL,0,MDM_GR_MANAGE,ASS_GR_GRM_UPDATA,RES_GR_GRM_UP2);

}

CGRoomManagerWnd::~CGRoomManagerWnd(void)
{
}

LPCTSTR CGRoomManagerWnd::GetWindowClassName() const 
{ 
	return _T("UIFrame");
};

UINT CGRoomManagerWnd::GetClassStyle() const 
{ 
	return UI_CLASSSTYLE_DIALOG; 
};

void CGRoomManagerWnd::OnFinalMessage(HWND hWnd) 
{ 
	//CTopDuWndClass::UnRegisterTopperWnd(m_hWnd);
	m_pm.RemovePreMessageFilter(this);
	//delete this;
};

LRESULT CGRoomManagerWnd::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LONG styleValue = ::GetWindowLong(*this, GWL_STYLE);
	styleValue &= ~WS_CAPTION;
	::SetWindowLong(*this, GWL_STYLE, styleValue | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);

	m_pm.Init(m_hWnd);
	m_pm.AddPreMessageFilter(this);
	CDialogBuilder builder;
	CControlUI* pRoot = builder.Create(_T("room_mid\\GRMWnd\\GRMWnd.xml"), (UINT)0, NULL, &m_pm);
	ASSERT(pRoot && "Failed to parse XML");
	m_pm.AttachDialog(pRoot);
	m_pm.AddNotifier(this);

	//CTopDuWndClass::RegisterTopperWnd(m_hWnd);
	Init();

	HRGN hRgn;
	RECT rcClient;
	GetClientRect(GetHWND(),&rcClient);
	hRgn = CreateRoundRectRgn(rcClient.left, rcClient.top, rcClient.right, rcClient.bottom, 5, 5);
	SetWindowRgn(GetHWND(), hRgn, TRUE);

	CString sdp;
	sdp.Format("sdp_ GRM OnCreate-----");
	OutputDebugString(sdp);

	return 0;
}

LRESULT CGRoomManagerWnd::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;    
	return 0;
}

LRESULT CGRoomManagerWnd::OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if( ::IsIconic(*this) ) bHandled = FALSE;
	return (wParam == 0) ? TRUE : FALSE;
}

LRESULT CGRoomManagerWnd::OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CGRoomManagerWnd::OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CGRoomManagerWnd::OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	POINT pt; pt.x = GET_X_LPARAM(lParam); pt.y = GET_Y_LPARAM(lParam);
	::ScreenToClient(*this, &pt);

	RECT rcClient;
	::GetClientRect(*this, &rcClient);

	RECT rcCaption = m_pm.GetCaptionRect();
	if( pt.x >= rcClient.left + rcCaption.left && pt.x < rcClient.right - rcCaption.right \
		&& pt.y >= rcCaption.top && pt.y < rcCaption.bottom ) 
	{
			CControlUI* pControl = static_cast<CControlUI*>(m_pm.FindControl(pt));
			if( pControl && _tcscmp(pControl->GetClass(), _T("ButtonUI")) != 0 )
				return HTCAPTION;
	}

	return HTCLIENT;
}

LRESULT CGRoomManagerWnd::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CGRoomManagerWnd::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lRes = 0;
	BOOL bHandled = TRUE;
	switch(uMsg) 
	{
		case WM_CREATE:
			{
				 lRes = OnCreate(uMsg, wParam, lParam, bHandled); 
			}
			break;

		case WM_DESTROY:       
			{
				 lRes = OnDestroy(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCACTIVATE:    
			{
				 lRes = OnNcActivate(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCCALCSIZE:    
			{
				 lRes = OnNcCalcSize(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCPAINT:       
			{
				lRes = OnNcPaint(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCHITTEST:     
			{
				 lRes = OnNcHitTest(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_SIZE:          
			{
				lRes = OnSize(uMsg, wParam, lParam, bHandled);
			}
			break;

		default:
			bHandled = FALSE;
	}

	if(bHandled)
	{
		return lRes;
	}

	if(m_pm.MessageHandler(uMsg,wParam,lParam,lRes))
	{
		return lRes;
	}

	return CWindowWnd::HandleMessage(uMsg, wParam, lParam);
}

LRESULT CGRoomManagerWnd::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if( uMsg == WM_KEYDOWN ) 
	{
		if( wParam == VK_RETURN ) 
		{
			OnOK();
			return true;
		}
		else if( wParam == VK_ESCAPE ) 
		{
			Close();
			return true;
		}
	}
	return false;
}

void CGRoomManagerWnd::Init() 
{
	LoadNormalCtrlSkin();

	//�����Ƿ���ʾ������ѡ���
	CComboUI* pCobCtrl = NULL;
	pCobCtrl = static_cast<CComboUI*>(m_pm.FindControl("Cob_2"));
	if (NULL != pCobCtrl)
	{
		CString str;
		pCobCtrl->RemoveAll();

		CListLabelElementUI* p = new CListLabelElementUI();
		pCobCtrl->SetTag(0);
		pCobCtrl->Add(p);

		str.Empty();
		str.Format("����AI");
		p->SetText(str);

		CListLabelElementUI* p2 = new CListLabelElementUI();
		pCobCtrl->SetTag(1);
		pCobCtrl->Add(p2);

		str.Empty();
		str.Format("��ʾAI");
		p2->SetText(str);

		pCobCtrl->SelectItem(m_ShowAI==false?0:1);
		pCobCtrl->SetEnabled(true);
	}

	//��������ʼ��
	Init_Title();
	//�û���Ϣ�����ʼ��
	Init_UerInfo();
	//���������ʼ��
	Init_Pond();
	//�����Ӯ���Ƴ�ʼ��
	Init_WinProb();

	CTextUI* pTextCtrl = NULL;
	TCHAR sz[128];
	pTextCtrl = static_cast<CTextUI*>(m_pm.FindControl("Text_8"));
	if (NULL != pTextCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"");
		pTextCtrl->SetText(sz);
		pTextCtrl->SetVisible(false);
	}
}

//��������ʼ��
void CGRoomManagerWnd::Init_Title()
{
	return;
}

//���ǵ������ܻ������ҽ����������Ӧʱʱ�����û��б�
void CGRoomManagerWnd::UpDataUserInfo()
{
	Init_UerInfo();
	return;
}

//�û���Ϣ�����ʼ��
void CGRoomManagerWnd::Init_UerInfo()
{
	//��ʼ���б�
	UserItemStruct * pFindUserItem = NULL;
	CGameRoomEx* pGameRoomEx = (CGameRoomEx*)m_pGameRoom;
	if (NULL == m_pGameRoom)
	{
		return;
	}

	CListUI* pListCtrl = NULL;
	CString str;
	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_1"));
	if (NULL != pListCtrl)
	{
		// ����List�б����ݣ�������Add(pListElement)����SetText
		int inum = 0;
		pListCtrl->RemoveAll();
		for(int i = 0 ; i < pGameRoomEx->m_UserManage.GetOnLineUserCount(); i ++)
		{
			pFindUserItem =  pGameRoomEx->m_UserManage.FindOnLineUserByIndex(i);
			if(pFindUserItem == NULL)
				continue;

			if (!m_ShowAI && pFindUserItem->GameUserInfo.isVirtual)
				continue;

			CListTextElementUI* pListElement = new CListTextElementUI;
			pListElement->SetTag(inum);
			pListCtrl->Add(pListElement);

			str.Empty();
			str.Format("%d", i);
			pListElement->SetText(0, str);//���1
			str.Empty();
			str.Format("%ld", pFindUserItem->GameUserInfo.dwUserID);
			pListElement->SetText(1, str);//�û�id2
			str.Empty();
			str.Format("%s", pFindUserItem->GameUserInfo.nickName);
			pListElement->SetText(2, str);//�û��ǳ�3
			str.Empty();
			if (1 == pFindUserItem->GameUserInfo.isVirtual)
			{
				str.Format("��");
			} 
			else
			{
				str.Format("��");
			}
			pListElement->SetText(3, str);//�Ƿ������4
			str.Empty();
			str.Format("%I64d", pFindUserItem->GameUserInfo.i64Money);
			pListElement->SetText(4, str);//���5
			str.Empty();
			str.Format("%d", pFindUserItem->GameUserInfo.bDeskNO);
			pListElement->SetText(5, str);//���Ӻ�6
			str.Empty();
			str.Format("%d", pFindUserItem->GameUserInfo.uWinCount);
			pListElement->SetText(6, str);//ʤ����Ŀ7
			str.Empty();
			str.Format("%d", pFindUserItem->GameUserInfo.uLostCount);
			pListElement->SetText(7, str);//����Ŀ8
			str.Empty();
			str.Format("%d", pFindUserItem->GameUserInfo.uMidCount);
			pListElement->SetText(8, str);//�;���Ŀ9
			str.Empty();
			str.Format("%d", pFindUserItem->GameUserInfo.uCutCount);
			pListElement->SetText(9, str);//ǿ����Ŀ10

			++inum;
		}
	}


	return;
}

//����CListUI���б���
void CGRoomManagerWnd::ProbLoadListItems()
{
	CListUI* pListCtrl = NULL;
	CString str;
	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_2"));
	if (NULL != pListCtrl)
	{
		// ����List�б����ݣ�������Add(pListElement)����SetText
		int inum = 0;
		pListCtrl->RemoveAll();
		for(int i = 0 ; i < 20; i ++)
		{
			if (m_GRM_Updata.dwUserID_win[i] <= 0)
				continue;

			CListTextElementUI* pListElement = new CListTextElementUI;
			pListElement->SetTag(inum);
			pListCtrl->Add(pListElement);

			str.Empty();
			str.Format("%d", inum);
			pListElement->SetText(0, str);//���1
			str.Empty();
			str.Format("%ld", m_GRM_Updata.dwUserID_win[i]);
			pListElement->SetText(1, str);//�û�id2
			str.Empty();
			str.Format("%d", m_GRM_Updata.iProb_win[i]);
			pListElement->SetText(2, str);//��Ӯ����3

			++inum;
		}

		for(int i = 0 ; i < 20; i ++)
		{
			if (m_GRM_Updata.dwUserID_los[i] <= 0)
				continue;

			CListTextElementUI* pListElement = new CListTextElementUI;
			pListElement->SetTag(inum);
			pListCtrl->Add(pListElement);

			str.Empty();
			str.Format("%d", inum);
			pListElement->SetText(0, str);//���1
			str.Empty();
			str.Format("%ld", m_GRM_Updata.dwUserID_los[i]);
			pListElement->SetText(1, str);//�û�id2
			str.Empty();
			str.Format("%d", 0 - m_GRM_Updata.iProb_los[i]);
			pListElement->SetText(2, str);//��Ӯ����3

			++inum;
		}
	}
}

//Ϊ�б�������
void CGRoomManagerWnd::ProbListAddItem()
{
	CComboUI* pCobCtrl = NULL;
	CEditUI* pEdtCtrl = NULL;
	CListUI* pListCtrl = NULL;
	long int iUserID = 0;
	int iProb = 0;
	pCobCtrl = static_cast<CComboUI*>(m_pm.FindControl("Cob_1"));
	if (NULL != pCobCtrl)
	{
		CString str = pCobCtrl->GetText();
		iUserID = atoi(str);
	}

	//���������
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_9"));
	if (NULL != pEdtCtrl)
	{
		CString str = pEdtCtrl->GetText();
		iProb = atoi(str);
	}

	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_2"));
	if (pListCtrl == NULL)
		return;

	if (iUserID <= 0)
		return;

	CListTextElementUI* pListElement = NULL;
	//��֤�б����� �� �޸�,û�� �� ����
	int iIndex = GetProbListlineID(iUserID);
	if (iIndex != -1)
	{
		pListElement = (CListTextElementUI*)pListCtrl->GetItemAt(iIndex);
		if (pListElement == NULL)
			return;
		pListCtrl->SetItemIndex(pListElement, pListCtrl->GetItemIndex(pListElement));
		CString str;
		str.Format("%d", iProb);
		pListElement->SetText(2, str);//��Ӯ����3
	}
	else
	{
		pListElement = new CListTextElementUI;
		pListElement->SetTag(pListCtrl->GetCount()-1);
		pListCtrl->Add(pListElement);
		CString str;
		str.Empty();
		str.Format("%d", pListCtrl->GetCount()-1);
		pListElement->SetText(0, str);//���1
		str.Empty();
		str.Format("%ld", iUserID);
		pListElement->SetText(1, str);//�û�id2
		str.Empty();
		str.Format("%d", iProb);
		pListElement->SetText(2, str);//��Ӯ����3
	}

}

//Ϊ�б�ɾ����
void CGRoomManagerWnd::ProbListDelItem(int iIndex,bool bAll)
{
	CListUI* pListCtrl = NULL;
	CString str;
	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_2"));
	if (pListCtrl == NULL)
		return;

	if (bAll)
	{
		pListCtrl->RemoveAll();
	} 
	else
	{
		bool tag = pListCtrl->RemoveAt(iIndex);
		//ɾ���ɹ�������Ҫ�ǵø���ɾ��λ�ú���� �� ��Ž�һλ
		if (tag)
		{
			CListTextElementUI* pListElement = NULL;
			for (int i=iIndex;i<pListCtrl->GetCount();++i)
			{
				pListElement = (CListTextElementUI*)pListCtrl->GetItemAt(i);
				if (pListElement != NULL)
				{
					pListCtrl->SetItemIndex(pListElement, pListCtrl->GetItemIndex(pListElement));
					CString str;
					str.Format("%d", i+1);
					pListElement->SetText(0, str);//���1
				}

			}
		}


	}
}

//�����Ӯ�����б�ĳһ��
int  CGRoomManagerWnd::GetProbListlineID(long int UserID)
{
	if (UserID == 0)
		return -1;

	CListUI* pListCtrl = NULL;
	CString str;
	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_2"));
	if (NULL != pListCtrl)
	{
		CListTextElementUI* pListElement = NULL;
		for (int i = 0; i < pListCtrl->GetCount();++i)
		{
			pListElement = (CListTextElementUI*)pListCtrl->GetItemAt(i);
			CString str = pListElement->GetText(1);
			long int inum = atoi(str);
			if (inum == UserID)
			{
				return i;
			}
		}
	}

	return -1;
}

//�����Ӯ�����б�ѡ�е���
int CGRoomManagerWnd::GetProbListSelelineID()
{
	CListUI* pListCtrl = NULL;
	CString str;
	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_2"));
	if (NULL == pListCtrl)
		return -1;

	return pListCtrl->GetCurSel();
}

////����ظ���UserID
void CGRoomManagerWnd::ClearProbListRepetitionUserID()
{
	//Ӯ���������ڲ�
	for (int i=0;i<20-1;++i)
	{
		for (int j=i+1;j<20;++j)
		{
			if (m_GRM_Updata.dwUserID_win[j] == m_GRM_Updata.dwUserID_win[i])
			{
				m_GRM_Updata.dwUserID_win[j] = 0;
				m_GRM_Updata.iProb_win[j] = 0;
			}
		}
	}
	//����������ڲ�
	for (int i=0;i<20-1;++i)
	{
		for (int j=i+1;j<20;++j)
		{
			if (m_GRM_Updata.dwUserID_los[j] == m_GRM_Updata.dwUserID_los[i])
			{
				m_GRM_Updata.dwUserID_los[j] = 0;
				m_GRM_Updata.iProb_los[j] = 0;
			}
		}
	}
	//����ʲ��ܺ�Ӯ�����ظ�
	for (int i=0;i<20;++i)
	{
		for (int j=0;j<20;++j)
		{
			if (m_GRM_Updata.dwUserID_win[j] == m_GRM_Updata.dwUserID_los[i])
			{
				m_GRM_Updata.dwUserID_los[j] = 0;
				m_GRM_Updata.iProb_los[j] = 0;
			}
		}
	}
}

//���������ʼ��
void CGRoomManagerWnd::Init_Pond()
{
	COptionUI* pOptCtrl = NULL;
	CTextUI* pTextCtrl = NULL;
	CEditUI* pEdtCtrl = NULL;
	TCHAR sz[128];
	pOptCtrl = static_cast<COptionUI*>(m_pm.FindControl("Opt_1"));
	if (NULL != pOptCtrl)
	{
		pOptCtrl->Selected(m_bSeletPond);
		pOptCtrl->SetEnabled(true);
		pOptCtrl->SetVisible(true);
	}

	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_1"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"0");
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(false);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_2"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%I64d",m_GRM_Updata.iAIWantWinMoney[0]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_3"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%I64d",m_GRM_Updata.iAIWantWinMoney[1]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_4"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%I64d",m_GRM_Updata.iAIWantWinMoney[2]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_5"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%d",m_GRM_Updata.iAIWinLuckyAt[0]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_6"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%d",m_GRM_Updata.iAIWinLuckyAt[1]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_7"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%d",m_GRM_Updata.iAIWinLuckyAt[2]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_8"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%d",m_GRM_Updata.iAIWinLuckyAt[3]);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_10"));
	if (NULL != pEdtCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"%d",m_GRM_Updata.iReSetAIHaveWinMoney);
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletPond);
		pEdtCtrl->SetVisible(true);
	}
	
	pTextCtrl = static_cast<CTextUI*>(m_pm.FindControl("Text_7"));
	if (NULL != pTextCtrl)
	{
		::sprintf_s(sz,sizeof(sz),"�������Ѿ�Ӯ�Ľ�%I64d",m_GRM_Updata.iAIHaveWinMoney);
		pTextCtrl->SetText(sz);
		pTextCtrl->SetVisible(true);
	}
}

//�����Ӯ���Ƴ�ʼ��
void CGRoomManagerWnd::Init_WinProb()
{
	COptionUI* pOptCtrl = NULL;
	CComboUI* pCobCtrl = NULL;
	CTextUI* pTextCtrl = NULL;

	pOptCtrl = static_cast<COptionUI*>(m_pm.FindControl("Opt_2"));
	if (NULL != pOptCtrl)
	{

		pOptCtrl->Selected(m_bSeletWinProb);
		pOptCtrl->SetEnabled(true);
		pOptCtrl->SetVisible(true);
	}

	Init_WinProb_Cob();//����ѡ���

	ProbLoadListItems();

}

//�����Ӯ�����е�һ������ѡ����ʼ��
void CGRoomManagerWnd::Init_WinProb_Cob()
{
	CComboUI* pCobCtrl = NULL;
	CTextUI* pTextCtrl = NULL;
	CEditUI* pEdtCtrl = NULL;
	TCHAR sz[128];
	::sprintf_s(sz,sizeof(sz),"0");
	pCobCtrl = static_cast<CComboUI*>(m_pm.FindControl("Cob_1"));
	if (NULL != pCobCtrl)
	{
		UserItemStruct * pFindUserItem = NULL;
		CGameRoomEx* pGameRoomEx = (CGameRoomEx*)m_pGameRoom;
		if (pGameRoomEx == NULL)
			return;

		CString str;
		int inum = 0;
		pCobCtrl->RemoveAll();
		for(int i = 0 ; i < pGameRoomEx->m_UserManage.GetOnLineUserCount(); i ++)
		{
			pFindUserItem =  pGameRoomEx->m_UserManage.FindOnLineUserByIndex(i);
			if(pFindUserItem == NULL)
				continue;

			if (!m_ShowAI && pFindUserItem->GameUserInfo.isVirtual)
				continue;

			CListLabelElementUI* p = new CListLabelElementUI();
			pCobCtrl->SetTag(inum);
			pCobCtrl->Add(p);

			str.Empty();
			str.Format("%ld", pFindUserItem->GameUserInfo.dwUserID);
			p->SetText(str);//�û�id

			++inum;
		}

		pCobCtrl->SelectItem(0);

		pCobCtrl->SetEnabled(m_bSeletWinProb);
	}

	//���������
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_9"));
	if (NULL != pEdtCtrl)
	{
		long int iUserID = 0;
		if (NULL != pCobCtrl)
		{
			CString str = pCobCtrl->GetText();
			iUserID = atoi(str);
		}
		::sprintf_s(sz,sizeof(sz),"%d",GetProbFromUserID(iUserID));
		pEdtCtrl->SetText(sz);
		pEdtCtrl->SetEnabled(m_bSeletWinProb);
		pEdtCtrl->SetVisible(true);
	}
}

//��Ӯ�����и����û�id��ȡ���ʣ�û�ҵ�����0
int CGRoomManagerWnd::GetProbFromUserID(long int UserID)
{
	for (int i = 0; i < 20; ++i)
	{
		if (m_GRM_Updata.dwUserID_win[i] == UserID)
		{
			return m_GRM_Updata.iProb_win[i];
		}
		if (m_GRM_Updata.dwUserID_los[i] == UserID)
		{
			return 0 - m_GRM_Updata.iProb_los[i];
		}
	}

	return 0;
}
void CGRoomManagerWnd::OnOK()
{
	CString sz;
	COptionUI* pOptCtrl = NULL;
	CEditUI* pEdtCtrl = NULL;
	CListUI* pListCtrl = NULL;
	CGameRoomEx* pGameRoomEx = (CGameRoomEx*)m_pGameRoom;
	if (NULL == pGameRoomEx)
		return;

	MSG_GR_GRM_Set cmd;
	memset(&cmd, 0, sizeof(cmd));
	cmd.dwUserID = m_dwUserID;	//�û� ID
	pOptCtrl = static_cast<COptionUI*>(m_pm.FindControl("Opt_1"));
	if (NULL == pOptCtrl)
		return;

	cmd.bAIWinAndLostAutoCtrl = pOptCtrl->IsSelected();//�����˿�����Ӯ����

	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_2"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWantWinMoney[0] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_3"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWantWinMoney[1] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_4"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWantWinMoney[2] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_5"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWinLuckyAt[0] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_6"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWinLuckyAt[1] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_7"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWinLuckyAt[2] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_8"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iAIWinLuckyAt[3] = atoi(sz);
	}
	pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_10"));
	if (NULL != pEdtCtrl)
	{
		sz = pEdtCtrl->GetText();
		cmd.iReSetAIHaveWinMoney = atoi(sz);
	}

	//�����Ӯ���ƿ���
	pOptCtrl = static_cast<COptionUI*>(m_pm.FindControl("Opt_2"));
	if (NULL == pOptCtrl)
		return;

	cmd.bWinProbCtrl = pOptCtrl->IsSelected();

	int iwinNum = 0;
	int ilosNum = 0;
	long int iUserID = 0;
	int iProb = 0;
	pListCtrl = static_cast<CListUI*>(m_pm.FindControl("List_2"));
	if (NULL != pListCtrl)
	{
		CListTextElementUI* pListElement = NULL;
		for (int i = 0; i < pListCtrl->GetCount();++i)
		{
			pListElement = (CListTextElementUI*)pListCtrl->GetItemAt(i);
			sz = pListElement->GetText(1);
			iUserID = atoi(sz);
			if (iUserID <=0)
				continue;

			sz = pListElement->GetText(2);
			iProb = atoi(sz);
			if (iProb >= 0 && iwinNum < 20)
			{
				cmd.dwUserID_win[iwinNum] = iUserID;
				cmd.iProb_win[iwinNum] = iProb;
				++iwinNum;
			}
			if (iProb < 0 && ilosNum < 20)
			{
				cmd.dwUserID_los[ilosNum] = iUserID;
				cmd.iProb_los[ilosNum] = 0 - iProb;//��������
				++ilosNum;
			}
		}
	}

	pGameRoomEx->SendData(&cmd,sizeof(cmd),MDM_GR_MANAGE,ASS_GR_GRM_SET,0);
}

//����Combol���б���
void CGRoomManagerWnd::LoadComboItems(CComboUI* pCtrl,LPCTSTR items[],int nums,int nSelect/* = 0*/)
{
	if (!pCtrl || nums <= 0)
	{
		return;
	}

	for (int i = 0; i < nums; ++i)
	{
		CListLabelElementUI* p = new CListLabelElementUI();
		p->SetText(items[i]);
		pCtrl->Add(p);
	}

	return;
}

//�����ı�����ѡ���б���
bool CGRoomManagerWnd::SelectComboItem(BzDui::CComboUI* pCtrl,LPCTSTR szText)
{
	if (!pCtrl)
	{
		return false;
	}

	int itNums = pCtrl->GetCount();

	if (itNums <= 0)
	{
		return false;
	}

	for (int i = 0; i < itNums; ++i)
	{
		if (strcmp(szText,pCtrl->GetItemAt(i)->GetText().GetData()) == 0)
		{
			pCtrl->SelectItem(i);
			return true;
		}
	}

	return false;
}

void CGRoomManagerWnd::Notify(TNotifyUI& msg)
{
	if( msg.sType == _T("click")) 
	{
		if( msg.pSender->GetName() == _T("Btn_Close")) 
		{
			Close();
		}
		if( msg.pSender->GetName() == _T("Btn_OK")) 
		{
			OnOK();
		}
		if( msg.pSender->GetName() == _T("Btn_Cancel")) 
		{
			Close();
		}
		if (msg.pSender->GetName() == _T("Btn_Add") && m_bSeletWinProb)
		{
			ProbListAddItem();
		}
		if (msg.pSender->GetName() == _T("Btn_Del") && m_bSeletWinProb)
		{
			ProbListDelItem(GetProbListSelelineID());
		}
		if (msg.pSender->GetName() == _T("Btn_UpData") && m_bSeletWinProb)
		{
			Init_WinProb_Cob();
		}
	}
	else if(msg.sType == _T("selectchanged"))
	{
		COptionUI* pOptCtrl = NULL;
		if (msg.pSender->GetName() == _T("Opt_1"))
		{
			pOptCtrl = static_cast<COptionUI*>(m_pm.FindControl("Opt_1"));
			if (NULL != pOptCtrl)
			{
				bool bOldSelet = m_bSeletPond;
				m_bSeletPond = pOptCtrl->IsSelected();
				if (bOldSelet != m_bSeletPond)//�иı���ˢ�¿ؼ�״̬
				{
					Init_Pond();
				}
			}
		}
		else if (msg.pSender->GetName() == _T("Opt_2"))
		{
			pOptCtrl = static_cast<COptionUI*>(m_pm.FindControl("Opt_2"));
			if (NULL != pOptCtrl)
			{
				bool bOldSelet = m_bSeletWinProb;
				m_bSeletWinProb = pOptCtrl->IsSelected();
				if (bOldSelet != m_bSeletWinProb)//�иı���ˢ�¿ؼ�״̬
				{
					Init_WinProb();
				}
			}
		}
	}
	else if (msg.sType == _T("itemselect"))
	{
		if (msg.pSender->GetName() == _T("Cob_1"))
		{
			CEditUI* pEdtCtrl = NULL;
			CComboUI* pCobCtrl = NULL;
			TCHAR sz[128];
			::sprintf_s(sz,sizeof(sz),"0");
			pCobCtrl = static_cast<CComboUI*>(m_pm.FindControl("Cob_1"));
			//���������
			pEdtCtrl = static_cast<CEditUI*>(m_pm.FindControl("Edit_9"));
			if (NULL != pEdtCtrl)
			{
				long int iUserID = 0;
				if (NULL != pCobCtrl)
				{
					CString str = pCobCtrl->GetText();
					iUserID = atoi(str);
				}
				::sprintf_s(sz,sizeof(sz),"%d",GetProbFromUserID(iUserID));
				pEdtCtrl->SetText(sz);
				pEdtCtrl->SetEnabled(m_bSeletWinProb);
				pEdtCtrl->SetVisible(true);
			}
		}
		else if (msg.pSender->GetName() == _T("Cob_2"))
		{
			m_ShowAI = !m_ShowAI;

			CComboUI* pCobCtrl = NULL;
			pCobCtrl = static_cast<CComboUI*>(m_pm.FindControl("Cob_2"));
			if (NULL != pCobCtrl)
			{
				if (pCobCtrl->GetCurSel() == 0)//����
				{
					m_ShowAI = false;
				}
				else if (pCobCtrl->GetCurSel() == 1)//��ʾ
				{
					m_ShowAI = true;
				}
			}

			Init_UerInfo();
			Init_WinProb();
		}
	}
}

//���س���ؼ�Ƥ��
void CGRoomManagerWnd::LoadNormalCtrlSkin()
{
	int idx = 0;
	CStdPtrArray* pCtrls = NULL;

	//���������ı��༭���Ƥ��
	pCtrls = m_pm.FindSubControlsByClass(m_pm.GetRoot(),_TEXT("EditUI"));
	CEditUI* pEditUI = NULL;
	do 
	{
		pEditUI = static_cast<CEditUI*>(pCtrls->GetAt(idx++));
		if (pEditUI)
		{
			if (pEditUI->GetName() == _T("Edt_ID"))
			{
				continue;
			}
            pEditUI->SetNormalImage("file='common\\edit.png' dest='0,0,500,30' source='0,0,500,23' corner='3,4,2,2'");
            pEditUI->SetHotImage("file='common\\edit.png' dest='0,0,500,30' source='0,23,500,46' corner='3,4,2,2'");
            pEditUI->SetFocusedImage("file='common\\edit.png' dest='0,0,500,30' source='0,46,500,69' corner='3,4,2,2'");
            pEditUI->SetDisabledImage("file='common\\edit.png' dest='0,0,500,30' source='0,69,500,92' corner='3,4,2,2'");
		}
	} while (pEditUI);

	//�������������б����Ƥ��
	idx = 0;
	pCtrls = m_pm.FindSubControlsByClass(m_pm.GetRoot(),_TEXT("ComboUI"));
	CComboUI* pComboUI = NULL;
	do 
	{
		pComboUI = static_cast<CComboUI*>(pCtrls->GetAt(idx++));
		if (pComboUI)
		{
            pComboUI->SetNormalImage("file='common\\combo.png' dest='0,0,500,30' source='0,0,500,23' corner='5,0,22,0'");
            pComboUI->SetHotImage("file='common\\combo.png' dest='0,0,500,30' source='0,23,500,46' corner='5,0,22,0'");
            pComboUI->SetPushedImage("file='common\\combo.png' dest='0,0,500,30' source='0,46,500,69' corner='5,0,22,0'");
            pComboUI->SetDisabledImage("file='common\\combo.png' dest='0,0,500,30' source='0,69,500,92' corner='5,0,22,0'");
            RECT rc = {6,0,0,0};
			pComboUI->SetItemTextPadding(rc);

// 			CScrollBarUI* pVScroll = pComboUI->GetVerticalScrollBar();
// 			if (pVScroll)
// 			{
// 				pVScroll->SetBkNormalImage("file='dialog\\vscrollbar_back.png' dest='0,0,14,100' source='0,0,14,100' corner='0,0,0,0'");
// 				pVScroll->SetButton1NormalImage("file='dialog\\vscrollbar_up.png' dest='0,0,16,16' source='0,0,16,16' corner='0,0,0,0'");
// 			}
		}
	} while (pComboUI);

	//�������ж�ѡ���Ƥ��
	idx = 0;
	pCtrls = m_pm.FindSubControlsByClass(m_pm.GetRoot(),_TEXT("OptionUI"));
	COptionUI* pOptionUI = NULL;
	do 
	{
		pOptionUI = static_cast<COptionUI*>(pCtrls->GetAt(idx++));
		if (pOptionUI)
		{
			pOptionUI->SetNormalImage("file='common\\check.png' dest='0,0,15,15' source='0,0,15,15' corner='0,0,0,0'");
			pOptionUI->SetHotImage("file='common\\check.png' dest='0,0,15,15' source='15,0,30,15' corner='0,0,0,0'");
			pOptionUI->SetSelectedImage("file='common\\check.png' dest='0,0,15,15' source='30,0,45,15' corner='0,0,0,0'");
		}
	} while (pOptionUI);

}

//�յ��������
void CGRoomManagerWnd::OnHandleGRMSetResult(DWORD bHandleCode,void * pNetData, UINT uDataSize)
{
	CString sdp;
	sdp.Format("sdp_ GRM c �յ��������!");
	OutputDebugString(sdp);

	//Ч������
	if (uDataSize!=sizeof(MSG_GR_GRM_Set)) 
		return;
	MSG_GR_GRM_Set * pCmd = (MSG_GR_GRM_Set *)pNetData;
	if (pCmd == NULL)
		return;
	CTextUI* pTextCtrl = NULL;
	pTextCtrl = static_cast<CTextUI*>(m_pm.FindControl("Text_8"));
	if (NULL == pTextCtrl)
		return;
	TCHAR sz[128];
	if (bHandleCode == RES_GR_GRM_SET_RES_ERR1)
	{
		::sprintf_s(sz,sizeof(sz),"���������޸� ʧ�ܣ�");
	}
	else if (bHandleCode == RES_GR_GRM_SET_RES_ERR2)
	{
		::sprintf_s(sz,sizeof(sz),"�����Ӯ���������޸� ʧ�ܣ�");
	}
	else if (bHandleCode == RES_GR_GRM_SET_RES_ERR3)
	{
		::sprintf_s(sz,sizeof(sz),"��û���޸�Ȩ�� �� �����޴˹��ܣ�");
	}
	else if (bHandleCode == RES_GR_GRM_SET_RES_ERR_ALL)
	{
		::sprintf_s(sz,sizeof(sz),"���� ��Ч��");
	}
	else if (bHandleCode == RES_GR_GRM_SET_RES_SUC)
	{
		::sprintf_s(sz,sizeof(sz),"���� �ɹ���");
		//�ɹ�����ˢ�´�������
		CGameRoomEx* pGameRoomEx = (CGameRoomEx*)m_pGameRoom;
		if (NULL == pGameRoomEx)
			return;
		pGameRoomEx->SendData(NULL,0,MDM_GR_MANAGE,ASS_GR_GRM_UPDATA,RES_GR_GRM_UP2);
	}
	else
	{
		return;
	}

	pTextCtrl->SetText(sz);
	pTextCtrl->SetVisible(true);

	return;
}

//�յ�����
void CGRoomManagerWnd::OnHandleGRMUpData(DWORD bHandleCode,void * pNetData, UINT uDataSize)
{
	//Ч������
	if (uDataSize!=sizeof(MSG_GR_GRM_UpData)) 
		return;
	MSG_GR_GRM_UpData * pCmd = (MSG_GR_GRM_UpData *)pNetData;
	if (pCmd == NULL)
		return;

	CTextUI* pTextCtrl = NULL;
	TCHAR sz[128];
	if (bHandleCode == RES_GR_GRM_UP1)
	{
		m_GRM_Updata.iAIHaveWinMoney = pCmd->iAIHaveWinMoney;
		pTextCtrl = static_cast<CTextUI*>(m_pm.FindControl("Text_7"));
		if (NULL != pTextCtrl)
		{
			::sprintf_s(sz,sizeof(sz),"�������Ѿ�Ӯ�Ľ�%I64d",m_GRM_Updata.iAIHaveWinMoney);
			pTextCtrl->SetText(sz);
			pTextCtrl->SetVisible(true);
		}
	}
	if (bHandleCode == RES_GR_GRM_UP2)
	{
		CopyMemory(&m_GRM_Updata,pCmd,sizeof(m_GRM_Updata));

		if (m_GRM_Updata.bAIWinAndLostAutoCtrl == 1)
		{
			m_bSeletPond = true;
		}
		else
		{
			m_bSeletPond = false;
		}

		if (m_GRM_Updata.bWinProbCtrl == 1)
		{
			m_bSeletWinProb = true;
		}
		else
		{
			m_bSeletWinProb = false;
		}

		//���������ʼ��
		Init_Pond();
		//�����Ӯ���Ƴ�ʼ��
		Init_WinProb();
	}

	CString sdp;
	sdp.Format("sdp_ GRM c �յ�������Ϣ ������!");
	OutputDebugString(sdp);

}