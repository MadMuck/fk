#include "StdAfx.h"
#include "ContestRoom.h"
#include "GameRoomEx.h"
#include "MainRoomEx.h"

#define IMAGEHEIGHT 560
#define IMAGEWIDTH 850
#define BUTTONHEIGHT 100
#define BUTTONWIDTH 170

using namespace BzDui;

CContestRoom::CContestRoom(void)
{
	m_preulaNeed1 = NULL;
	m_preulaNeed2 = NULL;
	m_pneed = NULL;
	m_pmatchTimeCount = NULL;
	m_ptime = NULL;
	m_pRoomBK= NULL;
	m_pInfoBK= NULL;
	m_uRoomID = 0;
	m_dwUserID = 0;
	m_iUpPeople = 0;
}

CContestRoom::~CContestRoom(void)
{
	
}

LPCTSTR CContestRoom::GetWindowClassName() const 
{ 
	return _T("UIFrame");
};

UINT CContestRoom::GetClassStyle() const 
{ 
	return UI_CLASSSTYLE_DIALOG; 
};

void CContestRoom::OnFinalMessage(HWND hWnd) 
{ 
	m_pm.RemovePreMessageFilter(this);
};

LRESULT CContestRoom::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LONG styleValue = ::GetWindowLong(*this, GWL_STYLE);
	styleValue &= ~WS_CAPTION;
	::SetWindowLong(*this, GWL_STYLE, styleValue | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);

	m_pm.Init(m_hWnd);
	m_pm.AddPreMessageFilter(this);
	CDialogBuilder builder;
	CControlUI* pRoot = builder.Create(_T("room_mid\\ContestRoom.xml"), (UINT)0, NULL, &m_pm);
	ASSERT(pRoot && "Failed to parse XML");
	m_pm.AttachDialog(pRoot);
	m_pm.AddNotifier(this);

	m_pRoomBK = static_cast<CContainerUI*>(m_pm.FindControl(_T("ContestBK")));
	m_pInfoBK = static_cast<CContainerUI*>(m_pm.FindControl(_T("ContestInfo")));

	m_pJoin = static_cast<CButtonUI*>(m_pm.FindControl(_T("Btn_Join")));
	m_pCancel = static_cast<CButtonUI*>(m_pm.FindControl(_T("Btn_Cancel")));

	Init();
	return 0;
}

LRESULT CContestRoom::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	return 0;
}

LRESULT CContestRoom::OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if( ::IsIconic(*this) ) bHandled = FALSE;
	return (wParam == 0) ? TRUE : FALSE;
}

LRESULT CContestRoom::OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CContestRoom::OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CContestRoom::OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	POINT pt; pt.x = GET_X_LPARAM(lParam); pt.y = GET_Y_LPARAM(lParam);
	::ScreenToClient(*this, &pt);

	RECT rcClient;
	::GetClientRect(*this, &rcClient);

	RECT rcCaption = m_pm.GetCaptionRect();
	if( pt.x >= rcClient.left + rcCaption.left && pt.x < rcClient.right - rcCaption.right \
		&& pt.y >= rcCaption.top && pt.y < rcCaption.bottom ) 
	{
			CControlUI* pControl = static_cast<CControlUI*>(m_pm.FindControl(pt));
			if( pControl && _tcscmp(pControl->GetClass(), _T("ButtonUI")) != 0 )
				return HTCAPTION;
	}

	return HTCLIENT;
}

LRESULT CContestRoom::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	RECT rect, bkrect, btnrect;
	::GetClientRect(*this, &rect);

	if(m_pRoomBK)
	{
		m_pRoomBK->SetFixedHeight(rect.bottom-rect.top);
		m_pRoomBK->SetFixedWidth(rect.right-rect.left);
	}
	
	if(m_pInfoBK)
	{
		
		bkrect.top = (rect.bottom+rect.top-IMAGEHEIGHT)/2 ;
		bkrect.bottom = (rect.bottom+rect.top+IMAGEHEIGHT)/2 ;
		bkrect.right = (rect.right+rect.left+IMAGEWIDTH)/2;
		bkrect.left = (rect.right+rect.left-IMAGEWIDTH)/2;
		

		m_pInfoBK->SetPos(bkrect);
	}

	

	return 0;
}

LRESULT CContestRoom::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CContestRoom::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	LRESULT lRes = 0;
	BOOL bHandled = TRUE;
	switch(uMsg) 
	{
		case WM_CREATE:
			{
				 lRes = OnCreate(uMsg, wParam, lParam, bHandled); 
			}
			break;

		case WM_TIMER:
			{
				lRes = OnTimer(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_DESTROY:       
			{
				 lRes = OnDestroy(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCACTIVATE:    
			{
				 lRes = OnNcActivate(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCCALCSIZE:    
			{
				 lRes = OnNcCalcSize(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCPAINT:       
			{
				lRes = OnNcPaint(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_NCHITTEST:     
			{
				 lRes = OnNcHitTest(uMsg, wParam, lParam, bHandled);
			}
			break;

		case WM_SIZE:          
			{
				lRes = OnSize(uMsg, wParam, lParam, bHandled);
			}
			break;

		default:
			bHandled = FALSE;
	}

	if(bHandled)
	{
		return lRes;
	}

	if(m_pm.MessageHandler(uMsg,wParam,lParam,lRes))
	{
		return lRes;
	}

	return CWindowWnd::HandleMessage(uMsg, wParam, lParam);
}

LRESULT CContestRoom::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if( uMsg == WM_KEYDOWN ) 
	{
		
	}
	return false;
}

void CContestRoom::Init() 
{
	m_preulaNeed1 = static_cast<CTextUI*>(m_pm.FindControl("text_regulaNeed1"));
	m_preulaNeed2 = static_cast<CTextUI*>(m_pm.FindControl("text_regulaNeed2"));
	m_pneed = static_cast<CTextUI*>(m_pm.FindControl("Text_Need"));
	m_pmatchTimeCount = static_cast<CTextUI*>(m_pm.FindControl("text_matchTimeCount"));
	m_ptime = static_cast<CTextUI*>(m_pm.FindControl("text_time"));
	m_pRoomBK = static_cast<CContainerUI*>(m_pm.FindControl("ContestBK"));

}

void CContestRoom::Notify(TNotifyUI& msg)
{
	if( msg.sType == _T("click")) 
	{
		if( msg.pSender->GetName() == _T("Btn_Join")) 
		{
			MSG_GR_I_ContestApply _in;
			_in.iUserID = m_dwUserID;
			_in.iTypeID = 0;
			if(GetGameRoom(m_uRoomID))
				GetGameRoom(m_uRoomID)->SendData(&_in,sizeof(_in),MDM_GR_USER_ACTION,ASS_GR_CONTEST_APPLY,0);
		}
		else if( msg.pSender->GetName() == _T("Btn_Cancel")) 
		{
			MSG_GR_I_ContestApply _in;
			_in.iUserID = m_dwUserID;
			_in.iTypeID = 1;
			GetGameRoom(m_uRoomID)->SendData(&_in,sizeof(_in),MDM_GR_USER_ACTION,ASS_GR_CONTEST_APPLY,0);
		}
	}
	
}

void CContestRoom::OnOK()
{
	
}

void CContestRoom::SetContestInfo(ContestInfo *pContestRoom,__int64 i64Money,int iUpPeople,long int dwUserID,int iRoomID)
{
	CString str;

	CTextUI *pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Champion")));
	if(pTxt)
	{
		str.Format("%d",pContestRoom->iChampionCount);
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Best")));
	if(pTxt)
	{
		str.Format("%d",pContestRoom->iBestRank);
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_JoinCount")));
	if(pTxt)
	{
		str.Format("%d",pContestRoom->iJoinCount);
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Money")));
	if(pTxt)
	{
		str.Format("%lld",i64Money);
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_First")));
	if(pTxt)
	{
		str.Format("%d%s",pContestRoom->iRankAward[0],pContestRoom->iAwardType[0] == 0?"���":"��ȯ");
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Second")));
	if(pTxt)
	{
		str.Format("%d%s",pContestRoom->iRankAward[1],pContestRoom->iAwardType[1] == 0?"���":"��ȯ");
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Third")));
	if(pTxt)
	{
		str.Format("%d%s",pContestRoom->iRankAward[2],pContestRoom->iAwardType[2] == 0?"���":"��ȯ");
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Already")));
	if(pTxt)
	{
		str.Format("%d",pContestRoom->iConstestNum);
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Need")));
	if(pTxt)
	{
		str.Format("%d",iUpPeople - pContestRoom->iConstestNum);
		pTxt->SetText(str);
	}

	m_uRoomID = iRoomID;
	m_dwUserID = dwUserID;
	m_iUpPeople = iUpPeople;


	InitButton();
}

void CContestRoom::SelectButton(int iButtonState)
{
	if(1 == iButtonState)
	{
		m_pJoin->SetVisible(false);
		m_pCancel->SetVisible(true);
	}
	if(0 == iButtonState)
	{
		m_pJoin->SetVisible(true);
		m_pCancel->SetVisible(false);
	}
}

void CContestRoom::UpdateContestNum(int iContestNum)
{
	CString str;
	CTextUI *pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Already")));
	if(pTxt)
	{
		str.Format("%d",iContestNum);
		pTxt->SetText(str);
	}
	pTxt = static_cast<CTextUI*>(m_pm.FindControl(_T("Text_Need")));
	if(pTxt)
	{
		str.Format("%d",m_iUpPeople - iContestNum);
		pTxt->SetText(str);
	}
}


void CContestRoom::InitButton()
{
	CString s=CBcfFile::GetAppPath ();
	CINIFile frecord(s+ RECORDFILE);

	if(!CINIFile::IsFileExist(s+ RECORDFILE))
		return;

	int irecordcount =frecord.GetKeyVal(CString("RecordCount"),CString("count"),0);
	CString csSection, csdebug;
	for(int i = 1;i<=irecordcount;++i)
	{
		csSection.Format("Record_%d",i);
		long luserid = frecord.GetKeyVal(csSection,CString("userid"),0);
		if(luserid == GetMainRoom()->m_PlaceUserInfo.dwUserID)
		{
			int iabolish = frecord.GetKeyVal(csSection,CString("abolish"),100);
			int year = frecord.GetKeyVal(csSection,CString("year"),0);
			int month = frecord.GetKeyVal(csSection,CString("month"),0);
			int day = frecord.GetKeyVal(csSection,CString("day"),0);
			int hour = frecord.GetKeyVal(csSection,CString("hour"),0);
			int min = frecord.GetKeyVal(csSection,CString("min"),0);
			int sec = frecord.GetKeyVal(csSection,CString("sec"),0);
			int iRoomid = frecord.GetKeyVal(csSection,CString("roomid"),0);

			if(iRoomid == 0)
			{
				AFCMessageBox(CString("��Ǹ����ȡ��ʱ��������Ϣʧ��"));
				continue;
			}
			if(iabolish == 0 && iRoomid == m_uRoomID)
			{
				COleDateTime matchBeginTime(year,month,day,hour,min,sec);

				if(matchBeginTime > COleDateTime::GetCurrentTime())
				{
					if(0 == iabolish)
					{
						m_pJoin->SetVisible(false);
						m_pCancel->SetVisible(true);
						GetGameRoom(m_uRoomID)->m_iContestState = 1;
						GetGameRoom(m_uRoomID)->m_bContestApply = 1;
					}
					else
					{
						m_pJoin->SetVisible(true);
						m_pCancel->SetVisible(false);
						GetGameRoom(m_uRoomID)->m_iContestState = 0;
						GetGameRoom(m_uRoomID)->m_bContestApply = 0;
					}
				}
			}
		}
		
	}
}