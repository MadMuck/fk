///��������
#include "StdAfx.h"
#include "BaseRoom.h"

BEGIN_MESSAGE_MAP(CBaseRoom, CGameFaceGo)
	ON_WM_SIZE()
	ON_MESSAGE(WM_SPLIT_WND,OnSplitMessage)
END_MESSAGE_MAP()

#define TRANSPARENT_COLOR RGB(255,0,255)//͸��ɫ

//���캯��
CBaseRoom::CBaseRoom(UINT uDialogTemplata) : CGameFaceGo(uDialogTemplata)
{
	m_TCPSocket = NULL;
	m_TCPSocket = new CTCPClientSocket(this);
}

//��������
CBaseRoom::~CBaseRoom()
{
	if (m_TCPSocket != NULL)
		delete m_TCPSocket;
}

//��ʼ������
BOOL CBaseRoom::OnInitDialog()
{
	CGameFaceGo::OnInitDialog();

	SetClassLong(m_hWnd,GCL_HBRBACKGROUND,NULL);

	return TRUE;
}

//λ�ñ仯
void CBaseRoom::OnSize(UINT nType, int cx, int cy)
{
	CGameFaceGo::OnSize(nType, cx, cy);
	if ((cx!=0)&&(cy!=0)) OnSizeEvent(nType,cx,cy);
	return;
}
//�������Ϣ
LRESULT CBaseRoom::OnSplitMessage(WPARAM wparam, LPARAM lparam)
{
	OnSplitEvent((UINT)wparam,LOWORD(lparam),HIWORD(lparam));
	return 0;
}
//����������Ϣ����
int CBaseRoom::SendGameData(BYTE bMainID, BYTE bAssistantID, BYTE bHandleCode)
{
	if (m_TCPSocket != NULL)
		return m_TCPSocket->SendData(bMainID,bAssistantID,bHandleCode);//����������
	return 0;
}

//����������Ϣ����
int CBaseRoom::SendGameData(void * pData, UINT uBufLen, BYTE bMainID, BYTE bAssistantID, BYTE bHandleCode)
{
	if (m_TCPSocket != NULL)
		return m_TCPSocket->SendData(pData,uBufLen,bMainID,bAssistantID,bHandleCode);
	return 0;
}


int CBaseRoom::CloseSocket(bool bNotify)
{
	if (m_TCPSocket != NULL)
		return m_TCPSocket->CloseSocket(bNotify);
	return 0;
}

//���ͺ���
int CBaseRoom::SendData(void * pData, UINT uSize, BYTE bMainID, BYTE bAssistantID, BYTE bHandleCode)
{
	if (m_TCPSocket != NULL)
		return m_TCPSocket->SendData(pData, uSize, bMainID, bAssistantID, bHandleCode);
	return 0;
}
//������ͺ���
int CBaseRoom::SendData(BYTE bMainID, BYTE bAssistantID, BYTE bHandleCode)
{
	if (m_TCPSocket != NULL)
		return m_TCPSocket->SendData(bMainID, bAssistantID, bHandleCode);
	return 0;
}

/*******************************************************************************************************/
