#pragma once

#include <queue>
#include "FinanceWnd.h"
#include "LogoChangeDlg.h"
#include "UserInfoWnd.h"
#include "AfcGameListWnd.h"

class CUserInfoSimplifyWnd : 
	public BzDui::CWindowWnd,
	public BzDui::INotifyUI,
	public BzDui::IMessageFilterUI
{
public:
	CUserInfoSimplifyWnd(CGameListWnd *pCGameListWnd);
	~CUserInfoSimplifyWnd(void);

	LPCTSTR GetWindowClassName() const;

	UINT GetClassStyle() const;

	void OnFinalMessage(HWND hWnd);

	void Init();

	void Notify(BzDui::TNotifyUI& msg);

public:

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);

protected:

	CGameListWnd*					m_pCGameListWnd;//��������
	BzDui::CPaintManagerUI			m_pm;
	queue<TMailItem>				m_Mails;//�ʼ���Ϣ
	CFinanceWnd*					m_pFinanceWnd;		//����״������
	CLogoChangeDlg*					m_pLogoChangeWnd;	//����ͷ��
	CUserInfoWnd*					m_pUserInfoWnd;		//�û����Ϲ�����

	BzDui::CButtonUI *m_pBut_mail;//�ʼ���ť
	BzDui::CButtonUI *m_pBut_info;//����
	BzDui::CButtonUI *m_pBut_friend;//����
	BzDui::CButtonUI *m_pBut_fascx;//����ֵ��ť
	BzDui::CButtonUI *m_pBut_logo;//����ͷ��ť
	BzDui::CControlUI *m_pControl_logo;//����ͷ��ͼƬ�ؼ�
	BzDui::CButtonUI *m_pBut_finance;//����״����ť

	BzDui::CTextUI *m_text_UserID;//�û�id
	BzDui::CTextUI *m_text_NickName;//�ǳ�
	CSkinMgr        m_skinmgr;
	

public:
	//����ͷ��
	void SetLogo(UINT bLogoID);
	//�����ʼ�
	void AddMail(TMailItem mail);
	//��ʾ/���ظ��˲�����Ϣ
	void OnShowFinance();
	void OnHideFinance();

	//����ʼ���ť
	void OnMailClick();
	void OnUserInfo();
	void OnIMList();
	void OnFacExchange();
	void OnLogoClick();
	

	//�յ�����logoͼ�����Ϣ
	LRESULT	OnSetLogo(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnMouseMove(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	//�����û���Ϣ
	void  SetUserInfoWnd(MSG_GP_R_LogonResult *logoResult);

	void ShowBut_friend(bool bShow){m_pBut_friend->SetVisible(bShow);}

	CUserInfoWnd* GetUserInfoWnd(){return m_pUserInfoWnd;}

	CFinanceWnd* GetFinanceWnd(){return m_pFinanceWnd;}

	//��ô��ڸ߿�
	UINT GetWndwidth(){return m_pm.GetClientSize().cx;}
	UINT GetWndHeight(){return m_pm.GetClientSize().cy;}
};
