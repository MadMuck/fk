#pragma once
#include "GameListUI.h"
#include "GameElementUI.h"

enum E_DOWNLOAD_STATE
{
	E_OK,	//�������
	E_ERROR,//���ش���
	E_WAIT,	//�ȴ�����
	E_ING	//��������	
};
struct S_DowndloadItme
{	
	char	szGameName[61];	//��Ϸ����	
	char szUrl[MAX_PATH];	//���ص�ַ
	char	szErr[50];		//������Ϣ
	float	fSize;			//�ļ��ܴ�С
	float	fDownSize;		//�����ش�С	
	float	fSpeed;		//�����ٶ�
	UINT	uNameID;		//��Ϸ���� ID ����
	UINT	uiProgress;		//���ؽ���
	E_DOWNLOAD_STATE e_state;
	bool    bU3dGame;
	bool	bCocosGame;
	S_DowndloadItme()
	{ 
		ZeroMemory(this,sizeof(S_DowndloadItme));
	}
};

typedef map<UINT, BzDui::CListContainerElementUI*> map_GameItem;

class CDownloadListUI: public BzDui::CListUI
{
public:
	CDownloadListUI(void);
	~CDownloadListUI(void);

	bool AddGame(ComNameInfo* pNameInfo, const char* lpstrUrl,bool bU3dGame = false,bool bCocosGame = false);
		
	void UpdateData(BzDui::CListContainerElementUI *pElement);

	bool UpdateGame(S_DowndloadItme* pDownloadItem);

	S_DowndloadItme* GetItem(UINT uNameID);

private:

	map_GameItem m_mapGame;
	CSkinMgr     m_skinmgr;
};

class CProgressExUI : public BzDui::CProgressUI
{
public:
	void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue);
};

class CDialogBuilderCallbackEx : public BzDui::IDialogBuilderCallback
{
public:
	BzDui::CControlUI* CreateControl(LPCTSTR pstrClass) 
	{
		if(_tcscmp(pstrClass, _T("DownloadList")) == 0)
		{			
			return new CDownloadListUI;
		}
		else if(_tcscmp(pstrClass, _T("ProgressEx")) == 0)
		{
			return new CProgressExUI;
		}
		else if(_tcscmp(pstrClass, _T("GameList")) == 0)
		{
			CGameListUI *pControl = new CGameListUI;
			return pControl;
		}
		else if (_tcscmp(pstrClass, _T("GameElement")) == 0)
		{
			CGameElementUI *pControl = new CGameElementUI;
			return pControl;
		}
		else if (_tcscmp(pstrClass, _T("RoomElement")) == 0)
		{
			CRoomElementUI *pControl = new CRoomElementUI;
			return pControl;
		}
		return NULL;
	}
};
