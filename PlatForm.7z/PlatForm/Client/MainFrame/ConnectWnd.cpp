#include "StdAfx.h"
#include "ConnectWnd.h"
#include "MainRoomEx.h"

using namespace BzDui;

//��������ʱ�� ID
#define ID_PRO_TIME					100	

CConnectDlg::CConnectDlg(void)
{
	m_pProgress = NULL;
	m_bStart = false;
}


CConnectDlg::~CConnectDlg(void)
{
}

LPCTSTR CConnectDlg::GetWindowClassName() const 
{ 
	return _T("UIFrame");
};

UINT CConnectDlg::GetClassStyle() const 
{ 
	return UI_CLASSSTYLE_DIALOG; 
};

void CConnectDlg::OnFinalMessage(HWND hWnd) 
{ 
	m_pm.RemovePreMessageFilter(this);
};

LRESULT CConnectDlg::OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	LONG styleValue = ::GetWindowLong(*this, GWL_STYLE);
	styleValue &= ~WS_CAPTION;
	::SetWindowLong(*this, GWL_STYLE, styleValue | WS_CLIPSIBLINGS | WS_CLIPCHILDREN);

	m_pm.Init(m_hWnd);
	m_pm.AddPreMessageFilter(this);
	CDialogBuilder builder;
	CControlUI* pRoot = builder.Create(_T("ConnectWnd\\ConnectWnd.xml"), (UINT)0, NULL, &m_pm);
	ASSERT(pRoot && "Failed to parse XML");
	m_pm.AttachDialog(pRoot);
	m_pm.AddNotifier(this);

	Init();
	return 0;
}

LRESULT CConnectDlg::OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	bHandled = FALSE;
	return 0;
}

LRESULT CConnectDlg::OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if( ::IsIconic(*this) ) bHandled = FALSE;
	return (wParam == 0) ? TRUE : FALSE;
}

LRESULT CConnectDlg::OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CConnectDlg::OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CConnectDlg::OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	POINT pt; pt.x = GET_X_LPARAM(lParam); pt.y = GET_Y_LPARAM(lParam);
	::ScreenToClient(*this, &pt);

	RECT rcClient;
	::GetClientRect(*this, &rcClient);

	RECT rcCaption = m_pm.GetCaptionRect();
	if( pt.x >= rcClient.left + rcCaption.left && pt.x < rcClient.right - rcCaption.right \
		&& pt.y >= rcCaption.top && pt.y < rcCaption.bottom ) 
	{
		CControlUI* pControl = static_cast<CControlUI*>(m_pm.FindControl(pt));
		if( pControl && _tcscmp(pControl->GetClass(), _T("ButtonUI")) != 0 )
			return HTCAPTION;
	}

	return HTCLIENT;
}

LRESULT CConnectDlg::OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	return 0;
}

LRESULT CConnectDlg::HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam)
{	
	LRESULT lRes = 0;
	BOOL bHandled = TRUE;
	switch(uMsg) 
	{
	case WM_CREATE:
		{
			lRes = OnCreate(uMsg, wParam, lParam, bHandled); 
		}
		break;

	case WM_TIMER:
		{
			lRes = OnTimer(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_DESTROY:       
		{
			lRes = OnDestroy(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCACTIVATE:    
		{
			lRes = OnNcActivate(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCCALCSIZE:    
		{
			lRes = OnNcCalcSize(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCPAINT:       
		{
			lRes = OnNcPaint(uMsg, wParam, lParam, bHandled);
		}
		break;

	case WM_NCHITTEST:     
		{
			lRes = OnNcHitTest(uMsg, wParam, lParam, bHandled);
		}
		break;
	default:
		bHandled = FALSE;
	}

	if(bHandled)
	{
		return lRes;
	}

	if(32769!=uMsg && m_pm.MessageHandler(uMsg,wParam,lParam,lRes))
	{
		return lRes;
	}

	return CWindowWnd::HandleMessage(uMsg, wParam, lParam);
}

LRESULT CConnectDlg::MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled)
{
	if( uMsg == WM_KEYDOWN ) 
	{
		if( wParam == VK_RETURN ) 
		{
			return true;
		}
		else if( wParam == VK_ESCAPE ) 
		{
			return true;
		}
	}
	return false;
}

void CConnectDlg::Init()
{
	m_pProgress = static_cast<CControlUI*>(m_pm.FindControl("progress"));
	if (m_pProgress == NULL)
	{
		DUIMessageBox(m_hWnd,MB_ICONINFORMATION|MB_OK,"ϵͳ��ʾ","����������Ϣ�����");
	}
}

void CConnectDlg::Notify(TNotifyUI& msg)
{
	if (msg.sType == _T("click"))
	{
		if (msg.pSender->GetName() == _T("closebtn"))
		{
			OnQuit();
		}
	}
}

LRESULT CConnectDlg::OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
	if (ID_PRO_TIME == wParam)
	{
		////////////////////////////////////////////////
		TCHAR path[MAX_PATH];
		static int itag = 1;
		if (m_bStart)//����ʱ��ų�ʼ��
		{
			itag = 1;
			m_bStart = false;
		}
			
		if(itag >= 11)//������������ʾ�ȶ�״̬
		{
			wsprintf(path,"file='ConnectWnd\\%d.png'", (itag%10 + 21));
		}
		else
		{
			wsprintf(path,"file='ConnectWnd\\%d.png'", (itag%11 + 1));
		}
			
		++itag;

		m_pProgress->SetBkImage(path);
	}

	return 0;
}

//�˳���ť
void CConnectDlg::OnQuit()
{
	KillTimer(m_hWnd,ID_PRO_TIME);
	if (NULL != m_pBaseRoom)
	{
		if (m_pBaseRoom->OnCancelConnectEvent()) 
			ShowWindow(false);
	}
}

//����������
bool CConnectDlg::SetMessageText(const TCHAR *szMessage)
{
	return true;	///< ���ֱ�����ף����Բ�������
	if (szMessage==NULL) return false;
	return true;
}

//��ʾ���ض���
void CConnectDlg::ShowProgress(bool bShow, CBaseRoom *pBaseRoom)
{
	ShowWindow(bShow, bShow);
	m_bStart = bShow;
	KillTimer(m_hWnd, ID_PRO_TIME);
	if (bShow)
	{
		m_pBaseRoom = pBaseRoom;//����������ʾ������˭�򿪵�
		SetTimer(m_hWnd, ID_PRO_TIME,100,NULL);//��������ʱ�� ID
	}
	else
	{
		m_pBaseRoom = NULL;
	}
}