#pragma once

#ifndef CONTESTROOM_HEAD_H
#define CONTESTROOM_HEAD_H

#include "StdAfx.h"
#include <vector>

class CContestRoom : 
		public BzDui::CWindowWnd,
		public BzDui::INotifyUI,
		public BzDui::IMessageFilterUI
{

public:

	CContestRoom();
	virtual ~CContestRoom(void);

	LPCTSTR GetWindowClassName() const;

	UINT GetClassStyle() const;

	void OnFinalMessage(HWND hWnd);

	void Init();

	void Notify(BzDui::TNotifyUI& msg);


public:

	LRESULT OnCreate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnDestroy(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcActivate(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcCalcSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcPaint(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnNcHitTest(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnSize(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT OnTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled);

	LRESULT HandleMessage(UINT uMsg, WPARAM wParam, LPARAM lParam);

	LRESULT MessageHandler(UINT uMsg, WPARAM wParam, LPARAM lParam, bool& bHandled);

	void OnOK();

	void SetContestInfo(ContestInfo *pContestRoom,__int64 i64Money,int iUpPeople,long int dwUserID,int iRoomID);

	void SelectButton(int iButtonState);

	void UpdateContestNum(int iContestNum);

	void InitButton();

	BzDui::CContainerUI* GetGameBkContainer()	
	{ 
		if(m_pInfoBK)
			return m_pInfoBK;
		else
			return NULL;
	}
	BzDui::CButtonUI* GetJoinBtn()	{return m_pJoin;}
	BzDui::CButtonUI* GetCancelBtn()	{return m_pCancel;}

private:
	BzDui::CPaintManagerUI		m_pm;
	BzDui::CContainerUI			*m_pRoomBK;
	BzDui::CContainerUI			*m_pInfoBK;
	BzDui::CButtonUI			*m_pJoin;
	BzDui::CButtonUI			*m_pCancel;
	UINT						m_uRoomID;
	long int					m_dwUserID;
	int							m_iUpPeople;
	CSkinMgr                    m_skinmgr;

public:
	BzDui::CTextUI				*m_preulaNeed1;
	BzDui::CTextUI				*m_preulaNeed2;
	BzDui::CTextUI				*m_pneed;
	BzDui::CTextUI				*m_pmatchTimeCount;
	BzDui::CTextUI				*m_ptime;
};





#endif
/*******************************************************************************************************/