#ifndef __UIMARQUEETEXT_H__
#define __UIMARQUEETEXT_H__

#pragma once
#include <list>
#include <atlconv.h>
//#include "StdAfx.h"
#define lengthof(x) (sizeof(x)/sizeof(*x))
using namespace std;

namespace DuiLib 
{
	class UILIB_API CMarqueeTextUI : public CTextUI
	{
	public:
		static const UINT m_timer_ad = 1;//�������ƶ���ʱ��

		CMarqueeTextUI()
		{
			m_ad_time = 20;//�ƶ�Ƶ��
			m_list_max = 10;//��׼��list�������
			m_ListCString_marquee.clear();
			m_bStop = false;
			m_dwHotTextColor = 0x0000ff00;
		}

		~CMarqueeTextUI()
		{
			m_pManager->KillTimer(this, m_timer_ad);
			m_ListCString_marquee.clear();
		}

		virtual void SetVisible(bool bVisible = true)
		{
			CTextUI::SetVisible(bVisible);
			if (!bVisible)
			{
				m_pManager->KillTimer(this, m_timer_ad);
			}
			else
			{
				m_pManager->KillTimer(this, m_timer_ad);
				m_pManager->SetTimer(this, m_timer_ad, m_ad_time);
			}
		}

		void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue)
		{
			if ( _tcscmp(pstrName, _T("frequency")) == 0 )//�ƶ�Ƶ��
			{
				m_ad_time = _ttoi(pstrValue);
			}
			else if ( _tcscmp(pstrName, _T("listmax")) == 0 )//��׼��list�������
			{
				m_list_max = _ttoi(pstrValue);
			}
			else if ( _tcscmp(pstrName, _T("hottextcolor")) == 0 )//��긡������������ɫ
			{
				m_dwHotTextColor = _ttoi(pstrValue);
			}
			CTextUI::SetAttribute(pstrName, pstrValue);
		}

		virtual void DoEvent(TEventUI& event)
		{
			if( event.Type == UIEVENT_MOUSEMOVE)
			{
				if(PtInRect(&m_addrawrect, event.ptMouse))
				{
					Invalidate();
					m_pManager->SendNotify(this, DUI_MSGTYPE_MOUSEENTER, event.wParam, event.lParam);
				}
				else
				{
					Invalidate();
					m_pManager->SendNotify(this, DUI_MSGTYPE_MOUSELEAVE, event.wParam, event.lParam);
				}
			}
			if( event.Type == UIEVENT_MOUSEENTER )
			{
				if(PtInRect(&m_addrawrect, event.ptMouse))
				{
					Invalidate();
					m_pManager->SendNotify(this, DUI_MSGTYPE_MOUSEENTER, event.wParam, event.lParam);
				}
			}
			if( event.Type == UIEVENT_MOUSELEAVE )
			{
				Invalidate();
				m_pManager->SendNotify(this, DUI_MSGTYPE_MOUSELEAVE, event.wParam, event.lParam);
			}
			if(event.Type == UIEVENT_TIMER && event.wParam == m_timer_ad)
			{
				UINT step = 3;//����
				static UINT tag = 0;

				if(!m_bStop)
				{
					//if (m_addrawrect.left < (GetPos().right / 2 + (step / 2)) && m_addrawrect.left >= (GetPos().right / 2 - (step / 2)))//�պ��ڿͻ����м����ڵĲ����ڵ�֮�䣬ͣ��һ��ʱ��
					//{
					//	++tag;
					//}
					//else
					//{
					//	tag = 0;
					//}

					//tag = tag % 100;//ѭ����������Ϊͣ��ʱ�䣬 ���˾ͷ�ͨ��

					if (tag == 0)
					{
						m_addrawrect.left-=step;
						m_addrawrect.right=m_addrawrect.left+m_textLen;

						if(m_addrawrect.right<=GetPos().left)//����һ��
						{
							m_ListCString_marquee.pop_front();//�������ʾ����

							if(!m_ListCString_marquee.empty())
							{
								m_sText = m_ListCString_marquee.front();
								TCHAR ad[MAX_PATH] = {0};
								wsprintf(ad, "%s", m_sText);
								HDC hdc=::GetDC(NULL);
								//GetTextExtentPoint32(hdc, ad, lstrlen(ad), &m_adsize);
								TEXTMETRIC tm;
								GetTextMetrics(hdc,&tm);
								m_textLen = (tm.tmMaxCharWidth ) * lstrlen(ad);
							}
							else//û��������
							{
								m_sText.Empty();
								m_textLen = 0;
							}

							m_addrawrect=GetPos();
							m_addrawrect.left=GetPos().right;
							m_addrawrect.right=m_addrawrect.left+m_textLen;
						}
					}

					SetVisible((m_sText.IsEmpty()==true)?false:true);//�յľ�����
					Invalidate(); 
				}
			}
			CTextUI::DoEvent(event);
		}

		virtual LPVOID GetInterface(LPCTSTR pstrName)
		{
			if( _tcscmp(pstrName, DUI_CTR_MARQUEE_TEXT) == 0 ) return this;
			return NULL;
		}

		virtual LPCTSTR GetClass() const
		{
			return _T("MarqueeTextUI");
		}

		//�ռ����
		void CenterControl()//����Ǹ������ڵ�Ȼ���ã������ǳ�����Ƕ���򣬾�û�б�Ҫ��
		{
			if (this->GetParent())
			{
				RECT rcpos;
				rcpos.left = (GetParent()->GetFixedWidth()-m_cxyFixed.cx)/2;
				rcpos.top = (GetParent()->GetFixedHeight()-m_cxyFixed.cy)/2;
				rcpos.right = rcpos.left + m_cxyFixed.cx;
				rcpos.bottom = rcpos.top + m_cxyFixed.cy;
				SetPos(rcpos);
			}
		}

		CDuiString InsertTalkMsg(TCHAR* szMsgBuf)
		{
			TCHAR* p = szMsgBuf;
			CDuiString strRet = "";
			CDuiString strImageTmp("");
			while(*p != 0)
			{
				if (*p == '/' 
					&& (*(p + 1) != 0 && *(p + 1) == ':')
					&& (*(p + 2) != 0 && ::isdigit(*(p + 2)))
					&& (*(p + 3) != 0 && ::isdigit(*(p + 3)))
					)
				{
					CDuiString strNum;
					strNum.Format(_T("%c%c"), *(p + 2), *(p + 3));
					strImageTmp.Format("<i Face/%d.gif 1 0>", atoi(strNum));
					strRet += strImageTmp;
					p += 4;
					continue;
				}
				else
				{
					strRet += *p;
				}
				p++;
			}

			return strRet;
		}

		CDuiString InsertSysMsg(TCHAR* szMessage)
		{
			char szGBuffer[512] = {0};
			char szTempBuffer[256] = {0};

			::strcat(szGBuffer,"<p 4>");

			szTempBuffer[0] = '\0';
			_stprintf(szTempBuffer,"<c %08x>%s</c>",0x00FF0000,szMessage);
			::strcat(szGBuffer,szTempBuffer);

			::strcat(szGBuffer,"</p>");

			return InsertTalkMsg(szGBuffer);
		}

		//����ˢ�������ƣ��ڿͻ��˴�С�����ı�ʱ��
		void Update_marquee()
		{
			if(m_sText.IsEmpty())
				return;

			TCHAR ad[MAX_PATH] = {0};
			wsprintf(ad, "%s", m_sText);
			HDC hdc=::GetDC(NULL);
			//GetTextExtentPoint32(hdc, ad, lstrlen(ad), &m_adsize);
			TEXTMETRIC tm;
			GetTextMetrics(hdc,&tm);
			m_textLen = (tm.tmMaxCharWidth ) * lstrlen(ad);

			m_addrawrect=GetPos();
			m_addrawrect.left=GetPos().right;
			m_addrawrect.right=m_addrawrect.left+m_textLen;

			m_pManager->KillTimer(this, m_timer_ad);
			//��������������
			m_pManager->SetTimer(this, m_timer_ad,m_ad_time);
		}

		void SetAd(TCHAR ad[])
		{
			if(m_ListCString_marquee.size() < m_list_max)
			{
				CDuiString str;
				if (m_bShowHtml)
				{
					str = InsertSysMsg(ad);
				}
				else
				{
					str = ad;
				}
				if(m_ListCString_marquee.empty())//��һ�����ӵ�������������ʾ�ַ������Ⱥ�����
				{
					m_sText = str;
					HDC hdc=::GetDC(NULL);
					//GetTextExtentPoint32(hdc, ad, lstrlen(ad), &m_adsize);
					TEXTMETRIC tm;
					GetTextMetrics(hdc,&tm);
					m_textLen = (tm.tmMaxCharWidth ) * lstrlen(ad);

					m_addrawrect=GetPos();
					m_addrawrect.left=GetPos().right;
					m_addrawrect.right=m_addrawrect.left+m_textLen;
					m_pManager->KillTimer(this, m_timer_ad);
					//����������
					m_pManager->SetTimer(this, m_timer_ad,m_ad_time);
				}
				m_ListCString_marquee.push_back(str);
			}
		}

		void PaintText(HDC hDC)
		{
			if( m_sText.IsEmpty() ) {
				m_nLinks = 0;
				return;
			}

			if( m_dwTextColor == 0 ) m_dwTextColor = m_pManager->GetDefaultFontColor();
			if( m_dwDisabledTextColor == 0 ) m_dwDisabledTextColor = m_pManager->GetDefaultDisabledColor();

			if( m_sText.IsEmpty() ) 
			{
				return;
			}

			m_nLinks = lengthof(m_rcLinks);
			RECT rc = m_rcItem;

			if( IsEnabled() ) {
				if( m_bShowHtml )
					CRenderEngine::DrawHtmlText(hDC, m_pManager, /*rc*/m_addrawrect, m_sText, m_bStop==false?m_dwTextColor:m_dwHotTextColor, \
					m_rcLinks, m_sLinks, m_nLinks, m_uTextStyle);
				else
					CRenderEngine::DrawText(hDC, m_pManager, /*rc*/m_addrawrect, m_sText, m_bStop==false?m_dwTextColor:m_dwHotTextColor, \
					m_iFont, m_uTextStyle);
			}
			else {
				if( m_bShowHtml )
					CRenderEngine::DrawHtmlText(hDC, m_pManager, /*rc*/m_addrawrect, m_sText, m_dwDisabledTextColor, \
					m_rcLinks, m_sLinks, m_nLinks, m_uTextStyle);
				else
					CRenderEngine::DrawText(hDC, m_pManager, /*rc*/m_addrawrect, m_sText, m_dwDisabledTextColor, \
					m_iFont, m_uTextStyle);
			}
			if (GetTextStyle() & DT_CALCRECT && m_bSendNotify)
			{
				m_pManager->SendNotify(this, DUI_MSGTYPE_SETTEXT, WPARAM(rc.bottom-rc.top), LPARAM(rc.right-rc.left));
				m_bSendNotify = false;
			}
		}

		void SetStop(bool bstop){m_bStop = bstop;}

	private://������
		list<CDuiString>	m_ListCString_marquee;		//�洢����������
		RECT				m_addrawrect;//���������ʾ����Ч����

		UINT				m_ad_time;//�ƶ�Ƶ��
		UINT				m_list_max;//��׼��list�������

		bool				m_bStop;//��ͣ
		DWORD				m_dwHotTextColor;//�����������ʱ����ʾ��ɫ
		long				m_textLen;//�ַ������ش�С
	};
} // namespace DuiLib

#endif // __UIANIMATION_H__