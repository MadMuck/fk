#ifndef __UIANIMATION_H__
#define __UIANIMATION_H__

#pragma once

namespace DuiLib 
{
	//�����ؼ� �̳��ڰ�ť�ؼ�
	class UILIB_API CAnimationControlUI : public /*CControlUI*/CButtonUI
	{
	public:
		enum { LOADING_TIMERID = 1 };

		CAnimationControlUI()
			:m_uRowNums(1), m_uColNums(1), m_uElapse(50), m_iPicIndex(0)
		{
			m_strAnimationBk = _T("animationbk.png");
			m_bMouseEnter = false;
			m_bStop = false;
		}

		~CAnimationControlUI(){}

		virtual void SetVisible(bool bVisible = true)
		{
			CButtonUI::SetVisible(bVisible);
			if (!bVisible)
			{
				m_pManager->KillTimer(this, LOADING_TIMERID);
			}
			else
			{
				m_pManager->KillTimer(this, LOADING_TIMERID);
				m_iPicIndex = 0;
				if (!m_bStop)
				{
					m_pManager->SetTimer(this, LOADING_TIMERID, m_uElapse);
				}
			}
		}

		//����ʱ��
		void SetElapse(UINT uElapse, bool bShow)
		{
			m_uElapse = uElapse;
			m_pManager->KillTimer(this, LOADING_TIMERID);
			m_iPicIndex = 0;
			if (bShow)
			{
				m_pManager->SetTimer(this, LOADING_TIMERID, m_uElapse);
			}
		}

		//�Ƿ���ͣ����
		void Stop()
		{
			m_bStop = true;
			m_pManager->KillTimer(this, LOADING_TIMERID);
			m_iPicIndex = 0;
		}
		//��������
		void Start()
		{
			m_bStop = false;
			m_pManager->KillTimer(this, LOADING_TIMERID);
			m_iPicIndex = 0;
			m_pManager->SetTimer(this, LOADING_TIMERID, m_uElapse);
		}

		bool IsStop(){return m_bStop;}

		void SetAttribute(LPCTSTR pstrName, LPCTSTR pstrValue)
		{
			if ( _tcscmp(pstrName, _T("rownums")) == 0 )//����
			{
				m_uRowNums = _ttoi(pstrValue);
			}
			else if ( _tcscmp(pstrName, _T("colnums")) == 0 )//����
			{
				m_uColNums = _ttoi(pstrValue);
			}
			else if ( _tcscmp(pstrName, _T("elapse")) == 0 )//ʱ����
			{
				m_uElapse = _ttoi(pstrValue);
			}
			else if ( _tcscmp(pstrName, _T("animationbk")) == 0 )//ͼƬ����
			{
				m_strAnimationBk = pstrValue;
			}
			else if ( _tcscmp(pstrName, _T("picwidth")) == 0 )//ÿһ֡ͼƬ��ʵ�ʴ�С
			{
				m_uiWidth = _ttoi(pstrValue);
			}
			else if ( _tcscmp(pstrName, _T("picheight")) == 0 )//ÿһ֡ͼƬ��ʵ�ʴ�С
			{
				m_uiHeight = _ttoi(pstrValue);
			}
			CButtonUI::SetAttribute(pstrName, pstrValue);
		}

		virtual void DoEvent(TEventUI& event)
		{
			if( event.Type == UIEVENT_MOUSEENTER )
			{
				m_bMouseEnter = true;
			}
			if( event.Type == UIEVENT_MOUSELEAVE )
			{
				m_bMouseEnter = false;
			}
			if(event.Type == UIEVENT_TIMER && event.wParam == LOADING_TIMERID)
			{
				if (!m_bMouseEnter && !m_bStop)//�û��Ż�����ͼƬ
				{
					UINT nRowIndex = m_iPicIndex / m_uColNums;
					UINT nColIndex = m_iPicIndex % m_uColNums;

					UINT x = nColIndex*m_uiWidth;
					UINT y = nRowIndex*m_uiHeight;

					CDuiString str;
					str.Format("file='");
					str += m_strAnimationBk;
					CDuiString str2;
					str2.Format("' source='%u,%u,%u,%u'", x, y, x+m_uiWidth, y+m_uiHeight);
					str += str2;
					this->SetBkImage(str);

					++m_iPicIndex;
					m_iPicIndex%=(m_uRowNums*m_uColNums);
				}

			}
			CButtonUI::DoEvent(event);
		}

		void InitAnimationBk(CDuiString animationbk)
		{
			m_strAnimationBk = animationbk;
		}

		CDuiString GetAnimationBk()
		{
			return m_strAnimationBk;
		}

		virtual LPVOID GetInterface(LPCTSTR pstrName)
		{
			if( _tcscmp(pstrName, DUI_CTR_ANIMATION) == 0 ) return this;
			return NULL;
		}

		virtual LPCTSTR GetClass() const
		{
			return _T("AnimationUI");
		}

		//�ռ����
		void CenterControl()//����Ǹ������ڵ�Ȼ���ã������ǳ�����Ƕ���򣬾�û�б�Ҫ��
		{
			if (this->GetParent())
			{
				RECT rcpos;
				rcpos.left = (GetParent()->GetFixedWidth()-m_cxyFixed.cx)/2;
				rcpos.top = (GetParent()->GetFixedHeight()-m_cxyFixed.cy)/2;
				rcpos.right = rcpos.left + m_cxyFixed.cx;
				rcpos.bottom = rcpos.top + m_cxyFixed.cy;
				SetPos(rcpos);
			}
		}
		//PaintBkImage() �� PaintStatusImag()��һ���õ�
		virtual void PaintBkImage(HDC hDC)
		{
			if (!m_bMouseEnter && !m_bStop)//�û��Ż�����ͼƬ
			{
				CButtonUI::PaintBkImage(hDC);
			}
		}

		virtual void PaintStatusImage(HDC hDC)
		{
			if (m_bMouseEnter || m_bStop)//���û��ͻ���ť��ӦͼƬ
			{
				CButtonUI::PaintStatusImage(hDC);
			}
		}

	private://������
		UINT m_uRowNums;	//ͼƬ�����˶�����ͼƬ
		UINT m_uColNums;
		UINT m_uElapse;
		UINT m_iPicIndex;
		UINT m_uiWidth;
		UINT m_uiHeight;
		CDuiString m_strAnimationBk;//��ȡͼƬ·��
		bool m_bMouseEnter;//����ڿؼ���
		bool m_bStop;//��ͣ����
	};
} // namespace DuiLib

#endif // __UIANIMATION_H__