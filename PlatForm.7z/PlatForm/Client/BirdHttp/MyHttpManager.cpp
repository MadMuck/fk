#include "StdAfx.h"
#include "MyHttpManager.h"
#include "birdhttp.h"
#include "unzip.h"
#include "CommonMsg.h"

#define DOWN_MAX_VALUE						40	//��װһ���ļ��Ĳ����Ϊ���غͽ�ѹ���ڴ˶������ز�����ռ����Ϊ40%
#define UNZIP_MAX_VALUE						59	//��ѹ���ļ�ռ59%��ʣ�µ�1%���ں������������翽���ļ���
#define HALL_DOWM_MAX_VALUE					97	//���ؽ���ռ�������ȵ�97��ʣ�µ�����ת�������ļ�

//�Ӵ�����������Ϸ�ļ��е��ļ�
const std::string str_copy_array[] = {_T("BZAnimaPlay.dll"), _T("FCRTL.dll"), _T("fmodex.dll"), _T("Frame.dll"), _T("Graph.dll"), 
									  _T("irrKlang.dll"), _T("UI.dll"), _T("D3dx9d_43.dll")};

//���³������������ļ���Ҫ���浽����Ŀ¼
const std::string str_special_files[] = {_T("BirdHttp.dll"), _T("DuiLib.dll"), _T("Update.exe"), _T("mfc100.dll"), _T("msvcp100.dll"), _T("msvcr100.dll")};

bool FolderExists(CString s)   
{   
	DWORD attr;
	attr = GetFileAttributes(s);    
	return (attr != (DWORD)(-1) ) &&   
		( attr & FILE_ATTRIBUTE_DIRECTORY);    
} 

bool CreateMuliteDirectory(CString P)
{   
	int len=P.GetLength();   
	if ( len <2 ) return false;    
	if('\\'==P[len-1])  
	{  
		P=P.Left(len-1);  
		len=P.GetLength();  
	}  
	if ( len <=0 ) return false;  
	if (len <=3)   
	{
		if (FolderExists(P))return true;  
		else return false;   
	}
	if (FolderExists(P))return true;  
	CString Parent;  
	Parent=P.Left(P.ReverseFind('\\') );   
	if(Parent.GetLength()<=0)return false;    
	BOOL Ret=CreateMuliteDirectory(Parent);    
	if(Ret)    
	{   
		SECURITY_ATTRIBUTES sa;   
		sa.nLength=sizeof(SECURITY_ATTRIBUTES);   
		sa.lpSecurityDescriptor=NULL;   
		sa.bInheritHandle=0;   
		Ret=(CreateDirectory(P,&sa)==TRUE);   
		return Ret==TRUE?true:false;   
	}
	else
		return false;   
}

bool FileIsSpecail(LPCTSTR strFile)
{
	int iCount = sizeof(str_special_files)/sizeof(str_special_files[0]);
	for (int i=0; i!=iCount; ++i)
	{
		if (!strcmp(strFile, str_special_files[i].c_str()))
		{
			return true;
		}
	}
	return false;
}

void MyDebugString(LPCTSTR lpPre, LPCTSTR lpFormat, ...)
{
	CString strMsg;
	va_list pArg;
	va_start(pArg,lpFormat);
	strMsg.FormatV(lpFormat, pArg);
	va_end(pArg);

}


CMyHttpManager::CMyHttpManager(void)
{
	m_iDownType = -1;
	m_mapName.clear();
	m_bDownloading = false;
	m_wait_download.clear();
	m_strMainUrl.Empty();	
	m_hThread = INVALID_HANDLE_VALUE;
	m_dwTotalSize = 0;
	m_dwDownLoadSize = 0;
	m_iCurSize = 0;
	m_listInstallFinish.clear();
	m_listDownLoadStruct.clear();
	m_listInstallingStruct.clear();
	memset(m_strDownLoadFileName, 0, sizeof(m_strDownLoadFileName));
}


CMyHttpManager::~CMyHttpManager(void)
{
	for (auto iter = m_listInstallFinish.begin(); iter != m_listInstallFinish.end(); iter++)
		delete *iter;
	m_listInstallFinish.clear();
	for (auto iter = m_listDownLoadStruct.begin(); iter != m_listDownLoadStruct.end(); iter++)
		delete *iter;
	m_listDownLoadStruct.clear();
	for (auto iter = m_listInstallingStruct.begin(); iter != m_listInstallingStruct.end(); iter++)
		delete *iter;
	m_listInstallingStruct.clear();
}

CString CMyHttpManager::GetAppPath()
{
	CString strPath;
	GetModuleFileName(NULL, strPath.GetBuffer(MAX_PATH), MAX_PATH);
	strPath.ReleaseBuffer();
	int iIndex = strPath.ReverseFind('\\');
	if (0 < iIndex)
	{
		strPath = strPath.Mid(0, iIndex);
	}
	return strPath;
}

//����HTTP������ɺ����ý�����
void CMyHttpManager::OnAfterRequestSend (FCHttpRequest& rTask)
{
	if (0 == m_iDownType)
	{
		OnGameAfterRequestSend(rTask);
	}
	else if (1 == m_iDownType)
	{
		OnHallAfterRequestSend(rTask);
	}	
}

//�����ļ���ɺ󣬽��ļ����浽����
void CMyHttpManager::OnAfterRequestFinish (FCHttpRequest& rTask)
{
	if (0 == m_iDownType)
	{
		OnGameAfterRequestFinish(rTask);
	}
	else
	{
		OnHallAfterRequestFinish(rTask);
	}	
}

void CMyHttpManager::OnGameAfterRequestSend(FCHttpRequest& rTask)
{
	//�ҵ���Ӧ�������ļ���Ϣ
	_S_INSTALL_GAME *pInstall = m_mapName[rTask.GetTaskID()];
	if (!pInstall)
	{
		return;
	}

	_E_RSULT e_r = OP_OK;

	const HTTP_RESPONSE_INFO   & resp = rTask.GetResponseInfo() ;
	ComNameInfo *pNameInfo = pInstall->pNameInfo;
	if (resp.m_status_code == 0)
	{
		MAP_ITER iter = Find_Map_Item(pInstall->pNameInfo);
		if (iter != m_mapName.end())
		{
			delete iter->second;
			iter->second = NULL;
			m_mapName.erase(iter);
		}
		DeleteRequest(rTask.GetTaskID());
		e_r = OP_FAILD;
	}

	//֪ͨ���������ļ�����������
	PostMessage(m_hWnd, WM_HALL_INSTALL_RES, (WPARAM)pNameInfo, (LPARAM)e_r);
}

void CMyHttpManager::OnGameAfterRequestFinish(FCHttpRequest& rTask)
{
	const HTTP_RESPONSE_INFO &r = rTask.GetResponseInfo();
	_E_RSULT e_r = OP_FAILD;
	if (r.m_status_code == HTTP_STATUS_OK)
	{
		if (r.m_content_length)
		{
			//��ֹ���ع����������жϵ������ݴ���
			if (r.m_content_length == rTask.GetTotalReceiveByte())
			{
				e_r = OP_OK;
			}
		}
		else
		{
			//���ش�СΪ0��˵�����ص����ݿ�������ҳ��HTML,ASP������
			if (r.m_final_read_result)
			{
				e_r = OP_OK;
			}
		}
	}

	MyDebugString("http", "OnGameAfterRequestFinish:e_r=%d, r.m_status_code=%d, r.m_content_length=%d", e_r, r.m_status_code, r.m_content_length);
	_S_INSTALL_GAME *pInstall = m_mapName[rTask.GetTaskID()];
	if (!pInstall)
	{
		return;
	}
	ComNameInfo *pNameInfo = pInstall->pNameInfo;
	if (OP_OK != e_r)
	{
		//֪ͨ����������ʧ��
		PostMessage(m_hWnd, WM_HALL_INSTALL_RES, (WPARAM)pNameInfo, (LPARAM)e_r);
		if (m_wait_download.empty())
		{
			m_bDownloading = false;
		}
		if (m_mapName.empty())
		{//֪ͨ������װ�����ѽ���
			PostMessage(m_hWnd, WM_HALL_INSTALL_FINISH, 0, 0);
		}
		return;
	}

	//��ȡ�����������
	rTask.PopReceived(pInstall->str_recv_data);

	if (INVALID_HANDLE_VALUE == m_hThread)
	{
		unsigned int uiThreadID = 0;
		m_hThread = (HANDLE)_beginthreadex(NULL, 0, Thread_Install, this, 0, &uiThreadID);
	}

	//������һ���ļ�
	if (!m_wait_download.empty())
	{
		CString strFile;
		ComNameInfo *pTempNameInfo = m_wait_download.front();
		m_wait_download.pop_front();
		strFile.Format(_T("%s/%d.zip"), m_strMainUrl, pTempNameInfo->uNameID);
		int iIndex = AddDownload(strFile);

		if (ID_TASK_AND_TIMER_START <= iIndex)
		{
			_S_INSTALL_GAME *pIn = new _S_INSTALL_GAME;
			pIn->pNameInfo = pTempNameInfo;
			m_mapName.insert(pair<int, _S_INSTALL_GAME*>(iIndex, pIn));
		}
	}
	else
	{//�������޵ȴ��ߣ�����������״̬
		m_bDownloading = false;	
		MyDebugString("http", "OnGameAfterRequestFinish3:e_r=%d", e_r);
	}
}

void CMyHttpManager::OnHallAfterRequestSend(FCHttpRequest& rTask)
{
	_E_RSULT e_r = OP_OK;
	const HTTP_RESPONSE_INFO   & resp = rTask.GetResponseInfo() ;
	if (resp.m_status_code == 0)
	{//�޷����ӷ�����
		DeleteRequest(rTask.GetTaskID());
		e_r = OP_FAILD;
	}
	m_iCurSize = 0;//���õ�ǰ�ļ����س���
	//֪ͨ���������ļ�����������

	DownLoadStruct* dwStruct = new DownLoadStruct;
	memset(dwStruct, 0, sizeof(DownLoadStruct));
	if (strcmp(m_strDownLoadFileName, "��Ϸ����") == 0)
	{
		dwStruct->nLen = resp.m_content_length;
		m_dwDownLoadSize = resp.m_content_length; // �ļ�����
		dwStruct->nErrcode = e_r;
		strcpy(dwStruct->strFileName, "��Ϸ����");
	}

	dwStruct->nErrcode = e_r;
	strcpy(dwStruct->strFileName, m_strDownLoadFileName);
	m_listDownLoadStruct.push_back(dwStruct);
	PostMessage(m_hWnd, WM_HALL_INSTALL_RES, resp.m_status_code, (LPARAM)(void*)(dwStruct));
}

void CMyHttpManager::OnHallAfterRequestFinish(FCHttpRequest& rTask)
{
	const HTTP_RESPONSE_INFO &r = rTask.GetResponseInfo();
	_E_RSULT e_r = OP_FAILD;
	if (r.m_status_code == HTTP_STATUS_OK)
	{
		if (r.m_content_length)
		{
			//��ֹ���ع����������жϵ������ݴ���
			if (r.m_content_length == rTask.GetTotalReceiveByte())
			{
				e_r = OP_OK;
			}
		}
		else
		{
			//���ش�СΪ0��˵�����ص����ݿ�������ҳ��HTML,ASP������
			if (r.m_final_read_result)
			{
				e_r = OP_OK;
			}
		}
	}

	if (OP_OK != e_r)
	{
		MyDebugString("http", "OnGameAfterRequestFinish:e_r=%d, r.m_status_code=%d, r.m_content_length=%d, rTask.GetURL()=%s", e_r, r.m_status_code, r.m_content_length, rTask.GetURL());
		//֪ͨ����������ʧ��

		DownLoadStruct* dwStruct = new DownLoadStruct;
		memset(dwStruct, 0, sizeof(DownLoadStruct));
		dwStruct->nErrcode = e_r;
		strcpy(dwStruct->strFileName, m_strDownLoadFileName);
		m_listDownLoadStruct.push_back(dwStruct);
		PostMessage(m_hWnd, WM_HALL_INSTALL_RES, r.m_status_code, (LPARAM)(void*)(dwStruct));
		m_main_wait_download.clear();
		m_bDownloading = false;
		return;
	}

	std::string str_recv_data;

	//��ȡ�����������
	rTask.PopReceived(str_recv_data);

	CString strUrl = rTask.GetURL();
	int iIndex = strUrl.Find(m_strMainUrl);
	//if (0 > iIndex)
	//{
	//	PostMessage(m_hWnd, WM_HALL_INSTALL_RES, r.m_status_code, (LPARAM)OP_FAILD);
	//	m_main_wait_download.clear();
	//	m_bDownloading = false;
	//	return;
	//}

	std::string str_file_name = strUrl.Mid(iIndex+m_strMainUrl.GetLength()+1);

	if (strcmp(str_file_name.c_str(), update_version) == 0) // �汾�ļ�����
	{
		// ����update_version����
		m_bDownloading = false;
		ParseFileContent(str_file_name, str_recv_data, PARSE_UPDATE_VERSION);
		return;
	}
	else if (strncmp(str_file_name.c_str(), update_download, strlen(update_download)) == 0)
	{
		// ���������ļ��������
		m_bDownloading = false;
		ParseFileContent(str_file_name, str_recv_data, PARSE_UPDATE_DOWNLOAD);
		return;
	}
	else
	{
		//str_file_name = strUrl.Mid(iIndex+m_strMainUrl.GetLength()+1 + 2);
		// ����Ѱ���ļ���
		char* pBuff = strUrl.GetBuffer();
		char szTempFile[128] = { 0x00 };
		for (int i = strUrl.GetLength(); i > 0; i--)
		{
			if (pBuff[i] == '/')
			{
				memcpy(szTempFile, pBuff + i + 1,strUrl.GetLength());
				str_file_name = std::move(std::string(szTempFile));
				break;
			}
		}

	}

	m_vecHallDownData.push_back(_S_HALL_DOWNLOAD_DATA(str_file_name, str_recv_data));
	
	m_dwDownLoadSize += str_recv_data.size();
	m_iCurSize = 0;//���õ�ǰ�ļ����س���

	//������һ���ļ�
	if (!m_main_wait_download.empty())
	{
		std::string strFile = m_main_wait_download.front();
		m_main_wait_download.pop_front();
		m_iCurTaskID = AddDownload(strFile.c_str(), false);
	}
	else
	{//�������޵ȴ��ߣ�����������״̬
		m_bDownloading = false;
		//if (m_dwDownLoadSize == m_dwTotalSize)
		//{
		//	//�����ݴ洢������
		//	unsigned int uiThreadID = 0;
		//	m_hThread = (HANDLE)_beginthreadex(NULL, 0, Thread_CopyFiles, this, 0, &uiThreadID);
		//}
		//else
		//{
		//	PostMessage(m_hWnd, WM_HALL_INSTALL_FINISH, 0, OP_FAILD);
		//}

		// ������ɣ������ļ�
		//	//�����ݴ洢������
		unsigned int uiThreadID = 0;
		m_hThread = (HANDLE)_beginthreadex(NULL, 0, Thread_CopyFiles, this, 0, &uiThreadID);


	}
}

bool CMyHttpManager::ParseFileContent(std::string& fileName, std::string& fileContent, Parse_Type type)
{
	// �����汾�ļ�����
	std::string::size_type nPos;
	std::vector<string> urls;
	urls.clear();
	do 
	{
		std::string tempStr;
		nPos = fileContent.find_first_of('\r\n');
		if (nPos != std::string::npos)
		{
			tempStr = fileContent.substr(0, nPos);
			fileContent = fileContent.substr(nPos + 2);
			urls.push_back(tempStr);
		}
	} while (nPos != std::string::npos);
	
	for (auto aIter = urls.begin(); aIter != urls.end(); aIter++)
	{
		auto nPos = aIter->find_first_of('=');
		if (nPos != std::string::npos)
		{
			auto filePos = aIter->find_last_of('/');
			if (filePos != std::string::npos)
			{
				std::string file = aIter->substr(filePos + 1);
				if (type == PARSE_UPDATE_VERSION) // ���ذ汾�ļ�
				{
					memset(m_strDownLoadFileName, 0, sizeof(m_strDownLoadFileName));
					strcpy(m_strDownLoadFileName, fileContent.c_str());
					m_iCurTaskID = AddDownloadEx(file.c_str(), 0);
				}
				else if (type == PARSE_UPDATE_DOWNLOAD) // �����ļ�
				{
					PostMessage(m_hWnd, WM_HALL_INSTALL_START, 0,(LPARAM)(void*)("��Ϸ����"));
					memset(m_strDownLoadFileName, 0, sizeof(m_strDownLoadFileName));
					strcpy(m_strDownLoadFileName, "��Ϸ����");
					m_iCurTaskID = AddDownload(aIter->substr(nPos + 1).c_str(), false);
				}
				return true;
			}
		}
	}

	m_strErrorMsg = "";
	m_strErrorMsg.Format("%s�ļ����ݴ�����������������ļ�����", fileName.c_str());
	PostMessage(m_hWnd, WM_HALL_INSTALL_PARSE_FAILED, 0, (LPARAM)(void*)(m_strErrorMsg.GetBuffer()));

	return false;
}

bool CMyHttpManager::AddDownloadEx(ComNameInfo *pNameInfo)
{
	m_iDownType = 0;	//��������������Ϸ
	//�жϸ��ļ��Ƿ��Ѿ�����
	MAP_ITER iter = Find_Map_Item(pNameInfo);	

	if (iter != m_mapName.end() && m_mapName.size() >0)	//���ļ����ڰ�װ�б���
	{
		return true;
	}
	
	//�ж�URL��ַ�Ƿ�Ϸ�
// 	if (!UrlIs(m_strMainUrl, URLIS_URL))
// 	{
// 		return false;
// 	}
	//������������ļ����򽫴���Ϸ���ӵ��ȴ�������
	if (m_bDownloading)
	{
		m_wait_download.push_back(pNameInfo);
		return true;
	}
	m_bDownloading = true;
	PostMessage(m_hWnd, WM_HALL_INSTALL_START, 0,0);
	CString strFile;
	strFile.Format(_T("%s/%d.zip"), m_strMainUrl, pNameInfo->uNameID);

	int iIndex = AddDownload(strFile);

	if (ID_TASK_AND_TIMER_START > iIndex)
	{
		return false;
	}
	//���氲װ��Ϣ
	_S_INSTALL_GAME *pInstall = new _S_INSTALL_GAME;
	pInstall->pNameInfo = pNameInfo;
	m_mapName.insert(pair<int, _S_INSTALL_GAME*>(iIndex, pInstall));


	return true;
}

bool CMyHttpManager::AddDownloadEx(LPCTSTR strFile, DWORD dwTotalSize)
{
	m_iDownType = 1;//���������ش���
	//�ж�URL��ַ�Ƿ�Ϸ�
	if (!UrlIs(m_strMainUrl, URLIS_URL))
	{
		return false;
	}
	CString strCombin = m_strMainUrl + "/" + strFile;
	//������������ļ����򽫴��ļ����ӵ��ȴ�������
	if (m_bDownloading)
	{
		m_main_wait_download.push_back(std::string(strCombin));
		return true;
	}
	m_dwTotalSize = dwTotalSize;
	m_bDownloading = true;
	PostMessage(m_hWnd, WM_HALL_INSTALL_START, 0,(LPARAM)(void*)(m_strDownLoadFileName));
	m_iCurTaskID = AddDownload(strCombin, false);

	return true;
}

bool CMyHttpManager::AddDownloadUpdateVersion(LPCTSTR strFile)
{
	m_iDownType = 1;//���������ش���
	//�ж�URL��ַ�Ƿ�Ϸ�
	if (!UrlIs(m_strMainUrl, URLIS_URL))
	{
		m_strErrorMsg = "";
		m_strErrorMsg = m_strMainUrl + "������Ч��URL��ַ";
		PostMessage(m_hWnd, WM_HALL_INSTALL_PARSE_FAILED, 0, (LPARAM)(void*)(m_strErrorMsg.GetBuffer()));
		return false;
	}
	CString strCombin = m_strMainUrl + "/" + strFile;
	//������������ļ����򽫴��ļ����ӵ��ȴ�������
	if (m_bDownloading)
	{
		m_main_wait_download.push_back(std::string(strCombin));
		return true;
	}

	if (strcmp(strFile, update_version) != 0) // ���UpdateVersion.txt�Բ���
	{
		m_strErrorMsg = "";
		m_strErrorMsg = "�ļ�������update_version.txt";
		PostMessage(m_hWnd, WM_HALL_INSTALL_PARSE_FAILED, 0, (LPARAM)(void*)(m_strErrorMsg.GetBuffer()));
		return false;
	}

	memset(m_strDownLoadFileName, 0, sizeof(m_strDownLoadFileName));
	strcpy(m_strDownLoadFileName, update_version);
	m_bDownloading = true;
	PostMessage(m_hWnd, WM_HALL_INSTALL_START, 0,(LPARAM)(void*)(update_version)); // ��װ��ʼ
	m_iCurTaskID = AddDownload(strCombin, false);

	return true;
}

void CMyHttpManager::GetDownLoadProcess()
{
	//if (0 == m_iDownType)
	//{
	//	//ѭ����ȡ��װ�ļ�����
	//	MAP_ITER iter = m_mapName.begin();
	//	_S_INSTALL_GAME *pInstall = NULL;
	//	for (; iter!=m_mapName.end(); ++iter)
	//	{
	//		pInstall = iter->second;
	//		if (!pInstall && pInstall->bStopInstall)
	//		{
	//			continue;
	//		}
	//		if (DOWN_MAX_VALUE >= pInstall->iCurPos)
	//		{
	//			FCHttpRequest *pTask = FindRequest(iter->first);
	//			if (!pTask)
	//			{
	//				continue;
	//			}
	//			int iRecived = pTask->GetTotalReceiveByte();
	//			int iTotalLen = pTask->GetResponseInfo().m_content_length ;
	//			//�����ļ�ռ������װ���ȵ�DOWN_MAX_VALUE
	//			pInstall->iCurPos = DOWN_MAX_VALUE*1.0*iRecived/iTotalLen;
	//		}
	//		//���Ͱ�װ���ȵ�������
	//		PostMessage(m_hWnd, WM_HALL_INSTALL_ING, (WPARAM)pInstall->pNameInfo, (LPARAM)pInstall->iCurPos);
	//	}
	//}
	//else
	//{
	//	FCHttpRequest *pTask = FindRequest(m_iCurTaskID);
	//	if (pTask)
	//	{
	//		m_iCurSize += pTask->GetTotalReceiveByte();
	//	}
	//	//���Ͱ�װ���ȵ�������
	//	int iCurPos = HALL_DOWM_MAX_VALUE*1.0*(m_iCurSize+m_dwDownLoadSize)/m_dwTotalSize;
	//	PostMessage(m_hWnd, WM_HALL_INSTALL_ING, 0, (LPARAM)iCurPos);
	//}

	FCHttpRequest *pTask = FindRequest(m_iCurTaskID);
	if (!pTask)
	{
		return ;
	}

	int living_ms = pTask->GetRunningTime();
	long iRecived = pTask->GetTotalReceiveByte()/1024 ;
	long iTotalLen = pTask->GetResponseInfo().m_content_length/1024 ;

	auto iter = find_if(m_listInstallingStruct.begin(), m_listInstallingStruct.end(), [=](InstallingStruct* obj){ return strcmp(obj->strFileName, m_strDownLoadFileName) == 0;});
	if (iter == m_listInstallingStruct.end())
	{
		InstallingStruct* nowProcess = new InstallingStruct;
		memset(nowProcess, 0, sizeof(InstallingStruct));
		strcpy(nowProcess->strFileName, m_strDownLoadFileName);
		nowProcess->fSpeed = iRecived*1000.f/living_ms;
		nowProcess->uiProgress = iRecived * 100 / iTotalLen;
		nowProcess->nFileSize = iTotalLen;
		m_listInstallingStruct.push_back(nowProcess);
		iter = m_listInstallingStruct.begin();
	}
	else
	{
		strcpy((*iter)->strFileName, m_strDownLoadFileName);
		(*iter)->fSpeed = iRecived*1000.f/living_ms;
		(*iter)->uiProgress = iRecived * 100 / iTotalLen; 
		(*iter)->nFileSize = iTotalLen;
	}

	PostMessage(m_hWnd, WM_HALL_INSTALL_ING, 0, (LPARAM)(void*)(*iter));

}

bool CMyHttpManager::StopInstall(ComNameInfo *pNameInfo)
{
	if (!pNameInfo)
	{
		return true;
	}
	MAP_ITER iter = Find_Map_Item(pNameInfo);
	if (iter == m_mapName.end())
	{
		return true;
	}
	//����ȡ����װ��־
	iter->second->bStopInstall = true;
	return true;
}

void CMyHttpManager::Install(char *zipbuf, unsigned int ziplen, _S_INSTALL_GAME *pInstall)
{
	CString sdp;
	if (!zipbuf || 0 >= ziplen || !pInstall)
	{
		return;
	}
	//��ѹ���ļ�
	HZIP hz = OpenZip(zipbuf, ziplen, 0);
	ZIPENTRY ze; 

	//��ȡѹ�������ļ�����
	GetZipItem(hz,-1,&ze);
	int numitems=ze.index;
	ZRESULT zr;
	for (int i=0; i!=numitems&&!pInstall->bStopInstall; ++i)
	{
		zr = GetZipItem(hz, i, &ze);
		if (ZE_OK != zr)
		{
			break; //û�и����ļ���
		}
		//��ѹ��i���ļ�
		zr = UnzipItem(hz, i, ze.name);
		//���������Ͱ�װ����(��װ֮ǰ�����أ������ص���ĿҲҪ���ȥ)
		pInstall->iCurPos = (UNZIP_MAX_VALUE*1.0*(i+1)/numitems) + DOWN_MAX_VALUE;

		PostMessage(m_hWnd, WM_HALL_INSTALL_ING, (WPARAM)pInstall->pNameInfo, (LPARAM)pInstall->iCurPos);
	}
	TCHAR strTemp[MAX_PATH];
	int copynums = sizeof(str_copy_array) / sizeof(str_copy_array[0]);
	for (int i=0; i!=copynums; ++i)
	{//�����ļ�
		sprintf_s(strTemp, MAX_PATH, _T(".\\%d\\%s"), pInstall->pNameInfo->uNameID, str_copy_array[i].c_str());
		CopyFile(str_copy_array[i].c_str(), strTemp, FALSE);
	}
	pInstall->iCurPos = 100;

	PostMessage(m_hWnd, WM_HALL_INSTALL_ING, (WPARAM)pInstall->pNameInfo, (LPARAM)pInstall->iCurPos);
	pInstall->bStopInstall = true;
	CloseZip(hz);
}

unsigned int __stdcall CMyHttpManager::Thread_Install(LPVOID lparam)
{
	CMyHttpManager *pHttp = (CMyHttpManager*)lparam;
	_S_INSTALL_GAME *pInstall = NULL;
	MAP_ITER iter = pHttp->m_mapName.begin();
	std::string receive_data;	
	while (1)
	{
		iter = pHttp->m_mapName.begin();
		for (; iter!=pHttp->m_mapName.end(); ++iter)
		{
			receive_data = iter->second->str_recv_data;
			if (!receive_data.empty() && !iter->second->bStopInstall)
			{
				//��ѹ�ļ�	
				pHttp->Install((char*)receive_data.c_str(), (unsigned int)receive_data.size(), iter->second);				
			}
			if (iter->second->bStopInstall)
			{
				delete iter->second;
				iter->second = NULL;
				pHttp->m_mapName.erase(iter);
			}
		}
		if (pHttp->m_mapName.empty())	//֪ͨ������װ�����ѽ���
		{
			PostMessage(pHttp->m_hWnd, WM_HALL_INSTALL_FINISH, 0, 0);
			break;
		}
	}
	pHttp->m_hThread = INVALID_HANDLE_VALUE;
	return 0;
}

unsigned int __stdcall CMyHttpManager::Thread_CopyFiles(LPVOID lparam)
{
	CMyHttpManager *pHttp = (CMyHttpManager*)lparam;
	CString strRoot = GetAppPath();
	CString strPath;
	vector<_S_HALL_DOWNLOAD_DATA>::iterator iter = pHttp->m_vecHallDownData.begin();
	_E_RSULT iErrorFlag = OP_OK;
	int iIndex = 0;
	CString strDir, strPre, strBat;
	static int iHaveSpecial = 0;
	std::string fileName = "";
	while (iter != pHttp->m_vecHallDownData.end())
	{
		if (FileIsSpecail(iter->m_strFileName.c_str()))
		{//���ļ���Update.exe�������ļ�����Ҫ�洢����ʱ�ļ���
			strPath.Format(_T("%s\\temp"), strRoot);
			if (CreateDirectory(strPath, NULL))
			{
				SetFileAttributes(strPath, FILE_ATTRIBUTE_HIDDEN ); //����
			}
			strBat.Format(_T("%s\\hn.bat"),strPath);
			strPath.Format(_T("%s\\%s"), strPath, iter->m_strFileName.c_str());
			
			if (0 == iHaveSpecial)
			{
				DeleteFile(strBat);
				iHaveSpecial = 1;
			}

			//����BAT�ļ�
			HANDLE hFile = CreateFile(strBat,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
			if (hFile != INVALID_HANDLE_VALUE)
			{
				DWORD dwHigh;
				DWORD dwPos = GetFileSize(hFile,&dwHigh);
				SetFilePointer(hFile,dwPos,0,FILE_BEGIN);
				DWORD dwWritten;
				char sz[MAX_PATH];
				sprintf_s(sz, MAX_PATH, _T("copy \".\\temp\\%s\" \"%s\"\r\n"), iter->m_strFileName.c_str(), iter->m_strFileName.c_str());
				WriteFile(hFile,sz,lstrlen(sz),&dwWritten,NULL);
				CloseHandle(hFile);
			}
		}
		else
		{
			strPath.Format(_T("%s\\%s"), strRoot, iter->m_strFileName.c_str());
			//�ж�Ŀ¼�Ƿ����
			fileName = iter->m_strFileName;
			iIndex = strPath.ReverseFind('\\');
			if (0 >= iIndex)
			{
				iErrorFlag = OP_FAILD;
				break;
			}
			strDir = strPath.Left(iIndex);
			if (strDir != strPre)
			{
				if (!CreateMuliteDirectory(strDir))
				{
					MyDebugString("http", "����Ŀ¼ʧ��-%s", strDir);
					iErrorFlag = OP_FAILD;
					break;
				}
				strPre = strDir;
			}
		}

		HANDLE   f = CreateFile(strPath, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL) ;
		if (f != INVALID_HANDLE_VALUE)
		{
			DWORD   nWrite ;
			::WriteFile(f, iter->m_strRecvData.c_str(), iter->m_strRecvData.size(), &nWrite, NULL) ;			
			CloseHandle(f);
			if (((int)nWrite != iter->m_strRecvData.size()))
			{//д���ļ�ʧ��
				MyDebugString("http", "д���ļ�ʧ��%d--%s", GetLastError(), strPath);
				iErrorFlag = OP_FAILD;
				break;
			}
		}
		else
		{
			MyDebugString("http", "�����ļ�ʧ��%d--%s", GetLastError(), strPath);
			iErrorFlag = OP_FAILD;
			break;
		}
		++iter;
	}
	_S_HALL_INSTALL_FINISH_DATA* data = new _S_HALL_INSTALL_FINISH_DATA;
	memset(data, 0, sizeof(_S_HALL_INSTALL_FINISH_DATA));
	data->_ret = (int)iErrorFlag;
	strncpy(data->strFileName, fileName.c_str(), fileName.size());
	pHttp->m_listInstallFinish.push_back(data);
	PostMessage(pHttp->m_hWnd, WM_HALL_INSTALL_FINISH, 0, LPARAM((void*)(data)));
	return 0;
}

MAP_ITER CMyHttpManager::Find_Map_Item(ComNameInfo *pNameInfo)
{
	MAP_ITER iter = m_mapName.end();
	if (!pNameInfo)
	{
		return iter;
	}
	iter = std::find_if(m_mapName.begin(), m_mapName.end(), map_value_finder(pNameInfo));
	return iter;
}