#pragma once

#include "http_request_manager.h"
#include "md5.h"
#include "file.h"
#include "comstruct.h"
#include <map>
#include <algorithm>
#include <list>
using namespace std;

const char update_version[20] = "update_version.txt"; // �汾�ļ�
const char update_download[20] = "download"; // �����ļ�txt

struct _S_INSTALL_GAME
{
	ComNameInfo *pNameInfo;		//��Ϸ��־
	std::string str_recv_data;	//���ص�����
	int			iCurPos;		//��ǰ��װ����0-100
	bool		bStopInstall;	//�Ƿ�ֹͣ��װ
	_S_INSTALL_GAME()
	{
		pNameInfo = NULL;
		str_recv_data.clear();
		iCurPos = 0;
		bStopInstall = false;
	}
};

struct _S_HALL_DOWNLOAD_DATA
{
	_S_HALL_DOWNLOAD_DATA(std::string strFileName, std::string strRecvData):
		m_strFileName(strFileName), m_strRecvData(strRecvData)
	{
	}
	std::string m_strFileName;	//�ļ���
	std::string m_strRecvData;	//�ļ�����
};

struct _S_HALL_INSTALL_FINISH_DATA
{
	int _ret;
	char     strFileName[128];
};

struct DownLoadStruct
{
	char strFileName[128]; // �ļ���
	int nLen; // �ļ�����
	int nErrcode; // �������
};

struct InstallingStruct // �������ص��ļ�
{
	char strFileName[128]; // �ļ���
	float	fSpeed;		//�����ٶ�
	int	 uiProgress;		//���ؽ���
	long nFileSize; // �ļ���С
};


//����map���Һ���
class map_value_finder
{
public:
	map_value_finder(const ComNameInfo *pNameInfo):m_pNameInfo(pNameInfo){}
	bool operator ()(const std::map<int, _S_INSTALL_GAME*>::value_type &pair)
	{
		ComNameInfo *pNameInfo = pair.second->pNameInfo;
		if (NULL == m_pNameInfo)
		{
			return false;
		}
		if (m_pNameInfo->uNameID == pNameInfo->uNameID)
		{
			return true;
		}
		return false;
	}
private:
	const ComNameInfo *m_pNameInfo;                    
};


typedef map<int, _S_INSTALL_GAME*>::iterator MAP_ITER;

class CMyHttpManager : public FCHttpRequestManager
{
public:
	CMyHttpManager(void);
	~CMyHttpManager(void);

private:
	enum Parse_Type
	{
		PARSE_UPDATE_VERSION,
		PARSE_UPDATE_DOWNLOAD
	};

private:
	virtual void OnAfterRequestSend (FCHttpRequest& rTask);
	virtual void OnAfterRequestFinish (FCHttpRequest& rTask);
	void OnGameAfterRequestSend (FCHttpRequest& rTask);
	void OnGameAfterRequestFinish (FCHttpRequest& rTask);
	void OnHallAfterRequestSend (FCHttpRequest& rTask);
	void OnHallAfterRequestFinish (FCHttpRequest& rTask);
	void Install(char *zipbuf, unsigned int ziplen, _S_INSTALL_GAME *pInstall);

	bool ParseFileContent(std::string& fileName, std::string& fileContent, Parse_Type type);

public:
	bool AddDownloadEx(ComNameInfo *pNameInfo);
	bool AddDownloadEx(LPCTSTR strFile, DWORD dwTotalSize);
	bool AddDownloadUpdateVersion(LPCTSTR strFile); // ���ذ汾�ļ�
	static CString GetAppPath();
	void Initial(HWND hWnd, LPCTSTR sMainUrl)	{ m_hWnd = hWnd;	m_strMainUrl = sMainUrl;	}
	void GetDownLoadProcess();
	bool StopInstall(ComNameInfo *pNameInfo);
	static unsigned int __stdcall Thread_Install(LPVOID lparam);
	static unsigned int __stdcall Thread_CopyFiles(LPVOID lparam);
	MAP_ITER Find_Map_Item(ComNameInfo *pNameInfo);

private:
	map<int, _S_INSTALL_GAME*> m_mapName;				//�������ص�����
	vector<_S_HALL_DOWNLOAD_DATA> m_vecHallDownData;	//��������ʱ������ļ�����
	HWND m_hWnd;
	std::deque<ComNameInfo*>   m_wait_download;
	std::deque<std::string>	   m_main_wait_download;
	bool   m_bDownloading;
	CString m_strMainUrl;
	HANDLE m_hThread;
	int m_iDownType;									//�������ͣ�0-������Ϸ��1-���ش���
	DWORD m_dwTotalSize;
	DWORD m_dwDownLoadSize;
	int m_iCurSize;
	int m_iCurTaskID;

	char m_strDownLoadFileName[128];                    // �������ص��ļ���
	CString m_strErrorMsg;                              // ������Ϣ

	std::list<struct _S_HALL_INSTALL_FINISH_DATA*> m_listInstallFinish;
	std::list<struct DownLoadStruct*> m_listDownLoadStruct;
	std::list<struct InstallingStruct*> m_listInstallingStruct;
};

