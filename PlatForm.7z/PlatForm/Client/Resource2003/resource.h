//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AFCResDll.rc
//
#define IDB_LOST_LOGO                   230
#define IDB_EP_001                      501
#define IDB_EP_002                      502
#define IDB_EP_003                      503
#define IDB_EP_004                      504
#define IDB_EP_005                      505
#define IDB_EP_006                      506
#define IDB_EP_007                      507
#define IDB_EP_008                      508
#define IDB_EP_009                      509
#define IDB_EP_010                      510
#define IDB_EP_011                      511
#define IDB_EP_012                      512
#define IDB_EP_013                      513
#define IDB_EP_014                      514
#define IDB_EP_015                      515
#define IDB_EP_016                      516
#define IDB_EP_017                      517
#define IDB_EP_018                      518
#define IDB_EP_019                      519
#define IDB_EP_020                      520
#define IDB_EP_021                      521
#define IDB_EP_022                      522
#define IDB_EP_023                      523
#define IDB_EP_024                      524
#define IDB_EP_025                      525
#define IDB_EP_026                      526
#define IDB_EP_027                      527
#define IDB_EP_028                      528
#define IDB_EP_029                      529
#define IDB_EP_030                      530
#define IDB_EP_031                      531
#define IDB_EP_032                      532
#define IDB_EP_033                      533
#define IDB_EP_034                      534
#define IDB_EP_035                      535
#define IDB_EP_036                      536
#define IDB_EP_037                      537
#define IDB_EP_038                      538
#define IDB_EP_039                      539
#define IDB_EP_040                      540
#define IDB_EP_041                      541
#define IDB_EP_042                      542
#define IDB_EP_043                      543
#define IDB_EP_044                      544
#define IDB_EP_045                      545
#define IDB_EP_046                      546
#define IDB_EP_047                      547
#define IDB_EP_048                      548
#define IDB_EP_049                      549
#define IDB_EP_050                      550
#define IDB_EP_051                      551
#define IDB_EP_052                      552
#define IDB_EP_053                      553
#define IDB_EP_054                      554
#define IDB_EP_055                      555
#define IDB_EP_056                      556
#define IDB_EP_057                      557
#define IDB_EP_058                      558
#define IDB_EP_059                      559
#define IDB_EP_060                      560
#define IDB_EP_061                      561
#define IDB_EP_062                      562
#define IDB_EP_063                      563
#define IDB_EP_064                      564
#define IDB_EP_065                      565
#define IDB_EP_066                      566
#define IDB_EP_067                      567
#define IDB_EP_068                      568
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_CHECK3                      1002
#define IDB_MATCH_LOGO                  1083

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        1121
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           1000
#endif
#endif
