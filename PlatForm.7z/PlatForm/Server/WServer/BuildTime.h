#define VER_MAIN 1
#define VER_MIDDLE 0
#define VER_RESVERSE 0
#define VER_BUILDTIME "2013"