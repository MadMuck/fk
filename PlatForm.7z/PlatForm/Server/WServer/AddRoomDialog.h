/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

#pragma once

#include "afxcmn.h"


// CAddRoomDialog dialog

class CAddRoomDialog : public CDialog
{
	DECLARE_DYNAMIC(CAddRoomDialog)

public:
	CAddRoomDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CAddRoomDialog();

	virtual void OnFinalRelease();

// Dialog Data
	//enum { IDD = IDD_DLL_SET };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
	DECLARE_DISPATCH_MAP()
	DECLARE_INTERFACE_MAP()
public:
	// ����ID
	int m_roomID;
public:
	CString m_szGameRoomName;
public:
	// ��½���ݿ�IP
	CIPAddressCtrl m_LogonSQLIP;
public:
	// �������ݿ�IP
	CIPAddressCtrl m_SQLIP;
public:
	// �������ݿ�IP
	CIPAddressCtrl m_NativeSQLIP;
public:
	//��Ϸ����
	int m_uComType;
public:
	// �����˿�
	int m_uListenPort;
public:
	// �ҽ�����
	int m_uKindID;
public:
	// ������
	int m_uDeskCount;
public:
	// �������
	int m_uMaxPeople;
public:
	// ��������
	int m_uBasePoint;
public:
	// ���ٷ���
	int m_uLessPoint;
public:
	// �������
	unsigned int m_dwRoomRule;
};
