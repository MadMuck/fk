/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AFCLoader.rc
//
#define IDR_MANIFEST                    1
#define IDR_MAINFRAME                   128
#define IDI_START                       129
#define IDD_DIALOG1                     129
#define IDI_STOP                        130
#define IDD_LOGON                       130
#define IDM_LOCK_SYSTEM                 132
#define IDD_SERVICE_CONTROL             133
#define IDD_ACCESS_SET                  134
#define IDR_COMMAND                     135
#define IDM_GET_ROOM_LIST               136
#define IDD_SETGAME_DIALOG              138
#define IDD_DLL_SET                     139
#define IDD_DIALOG2                     140
#define IDD_DIALOG3                     145
#define IDD_REGDLG                      145
#define IDC_SETTING                     1000
#define IDC_ACCESS_NUM                  1000
#define IDC_START_ALL                   1000
#define IDC_BUTTON1                     1000
#define IDC_PASS                        1001
#define IDC_LOGIN_ADDR                  1001
#define IDC_STOP_ALL                    1001
#define IDC_DESK_COUNT                  1001
#define IDC_BUTTON2                     1001
#define IDC_NAME                        1002
#define IDC_ROOM_NAME                   1002
#define IDC_EDIT1                       1002
#define IDC_GAME_TYPE                   1003
#define IDC_EDIT_NID                    1003
#define IDC_SOCKET_PORT                 1004
#define IDC_EDIT2                       1004
#define IDC_EDIT_DP                     1004
#define IDC_BASE_POINT                  1005
#define IDC_BUTTON3                     1005
#define IDC_EDIT_ST                     1005
#define IDC_LESS_POINT                  1006
#define IDC_BUTTON4                     1006
#define IDC_EDIT_SV                     1006
#define IDC_ROOM_ID                     1007
#define IDC_BUTTON5                     1007
#define IDC_EDIT_GN                     1007
#define IDC_MAX_CONNECT                 1008
#define IDC_BUTTON6                     1008
#define IDC_EDIT_GT                     1008
#define IDC_GAME_SQL_IP                 1009
#define IDC_BUTTON7                     1009
#define IDC_EDIT_DLLNAME                1009
#define IDC_USER_SQL_IP                 1010
#define IDC_CHECK1                      1010
#define IDC_EDIT_W                      1010
#define IDC_START_LIST                  1011
#define IDC_NATIVE_SQL_IP               1011
#define IDC_EDIT3                       1011
#define IDC_INSTANLL_LIST               1012
#define IDC_HIGHT_SET                   1012
#define IDC_EDIT4                       1012
#define IDC_EDIT_DLLNOTE                1012
#define IDC_DESK_COUNT2                 1012
#define IDC_ROOM_NUMBER                 1012
#define IDC_START                       1013
#define IDC_EDIT5                       1013
#define IDC_DELETE                      1014
#define IDC_MATCH_SET                   1014
#define IDC_EDIT6                       1014
#define IDC_UPDATE_COM                  1015
#define IDC_ROOM_NOTE                   1015
#define IDC_EDIT7                       1015
#define IDC_SETUP                       1016
#define IDC_CHANGE                      1017
#define IDC_SET_COM                     1018
#define IDC_INFO                        1019
#define IDC_STOP                        1020
#define IDC_EDIT_SIID                   1020
#define IDC_MANAGE                      1021
#define IDC_RE_LOAD                     1022
#define IDC_MOTIF                       1023
#define IDC_DELDLL                      1024
#define IDC_REMOVE                      1025
#define IDC_RELOAD_ROOMLIST             1026
#define IDC_CHECK2                      1027
#define IDC_INSTANLLED_FRAME            1028
#define IDC_CHECK3                      1028
#define IDC_START_FRAME                 1029
#define IDC_CHECK4                      1029
#define IDC_CHECK5                      1030
#define IDC_CHECK6                      1031
#define IDC_CHECK7                      1032
#define IDC_CHECK8                      1033
#define IDC_CHECK9                      1034
#define IDC_REGCODE                     1035
#define IDM_LOGON_SYSTEM                32771
#define IDM_SHOW_FACE                   32772
#define ID_Menu                         32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
