/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

#include "StdAfx.h"
#include "CenterServerManage.h"
#include "CommonUse.h"

//�궨��
#define IDT_UPDATE_INIFILE						20					//����������Ӷ�ʱ��
#define IDT_CHECK_DATA_CONNECT					2					//����������Ӷ�ʱ��
extern void OutputFun(char* message);
/******************************************************************************************************/

// ��������
bool CCenterServerManage::OnStart()
{
	// ������ݿ�����
	SetTimer(IDT_UPDATE_INIFILE,15000L);

	// m_ZServerManager������B�����������ã�B�а�����Z��IP�Ͷ˿ڶ��Ǵ洢��GAMEGATE.bcf�ļ���
	m_ZServerManager.Start();

	return true;
}

// ��ʱ����Ϣ
bool CCenterServerManage::OnTimerMessage(UINT uTimerID)
{
	switch (uTimerID)
	{
	case IDT_UPDATE_INIFILE:	// ������Ϸ�б���ʱ��
		{
			KillTimer(IDT_UPDATE_INIFILE);
			GetINIFile();
			SetTimer(IDT_UPDATE_INIFILE,30000L);
			break;
		}
	default:
		break;
	}

	return true;
}
void CCenterServerManage::GetINIFile()
{	
	CBcfFile f(CBcfFile::GetAppPath() + "HNGameGate.bcf");
	CString strValue;

	if(!f.IsFileExist())
	{
		return;
	}
	
	// �ͻ��˵�ǰ�汾ϵ�кţ����û��˱Ƚϲ�ͬ��Ҫ�û�ȥ����
	strValue = f.GetKeyVal("GateServer", "SerialNo", "");
	strncpy(m_msgSendToClient.m_strGameSerialNO, strValue, sizeof(m_msgSendToClient.m_strGameSerialNO)-1);
	m_msgSendToClient.m_strGameSerialNO[sizeof(m_msgSendToClient.m_strGameSerialNO)-1] = '\0';

	// ��������IP��ַ
	strValue = f.GetKeyVal("GateServer", "MainServerAddress", "");
	strncpy(m_msgSendToClient.m_strMainserverIPAddr, strValue, sizeof(m_msgSendToClient.m_strMainserverIPAddr)-1);
	m_msgSendToClient.m_strMainserverIPAddr[sizeof(m_msgSendToClient.m_strMainserverIPAddr)-1] = '\0';

	// ���������˿ں�
	m_msgSendToClient.m_iMainserverPort = f.GetKeyVal("GateServer", "MainServerPort", 6800);

	// ƽ̨�����õļ��ܷ�ʽ��1λMD5��2λSHA1��Ĭ��Ϊ2
	m_msgSendToClient.m_nEncryptType = f.GetKeyVal("GateServer","EncryType", 2);

	// ��ҳWEB��ַ
	strValue = f.GetKeyVal("GateServer", "WebHomeURL", "");
	strncpy(m_msgSendToClient.m_strHomeADDR, strValue, sizeof(m_msgSendToClient.m_strHomeADDR)-1);
	m_msgSendToClient.m_strHomeADDR[sizeof(m_msgSendToClient.m_strHomeADDR)-1] = '\0';

	// ��վ��·�����ڳ������漰���ļ���Ŀ¼���������ַ����չ
	strValue = f.GetKeyVal("GateServer", "WebRootURL", "");
	strncpy(m_msgSendToClient.m_strWebRootADDR, strValue, sizeof(m_msgSendToClient.m_strWebRootADDR)-1);
	m_msgSendToClient.m_strWebRootADDR[sizeof(m_msgSendToClient.m_strWebRootADDR)-1] = '\0';

	// ����ҳWEB��ַ
	strValue = f.GetKeyVal("GateServer", "WebHelpURL", "");
	strncpy(m_msgSendToClient.m_strHelpADDR, strValue, sizeof(m_msgSendToClient.m_strHelpADDR)-1);
	m_msgSendToClient.m_strHelpADDR[sizeof(m_msgSendToClient.m_strHelpADDR)-1] = '\0';

	// �ͻ��˰�װ��������ҳWEB��ַ
	strValue = f.GetKeyVal("GateServer", "DownLoadSetupURL", "");
	strncpy(m_msgSendToClient.m_strDownLoadSetupADDR, strValue, sizeof(m_msgSendToClient.m_strDownLoadSetupADDR)-1);
	m_msgSendToClient.m_strDownLoadSetupADDR[sizeof(m_msgSendToClient.m_strDownLoadSetupADDR)-1] = '\0';

	// �ͻ��˸��³�������ҳWEB��ַ
	strValue = f.GetKeyVal("GateServer", "DownLoadUpdatepURL", "");
	strncpy(m_msgSendToClient.m_strDownLoadUpdatepADDR, strValue, sizeof(m_msgSendToClient.m_strDownLoadUpdatepADDR)-1);
	m_msgSendToClient.m_strDownLoadUpdatepADDR[sizeof(m_msgSendToClient.m_strDownLoadUpdatepADDR)-1] = '\0';

	// �ͻ��˴���FLASH�������ҳWEB��ַ
	strValue = f.GetKeyVal("GateServer","RallAddvtisFlashURL","");
	strncpy(m_msgSendToClient.m_strRallAddvtisFlashADDR, strValue, sizeof(m_msgSendToClient.m_strRallAddvtisFlashADDR)-1);
	m_msgSendToClient.m_strRallAddvtisFlashADDR[sizeof(m_msgSendToClient.m_strRallAddvtisFlashADDR)-1] = '\0';

	// �ͻ��˹���������ַ
	strValue = f.GetKeyVal("GateServer", "RoomRollWords", "��ӭ��������������Ϸ���磡");
	strncpy(m_msgSendToClient.m_strRoomRollADDR, strValue, sizeof(m_msgSendToClient.m_strRoomRollADDR)-1);
	m_msgSendToClient.m_strRoomRollADDR[sizeof(m_msgSendToClient.m_strRoomRollADDR)-1] = '\0';

	// -
	m_msgSendToClient.m_nIsUsingIMList = f.GetKeyVal("GateServer","UsingIMList",1);

	// �������Ͻ�����ʾID�Ż�������ֵ
	m_msgSendToClient.m_nHallInfoShowClass = f.GetKeyVal("GateServer","HallInforShowClass",0);

	// -
    m_msgSendToClient.m_is_haveZhuanZhang = f.GetKeyVal("GateServer","IsHaveZhuanZhang",0);
	
	// ���ط������б�
	//m_MainserverList.LoadServerList(cfgHandle);

	// ��ȡ������ʹ�õĹ���
	GetFunction(); 
}

void CCenterServerManage::GetURL(char *strKey)
{
	CBcfFile f(CBcfFile::GetAppPath() + "HNGameGate.bcf");
	CString strValue;

	if (NULL == strKey)
	{
		// �ͻ��˹���������ַ
		strValue = f.GetKeyVal(_T("GateServer"), _T("RoomRollWords"), _T("��ӭ��������������Ϸ���ģ�"));
		strncpy(m_msgSendToClient.m_strRoomRollADDR, strValue, sizeof(m_msgSendToClient.m_strRoomRollADDR)-1);
		m_msgSendToClient.m_strRoomRollADDR[sizeof(m_msgSendToClient.m_strRoomRollADDR)-1] = '\0';

		// ����ҳWEB��ַ
		strValue = f.GetKeyVal(_T("GateServer"), _T("WebHelpURL"), _T(""));
		strncpy(m_msgSendToClient.m_strHelpADDR, strValue, sizeof(m_msgSendToClient.m_strHelpADDR)-1);
		m_msgSendToClient.m_strHelpADDR[sizeof(m_msgSendToClient.m_strHelpADDR)-1] = '\0';

		// ��ҳWEB��ַ
		strValue = f.GetKeyVal(_T("GateServer"), _T("WebHomeURL"), _T(""));
		strncpy(m_msgSendToClient.m_strHomeADDR, strValue, sizeof(m_msgSendToClient.m_strHomeADDR)-1);
		m_msgSendToClient.m_strHomeADDR[sizeof(m_msgSendToClient.m_strHomeADDR)-1] = '\0';

		// ��վ��·��
		strValue = f.GetKeyVal(_T("GateServer"), _T("WebRootURL"), _T(""));
		strncpy(m_msgSendToClient.m_strWebRootADDR, strValue, sizeof(m_msgSendToClient.m_strWebRootADDR)-1);
		m_msgSendToClient.m_strWebRootADDR[sizeof(m_msgSendToClient.m_strWebRootADDR)-1] = '\0';
	}
	else
	{
		// ��ҳWEB��ַ
		strValue = f.GetKeyVal(_T("WebHomeURL"),strKey,_T(""));
		if (strValue.IsEmpty())
		{
			GetURL(NULL);
			return;
		}
		strncpy(m_msgSendToClient.m_strHomeADDR, strValue, sizeof(m_msgSendToClient.m_strHomeADDR)-1);
		m_msgSendToClient.m_strHomeADDR[sizeof(m_msgSendToClient.m_strHomeADDR)-1] = '\0';

		// �ͻ��˹���������ַ
		strValue = f.GetKeyVal(_T("RoomRollWords"), strKey,_T(""));
		strncpy(m_msgSendToClient.m_strRoomRollADDR, strValue, sizeof(m_msgSendToClient.m_strRoomRollADDR)-1);
		m_msgSendToClient.m_strRoomRollADDR[sizeof(m_msgSendToClient.m_strRoomRollADDR)-1] = '\0';

		// ����ҳWEB��ַ
		strValue = f.GetKeyVal(_T("WebHelpURL"), strKey, _T(""));
		strncpy(m_msgSendToClient.m_strHelpADDR, strValue, sizeof(m_msgSendToClient.m_strHelpADDR)-1);
		m_msgSendToClient.m_strHelpADDR[sizeof(m_msgSendToClient.m_strHelpADDR)-1] = '\0';

		// ��վ��·��
		strValue = f.GetKeyVal(_T("WebRootURL"), strKey, _T(""));
		strncpy(m_msgSendToClient.m_strWebRootADDR, strValue, sizeof(m_msgSendToClient.m_strWebRootADDR)-1);
		m_msgSendToClient.m_strWebRootADDR[sizeof(m_msgSendToClient.m_strWebRootADDR)-1] = '\0';
	}	
}

// ��Function.bcf�ж�ȡ��������
void CCenterServerManage::GetFunction()
{
	CBcfFile f(CBcfFile::GetAppPath() + "Function.bcf");
	CString strValue;

	// ���«2��ָ��ID��
	strValue = f.GetKeyVal("SpecificID", "Available", "0");
	if (0 != _ttoi(strValue))
	{
		m_msgSendToClient.m_nFunction = 1;
		strValue = f.GetKeyVal("SpecificID", "NormalID", "60000000, 69999999");
		m_msgSendToClient.m_lNomalIDFrom = atol(strValue.Left(strValue.Find(",")+1));
		m_msgSendToClient.m_lNomalIDEnd  = atol(strValue.Right(strValue.GetLength()-strValue.Find(",")-1));
	}

	 // �����������ͽ��
	strValue = f.GetKeyVal("OnlineCoin", "Available", "0");
	if (0 != _ttoi(strValue))
	{
		m_msgSendToClient.m_nFunction |= 1<<1;
	}

	// �쵱�������������
	strValue = f.GetKeyVal("RobotExtend","Available","0");
	if (0 != _ttoi(strValue))
	{
		m_msgSendToClient.m_nFunction |= 2<<1;
	}

    // �����Ƿ��ֹ˽�ģ�0 = û�н�ֹ
    strValue = f.GetKeyVal("CommFunc","ForbidSay","0");
    if( 0 != _ttoi(strValue))
    {
        m_msgSendToClient.m_nFunction |= 1<<3;
    }
}

bool CCenterServerManage::OnSocketRead(NetMessageHead * pNetHead, void * pData, UINT uSize, ULONG uAccessIP, UINT uIndex, DWORD dwHandleID)
{
	// ������Ϸȫ�ֲ���
	if (pNetHead->bMainID == MDM_GP_REQURE_GAME_PARA)	
	{
		if (0 == uSize)
		{
			GetURL(NULL);
		}
		else
		{
			char * pBuf = (char*)pData;
			GetURL(pBuf);
		}

		// ���ؾ���
		//RandAServer();
		
		m_TCPSocket.SendData(uIndex, &m_msgSendToClient, sizeof(CenterServerMsg), MDM_GP_REQURE_GAME_PARA, 0, 0, 0);
		return true;
	}
	return false;
}
/******************************************************************************************************/

// ���캯��
CCenterServerManage::CCenterServerManage(void) 
	:CBaseMainManageForWeb()
{
	GetINIFile();
}

// �������� 
CCenterServerManage::~CCenterServerManage(void)
{
}
// ֹͣ����
bool CCenterServerManage::OnStop()
{
	KillTimer(IDT_CHECK_DATA_CONNECT);
	m_ZServerManager.Stop();
	return true;
}

// ���ݹ���ģ���ʼ��
bool CCenterServerManage::OnInit(ManageInfoStruct * pInitData, KernelInfoStruct * pKernelData)
{
	return m_ZServerManager.Init(pInitData,NULL);
}
// ���ݹ���ģ��ж��
bool CCenterServerManage::OnUnInit()
{
	return m_ZServerManager.UnInit();
}

// ��ȡ��Ϣ����
bool CCenterServerManage::PreInitParameter(ManageInfoStruct * pInitData, KernelInfoStruct * pKernelData)
{
	//���ð汾��Ϣ
	//pKernelData->bMaxVer=GAME_PLACE_MAX_VER;
	//pKernelData->bLessVer=GAME_PLACE_LESS_VER;

	// ����ʹ�����ݿ�
	pKernelData->bLogonDataBase    = FALSE; //TRUE;
	pKernelData->bNativeDataBase   = FALSE; //TRUE;
	pKernelData->bStartSQLDataBase = FALSE; //TRUE;

	// ����ʹ������
	pKernelData->bStartTCPSocket = TRUE;
	pInitData->uListenPort       = CENTER_SERVER_PORT;
	pInitData->uMaxPeople        = 300;
	pInitData->iSocketSecretKey  = SECRET_KEY;

	CString info;
	info.Format("���ķ��������ɹ�  Port:%d", CENTER_SERVER_PORT);

	OutputFun(info.GetBuffer ());

	return true;
}
// SOCKET �ر�
bool CCenterServerManage::OnSocketClose(ULONG uAccessIP, UINT uSocketIndex, long int lConnectTime)
{
	return true;
}

bool CCenterServerManage::OnDataBaseResult(DataBaseResultLine * pResultData)
{
	return true;
}

void CCenterServerManage::RandAServer()
{
	m_ZServerManager.m_MainserverList.RandAServer (m_msgSendToClient.m_strMainserverIPAddr, m_msgSendToClient.m_iMainserverPort);
}

bool CCenterServerManage::CMainserverList::RandAServer(char* ipaddr,long& port)
{
	bool result = false;
	Lock();
	if(!m_List.IsEmpty())
	{
		// Z�����ؾ��⣬ƽ�����䷨
		static int curi = 0;

		// ���ѡ��һ����
		long t = GetCurrentTime() + rand();

		// ����������ȡ�����ȳ˰ٷְ٣�Ȼ��ȡ������
		int i = 0; 

		POSITION pos=m_List.GetHeadPosition ();
		
		for(int j = 0; j < m_List.GetCount(); j++)
		{
			Node* nd = (Node*)m_List.GetNext(pos);
			if(nd)
			{				
				// �õ����������IP���͵��ͻ���
				if(i == curi)
				{
					CString s = nd->IPAddr ;
					port = nd->Port ;
					memcpy(ipaddr,s.GetBuffer(s.GetLength ()),20);
					result = true;
					break;
				}
			}
			i++;
		}

		curi++;
		if(curi >= m_List.GetCount()) 
			curi = 0;
	}
	UnLock();
	return result;
}


void CCenterServerManage::CMainserverList::clear()
{
	Lock();
	while(!m_List.IsEmpty())
	{
		Node* pdesk = (Node*)m_List.RemoveHead();
		delete pdesk;
	}
	m_List.RemoveAll();
	UnLock();
}

CCenterServerManage::CMainserverList::~CMainserverList()
{
	clear();
}

void CCenterServerManage::CMainserverList::LoadServerList(DWORD cfgHandle)
{
	clear();

	CString ss;
	for(int i = 0; i < 10; i++)
	{
		ss.Format("M_IPAddr%d",i+1);
		CString ip = cfgGetValue(cfgHandle,"GateServer",ss,"");
		if(ip == "")
		{
			break;
		}

		Node* nd = new Node();
		nd->IPAddr =ip;
		ss.Format("M_Port%d",i+1);
		nd->Port = cfgGetValue(cfgHandle,"GateServer",ss,0);
		ss.Format("M_id%d",i+1);
		nd->id = cfgGetValue(cfgHandle,"GateServer",ss,0);
		Lock();
		m_List.AddTail(nd);
		UnLock();
	}
}


//void CCenterServerManage::CMainserverList::ReadINIFile(CString TMLkey)
//{
//	clear();
//	CString s=CINIFile::GetAppPath ();
//	CINIFile f( s + "CenterServer.ini");
//	//int count=f.GetKeyVal ("www.TML.cn","MainserverListCount",0);//////������������
//	for(int i=0;i<10;i++)
//	{
//		CString s;
//		s.Format ("%d",i+1);
//		CString ip=f.GetKeyVal (TMLkey,"M_IPAddr"+s,"");
//		if (ip=="")break;
//		Node* nd=new Node();
//		nd->IPAddr =ip;
//		long port=f.GetKeyVal (TMLkey,"M_Port"+s,0);
//		nd->Port =port;
//		port=f.GetKeyVal (TMLkey,"M_id"+s,0);
//		nd->id  =port;
//		Lock();
//		  m_List.AddTail (nd);
//		UnLock();
//
////ԭ���㷨
//		//CString s;
//		//s.Format ("Mainserver%d",i+1);
//		//CString ip=f.GetKeyVal (s,"IPAddr","");
//		//Node* nd=new Node();
//		//nd->IPAddr =ip;
//		//long port=f.GetKeyVal (s,"Port",0);
//		//nd->Port =port;
//		//port=f.GetKeyVal (s,"id",0);
//		//nd->id  =port;
//		//Lock();
//		//  m_List.AddTail (nd);
//		//UnLock();
//
//	}
//
//}

CCenterServerManage::CMainserverList::CMainserverList()
{
	///srand( (unsigned)time( NULL ) );
	///InitializeCriticalSection(&cs);
   /// ReadINIFile();
}
/******************************************************************************************************/

CCenterServerModule::CCenterServerModule(void) 
{

}

CCenterServerModule::~CCenterServerModule(void)
{

}

bool CCenterServerModule::InitService(ManageInfoStruct * pInitData)
{
	try
	{
		return m_LogonManage.Init(pInitData,NULL);
	}
	catch (CAFCException * pException)
	{ 
		pException->Delete();	
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	catch (...)	
	{ 
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	return false;
}

// ж�غ���
bool CCenterServerModule::UnInitService()
{
	try
	{
		return m_LogonManage.UnInit();
	}
	catch (CAFCException * pException)	
	{ 
		pException->Delete();	
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	catch (...) 
	{
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	return false;
}

// ��ʼ���� 
bool CCenterServerModule::StartService(UINT &errCode)
{
	try
	{
		return m_LogonManage.Start();
	}
	catch (CAFCException * pException)
	{ 
		pException->Delete();
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	catch (...) 
	{
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	return false;
}

// ֹͣ���� 
bool CCenterServerModule::StoptService()
{
	try
	{
		return m_LogonManage.Stop();
	}
	catch (CAFCException * pException)
	{ 
		pException->Delete();
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	catch (...) 
	{
		TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
	}
	return false;

}

// ɾ������
bool CCenterServerModule::DeleteService()
{
	try	
	{ 
		delete this;
	}
	catch (...) 
	{

	}
	return true;
}

/******************************************************************************************************/
