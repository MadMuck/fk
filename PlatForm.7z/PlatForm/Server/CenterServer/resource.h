/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CenterServer.rc
//
#define IDD_CENTERSERVER_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDD_MAIN_DIALOG                 129
#define IDD_DIALOG_SETUP                130
#define IDC_STATIC_STATUSBAR            1000
#define IDC_EDIT_GAMESERIALNO           1001
#define IDC_EDIT_MAINSERVERIPADDR       1002
#define IDC_EDIT_MAINSERVERPORT         1003
#define IDC_EDIT_HOMEWEBADDR            1004
#define IDC_STATIC1                     1004
#define IDC_EDIT_LOGINNEWUSERWEBADDR    1005
#define IDC_EDIT_HELPWEBADDR            1006
#define IDC_EDIT_HUAZHANGWEBADDR        1007
#define IDC_EDIT_GAMESETUPEXEADDR       1008
#define IDC_EDIT_BBSWEBADDR             1009
#define IDC_EDIT_GAMEUPDATEEXEADDR      1010
#define IDC_BTNSTART                    10001
#define IDC_LIST_SYS_RUN_INFO           10002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
