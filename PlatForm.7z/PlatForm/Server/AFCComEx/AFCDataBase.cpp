/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

#include "StdAfx.h"
#include "Math.h"
#include "AFCDataBase.h"
#include "AFCFunction.h"
#include "AFCSocket.h"
#include "OleDBErr.h"

// �����߳̽ṹ����
struct ThreadStartStruct
{
	HANDLE						hEvent;									// �˳��¼�
	HANDLE						hCompletionPort;						// ��ɶ˿�
	CAFCDataBaseManage			* pDataManage;							// ���ݿ������ָ��
};

// ���캯��
CAFCDataBaseManage::CAFCDataBaseManage()
{
	m_bInit         = false;
	m_bRun          = false;
	m_hThread       = NULL;
	m_hCompletePort = NULL;
	m_pInitInfo     = NULL;
	m_pKernelInfo   = NULL;
	m_pHandleService= NULL;

	hDBLogon  = NULL;
	hDBNative = NULL;

	m_sqlClass = 0;
	m_nPort    = 0;
	m_bsqlInit = FALSE;

	m_pConnection.CreateInstance(__uuidof(Connection));

	// ��ʼ��Recordsetָ��
	m_pRecordset.CreateInstance(_uuidof(Recordset));

	m_pEngineSink = nullptr;	
	
}

// ��������
CAFCDataBaseManage::~CAFCDataBaseManage(void)
{
	if (nullptr != m_pEngineSink)
	{
		dklSQLEngineDelete(m_pEngineSink);
		m_pEngineSink = nullptr;
	}
}

// ��ʼ����
bool CAFCDataBaseManage::Start()
{
	if ((this == NULL) || m_bRun || !m_bInit)
	{
		throw new CAFCException(TEXT("CAFCDataBaseManage::Start û�г�ʼ������"), 0x401);
	}
	
	// �����¼�
	CEvent StartEvent(FALSE, TRUE, NULL, NULL);
	if (StartEvent == NULL)
	{
		throw new CAFCException(TEXT("CAFCDataBaseManage::Start �¼�����ʧ��"),0x402);
	}

	// ������ɶ˿�
	m_hCompletePort = CreateIoCompletionPort(INVALID_HANDLE_VALUE, NULL, NULL, 0);
	if(m_hCompletePort == NULL) 
	{
		throw new CAFCException(TEXT("CAFCDataBaseManage::Start m_hCompletePort ����ʧ��"), 0x403);
	}
	m_DataLine.SetCompletionHandle(m_hCompletePort);
		
	// ͨ�� sqlengine �������ݿ�	
	//SQLConnectReset();
	SQLConnect();//�������ݿ⡣

	int x = 0;
	
	// �������ݴ����߳�
	unsigned dwThreadID = 0;
	ThreadStartStruct ThreadStartData;
	ThreadStartData.pDataManage = this;
	ThreadStartData.hEvent=StartEvent;
	ThreadStartData.hCompletionPort = m_hCompletePort;
	m_hThread = (HANDLE)_beginthreadex(NULL, 0, DataServiceThread, &ThreadStartData, 0, &dwThreadID);
	if (m_hThread == NULL)
	{
		throw new CAFCException(TEXT("CAFCDataBaseManage::Start DataServerThread �߳̽���ʧ��"), 0x407);
	}

	WaitForSingleObject(StartEvent, INFINITE);
	ResetEvent(StartEvent);

	// �����ɹ�
	m_bRun = true;
	return true;
}

// ֹͣ����
bool CAFCDataBaseManage::Stop()
{
	// ��������
	bool bFlush = m_bRun;
	m_bRun = false;
	m_DataLine.SetCompletionHandle(NULL);

	// �ر���ɶ˿�
	if (m_hCompletePort != NULL)
	{
		// �˳������߳�
		if (m_hThread != NULL) 
		{
			PostQueuedCompletionStatus(m_hCompletePort, 0, NULL, NULL);
			CloseHandle(m_hThread);
			m_hThread = NULL;
		}
		CloseHandle(m_hCompletePort);
		m_hCompletePort = NULL;
	}

	// �ر����ݿ�����
	if (m_pKernelInfo != NULL)
	{
		if (nullptr != m_pEngineSink)
		{
			dklSQLEngineDelete(m_pEngineSink);
			m_pEngineSink = nullptr;
		}
	}

	return true;
}

// ȡ����ʼ��
bool CAFCDataBaseManage::UnInit()
{
	// ֹͣ����
	if (m_bRun) Stop();
	m_DataLine.CleanLineData();

	// �ָ�����
	m_bInit          = false;
	m_pInitInfo      = NULL;
	m_hThread        = NULL;
	m_hCompletePort  = NULL;
	m_pKernelInfo    = NULL;
	m_pHandleService = NULL;

	//if (m_pConnection->State)
	//	m_pConnection->Close();
	return true;
}

// ���봦������
bool CAFCDataBaseManage::PushLine(DataBaseLineHead * pData, UINT uSize, UINT uHandleKind, UINT uIndex,DWORD dwHandleID)
{
	//��������
	pData->dwHandleID=dwHandleID;
	pData->uIndex=uIndex;
	pData->uHandleKind=uHandleKind;
	return (m_DataLine.AddData(&pData->DataLineHead,uSize,0)!=0);
}

// ���ݿ⴦���߳�
unsigned __stdcall CAFCDataBaseManage::DataServiceThread(LPVOID pThreadData)
{
	// ���ݶ���
	ThreadStartStruct		* pData          = (ThreadStartStruct *)pThreadData;	// �߳���������ָ��
	CAFCDataBaseManage		* pDataManage    = pData->pDataManage;				    // ���ݿ����ָ��
	CDataLine				* pDataLine      = &pDataManage->m_DataLine;			// ���ݶ���ָ��
	IDataBaseHandleService	* pHandleService = pDataManage->m_pHandleService;	    // ���ݴ����ӿ�
	HANDLE					hCompletionPort  = pData->hCompletionPort;			    // ��ɶ˿�

	// �߳����ݶ�ȡ���
	::SetEvent(pData->hEvent);

	// �ص�����
	void					* pIOData     = NULL;							// ����
	DWORD					dwThancferred = 0;								// ��������
	ULONG					dwCompleteKey = 0L;								// �ص� IO ��ʱ����
	LPOVERLAPPED			OverData;										// �ص� IO ��ʱ����

	// ���ݻ���
	BOOL					bSuccess = FALSE;
	BYTE					szBuffer[LD_MAX_PART];

	while (TRUE)
	{
		// �ȴ���ɶ˿�
		bSuccess = GetQueuedCompletionStatus(hCompletionPort, &dwThancferred, &dwCompleteKey, (LPOVERLAPPED *)&OverData, INFINITE);
		if (!bSuccess || dwThancferred == 0)
		{
			_endthreadex(0);
			return 0;
		}

		
		while(pDataLine->GetDataCount())
		{
			//DebugPrintf("pDataLine->GetDataCount()=%d",pDataLine->GetDataCount());
			try
			{
				// ������ɶ˿�����
				if (pDataLine->GetData((DataLineHead *)szBuffer, sizeof(szBuffer)) < sizeof(DataBaseLineHead))
				{
					continue;
				}
				//DebugPrintf("GetData %d",((DataBaseLineHead *)szBuffer)->uHandleKind);
				pHandleService->HandleDataBase((DataBaseLineHead *)szBuffer);
				//DebugPrintf("HandleDataBase %d",((DataBaseLineHead *)szBuffer)->uHandleKind);
			}
			catch (...) 
			{ 
				TRACE("CATCH:%s with %s\n",__FILE__,__FUNCTION__);
				continue; 
			}
		}
	}

	_endthreadex(0);
	return 0;
}


// �������ݿ�
bool CAFCDataBaseManage::SQLConnectReset()
{
	if (nullptr != m_pEngineSink)
	{
		dklSQLEngineDelete(m_pEngineSink);
		m_pEngineSink = nullptr;
	}

	if (!m_bsqlInit)
	{
		tinyxml2::XMLDocument doc;
		if (tinyxml2::XMLError::XML_SUCCESS != doc.LoadFile("HNGameLocal.xml"))
		{
			AfxMessageBox("Load HNGameLocal.xml Error-0",0);
			return false;
		}
		tinyxml2::XMLElement* element1 = doc.FirstChildElement("SQLSERVER");
		if (NULL == element1)
		{
			AfxMessageBox("Load HNGameLocal.xml Error-0-1",0);
			return false;
		}
		for (const tinyxml2::XMLElement* xml_SqlServer = element1->FirstChildElement(); xml_SqlServer; xml_SqlServer = xml_SqlServer->NextSiblingElement()) 
		{
			// ���ݿ�IP��ַ
			if (!strcmp(xml_SqlServer->Value(), "DBSERVER")) 
			{
				m_szServer = xml_SqlServer->Attribute("key");
			}
			else if (!strcmp(xml_SqlServer->Value(), "DBPORT")) 
			{
				// �˿�
				CString sPort = xml_SqlServer->Attribute("key");
				m_nPort = _ttoi(sPort);
			}
			else if (!strcmp(xml_SqlServer->Value(), "DATABASE")) 
			{
				// ���ݿ���
				m_szDatabase = xml_SqlServer->Attribute("key");
			}
			
			else if (!strcmp(xml_SqlServer->Value(), "DBACCOUNT")) 
			{
				// ���ݿ��¼�ʺ�
				m_szAccount = xml_SqlServer->Attribute("key");
			}
			else if (!strcmp(xml_SqlServer->Value(), "DBPASSWORD")) 
			{
				// ���ݿ��¼����
				m_szPassword = xml_SqlServer->Attribute("key");
			}
		}
		m_szDetectTable = TEXT("");
		m_bsqlInit      = TRUE;
	}
	CString szPort;                                                                                                                                                                              
	szPort.Format(TEXT(",%d"), m_nPort);
	CString szServer;
	szServer = m_szServer + szPort;
	DBCreateParam createParam;
	_tcscpy_s(createParam.server, szServer);
	_tcscpy_s(createParam.db, m_szDatabase);
	_tcscpy_s(createParam.uid, m_szAccount);
	_tcscpy_s(createParam.pwd, m_szPassword);

	int code = dklSQLEngineCreate(createParam, &m_pEngineSink);
	if(code!=0)
	{
		m_pEngineSink=nullptr;
		throw new CAFCException(TEXT("CAFCDataBaseManage::Start ���ӱ������ݿ�ʧ��a"),code);
	}

	return true;
}

// �����������
bool CAFCDataBaseManage::CheckSQLConnect()
{
	return true;
}

void CAFCDataBaseManage::SQLConnect()
{
	if (!m_bsqlInit)
	{
		tinyxml2::XMLDocument doc;
		if (tinyxml2::XMLError::XML_SUCCESS != doc.LoadFile("HNGameLocal.xml"))
		{
			AfxMessageBox("Load HNGameLocal.xml Error-1",0);
			return ;
		}
		tinyxml2::XMLElement* element1 = doc.FirstChildElement("SQLSERVER");
		if (NULL == element1)
		{
			AfxMessageBox("Load HNGameLocal.xml Error-1-1",0);
			return ;
		}
		for (const tinyxml2::XMLElement* xml_SqlServer = element1->FirstChildElement(); xml_SqlServer; xml_SqlServer = xml_SqlServer->NextSiblingElement()) 
		{
			// ���ݿ�IP��ַ
			if (!strcmp(xml_SqlServer->Value(), "DBSERVER")) 
			{
				m_szServer = xml_SqlServer->Attribute("key");
			}
			else if (!strcmp(xml_SqlServer->Value(), "DBPORT")) 
			{
				// �˿�
				CString sPort = xml_SqlServer->Attribute("key");
				m_nPort = _ttoi(sPort);
			}
			else if (!strcmp(xml_SqlServer->Value(), "DATABASE")) 
			{
				// ���ݿ���
				m_szDatabase = xml_SqlServer->Attribute("key");
			}

			else if (!strcmp(xml_SqlServer->Value(), "DBACCOUNT")) 
			{
				// ���ݿ��¼�ʺ�
				m_szAccount = xml_SqlServer->Attribute("key");
			}
			else if (!strcmp(xml_SqlServer->Value(), "DBPASSWORD")) 
			{
				// ���ݿ��¼����
				m_szPassword = xml_SqlServer->Attribute("key");
			}
		}
		m_szDetectTable = TEXT("");
		m_bsqlInit      = TRUE;
	}


	if (nullptr != m_pEngineSink)
	{
		dklSQLEngineDelete(m_pEngineSink);
		m_pEngineSink = nullptr;
	}

	CString szPort;
	szPort.Format(TEXT(",%d"), m_nPort);
	CString szServer;
	szServer = m_szServer + szPort;
	DBCreateParam createParam;
	_tcscpy_s(createParam.server, szServer);
	_tcscpy_s(createParam.db, m_szDatabase);
	_tcscpy_s(createParam.uid, m_szAccount);
	_tcscpy_s(createParam.pwd, m_szPassword);

	int code = dklSQLEngineCreate(createParam, &m_pEngineSink);
	CString str;
	str.Format("ycl::dklSQLEngineCreate:%s %s %s %s",szServer,m_szDatabase,m_szAccount,m_szPassword);
	OutputDebugString(str);
	if(code!=0)
	{
		m_pEngineSink=nullptr;
		throw new CAFCException(TEXT("CAFCDataBaseManage::Start ���ӱ������ݿ�ʧ��b"),code);
	}	
	
}

//***********************************************************************************************//

// ���캯��
CDataBaseHandle::CDataBaseHandle(void)
{
	m_pInitInfo       = NULL;
	m_pKernelInfo     = NULL;
	m_pRusultService  = NULL;
	m_pDataBaseManage = NULL;
}

// �������� 
CDataBaseHandle::~CDataBaseHandle(void)
{
}

// ���ò���
bool CDataBaseHandle::SetParameter(IDataBaseResultService * pRusultService, CAFCDataBaseManage * pDataBaseManage, ManageInfoStruct * pInitData, KernelInfoStruct * pKernelData)
{
	m_pInitInfo       = pInitData;
	m_pKernelInfo     = pKernelData;
	m_pRusultService  = pRusultService;
	m_pDataBaseManage = pDataBaseManage;

	return true;
}



// ��ʼ������
bool CAFCDataBaseManage::Init(ManageInfoStruct * pInitInfo, KernelInfoStruct * pKernelInfo, 
							  IDataBaseHandleService * pHandleService,IDataBaseResultService * pResultService)
{
	// Ч�����
	if ((this == NULL) || m_bInit || m_bRun)
	{
		throw new CAFCException(TEXT("CAFCDataBaseManage::Init ״̬Ч��ʧ��"), 0x408);
	}

	// ��������
	m_pInitInfo      = pInitInfo;
	m_pKernelInfo    = pKernelInfo;
	m_pHandleService = pHandleService;
	m_DataLine.CleanLineData();

	// ��������
	m_bInit = true;
	return true;
}

bool CDataBaseHandle::sqlSPSetNameEx(LPCTSTR szSPName,bool bReturnValue)
{
	if (nullptr == m_pDataBaseManage)
	{
		return false;
	}

	if (nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		m_pDataBaseManage->SQLConnectReset();
	}

	if (nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return false;
	}

	int iRes = m_pDataBaseManage->m_pEngineSink->setStoredProc(szSPName, bReturnValue);
	if (0 != iRes)
	{
		return false;
	}

	return true;
}

void CDataBaseHandle::closeRecord()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return;
	}

	m_pDataBaseManage->m_pEngineSink->closeRecord();
}
bool CDataBaseHandle::adoBOF()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return false;
	}

	return m_pDataBaseManage->m_pEngineSink->adoBOF();
}
bool CDataBaseHandle::adoEndOfFile()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return false;
	}

	return m_pDataBaseManage->m_pEngineSink->adoEndOfFile();
}
bool CDataBaseHandle::moveFirst()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return false;
	}

	return m_pDataBaseManage->m_pEngineSink->moveFirst();
}
bool CDataBaseHandle::moveNext()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return false;
	}

	return m_pDataBaseManage->m_pEngineSink->moveNext();
}
bool CDataBaseHandle::moveLast()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return false;
	}

	return m_pDataBaseManage->m_pEngineSink->moveLast();
}
// ��ȡ��¼��
long CDataBaseHandle::getRecordCount()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return 0;
	}

	return m_pDataBaseManage->m_pEngineSink->getRecordCount();
}
// ��ȡ�ֶ���
long CDataBaseHandle::getFieldCount()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return 0;
	}

	return m_pDataBaseManage->m_pEngineSink->getFieldCount();
}

int CDataBaseHandle::execSQL(LPCTSTR sql, bool returnValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -3;
	}

	return m_pDataBaseManage->m_pEngineSink->execSQL(sql, returnValue);
}
int CDataBaseHandle::execStoredProc()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -3;
	}
	int iResult = m_pDataBaseManage->m_pEngineSink->execStoredProc();
	if (0 != iResult)
	{
		static COleDateTime LastTime = COleDateTime::GetCurrentTime();
		COleDateTime nowTime = COleDateTime::GetCurrentTime();
		COleDateTimeSpan tmDiff = (nowTime - LastTime);
		long lsec = (long)tmDiff.GetTotalSeconds();
		if (lsec > 60)
		{
			m_pDataBaseManage->SQLConnectReset();
			LastTime = nowTime;
		}
		
	}
	return iResult;
}

long CDataBaseHandle::getReturnValue()
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -1;
	}

	return m_pDataBaseManage->m_pEngineSink->getReturnValue();
}

int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, bool fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, char fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, unsigned char fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, short fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, unsigned short fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, int fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, unsigned int fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, long long fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, unsigned long long fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, float fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, double fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldValue);
}
int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, LPCTSTR fieldValue, unsigned int fieldSize)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldSize, fieldValue);
}

int CDataBaseHandle::addInputParameter(LPCTSTR fieldName, BYTE* fieldValue, unsigned int fieldSize)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->addInputParameter(fieldName, fieldSize, fieldValue);
}

int CDataBaseHandle::getValue(LPCTSTR fieldName, bool* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, char* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, unsigned char* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, short* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, unsigned short* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, int* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, unsigned int* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, long* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, unsigned long* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, long long* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, unsigned long long* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, float* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, double* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, COleDateTime* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, GUID* fieldValue)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, fieldValue);
}
int CDataBaseHandle::getValue(LPCTSTR fieldName, LPTSTR dstField, unsigned int dstFieldLength)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, dstField, dstFieldLength);
}

int CDataBaseHandle::getValue(LPCTSTR fieldName, BYTE* dstField, unsigned int dstFieldLength)
{
	if (nullptr == m_pDataBaseManage || nullptr == m_pDataBaseManage->m_pEngineSink)
	{
		return -2;
	}

	return m_pDataBaseManage->m_pEngineSink->getValue(fieldName, dstField, dstFieldLength);
}

//***********************************************************************************************//
