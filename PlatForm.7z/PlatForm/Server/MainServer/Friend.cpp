/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/
#include "StdAfx.h"
#include "Friend.h"
#include "GameLogonManage.h"
#include "commonuse.h"


Friend::Friend(CGameLogonManage* pLogonManage)
    :_pLogonManage(pLogonManage)
{

}


Friend::~Friend(void)
{

}

bool Friend::OnNetMessage(NetMessageHead* pNetHead,void* pData,UINT uSize,ULONG uAccessIP,UINT uIndex,DWORD dwHandleID)
{
    if (!_pLogonManage) 
    {
        return true;
    }

    if (MDM_GP_FRIEND != pNetHead->bMainID)
    {
        return true;
    }

    switch(pNetHead->bAssistantID)
    {
    case ASS_GP_USERADDORDEL_FRIEND:
        {
            WriteLog("�յ�146-0  �û�����ɾ����������");
            return UserAddorDelFriend(pData,uSize,uIndex,dwHandleID);
        }break;
    case ASS_GP_USERGET_FRIENDLIST:
        {
            WriteLog("�յ�146-1 ��ȡ�����б���Ϣ");
            return UserGetFriendList(pData,uSize,uIndex,dwHandleID);
        }break;
    case ASS_GP_USER_SHIELD:
        {
            WriteLog("�յ�146-2 ");
            return UserShieldRequest(pData,uSize,uIndex,dwHandleID);
        }break;
    case ASS_GP_USERINFO:
        {
            WriteLog("�յ�  146--3  ��ȡ������Ϣ");
            return UserGetUserInfoRequest(pData,uSize,uIndex,dwHandleID);
        }break;
    default:
        break;
    }

    return true ;
}

bool Friend::OnDataBaseResult(DataBaseResultLine* pResultData)
{
    if (!_pLogonManage) 
    {
        return true;
    }

    switch(pResultData->uHandleKind)
    {
    case DTK_GP_USERADDORDEL_FRIEND:
        {
            WriteLog("UserAddorDelFriendResponse break");
            UserAddorDelFriendResponse(pResultData);
        }break;	
   case DTK_GP_USERGETFRIENDLIST:
        {
            WriteLog("UserGetFriendListResponse break");
            UserGetFriendListResponse(pResultData);
        }break;
    case DTK_GP_USERSHIELD:
        {
            WriteLog("�û������Լ� ���ݿ⴦�����");
            UserShieldResponse(pResultData);
        }break;
    case DTK_GP_USER_GETUSERINFO:
        {
            WriteLog("������Ϣ ���ݿ⴦�����");
            UserGetUserInfoResponse(pResultData);
        }break;
    default:
        return true;
    }

    return true;
}

///������Ӻ���  ����
bool Friend::UserAddorDelFriend(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    
    if (uSize != sizeof(MSG_GP_I_UserAddOrDelFriend))
    {
        WriteLog("������Ӻ���   �ṹ���С���ԣ�");
        return false;
    }
  
    DL_I_HALL_UserAddFriend DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_UserAddOrDelFriend));


      WriteLog("�û����Ӻ���  �û�ID=%d,Ŀ��ID=%d��Type=%d(0--���ӣ�1---ɾ��)",DL_Data._data.UserID,DL_Data._data.TargetUserID,DL_Data._data.iType);
    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_USERADDORDEL_FRIEND,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}

///�������ɾ������  �������
bool Friend::UserAddorDelFriendResponse(DataBaseResultLine* pResultData)
{
    
    DL_O_HALL_UserAddFriend* pData = (DL_O_HALL_UserAddFriend*)pResultData;
    int sendret=_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_outdata, sizeof(pData->_outdata), MDM_GP_FRIEND,ASS_GP_USERADDORDEL_FRIEND,pResultData->uHandleRusult,pResultData->dwHandleID);
    WriteLog("������Ӻ��Ѹ��ͻ��˷�������  ���ݴ�С=%d",sendret);

    return true;
}

///������Ӻ���  ����
bool Friend::UserGetFriendList(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_UserGetFriendList))
    {
        return false;
    }

    DL_I_HALL_UserGetFriendList DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_UserGetFriendList));


    WriteLog("�û���ȡ�����б�  �û�ID=%d",DL_Data._data.UserID);
    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_USERGETFRIENDLIST,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


    ///��һ�ȡ�����б�  �������
bool Friend::UserGetFriendListResponse(DataBaseResultLine* pResultData)
{

    DL_O_HALL_UserGetFriendList* pHandleResult= (DL_O_HALL_UserGetFriendList*)pResultData;
    if(!pHandleResult)
    {
        //WriteLog("Err 4");
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_UserGetFriendList_Head))/sizeof(MSG_GP_O_UserGetFriendList_Data);
    int SendCount = 0;
    int SendTotalcount = 0;
    WriteLog("��ȡ�����б� Ӧ��");
    while(SendCount*iMax < pHandleResult->_data.FriendCount)
    {
        int PreSend = (pHandleResult->_data.FriendCount-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.FriendCount-SendCount*iMax);
        memcpy_s(bBuffer,sizeof(MSG_GP_O_UserGetFriendList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_UserGetFriendList_Head));
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+sizeof(MSG_GP_O_UserGetFriendList_Head)+i*sizeof(MSG_GP_O_UserGetFriendList_Data),sizeof(MSG_GP_O_UserGetFriendList_Data),&pHandleResult->FriendData[i+SendCount*iMax],sizeof(MSG_GP_O_UserGetFriendList_Data));
        }
        _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_UserGetFriendList_Head)+sizeof(MSG_GP_O_UserGetFriendList_Data)*PreSend,MDM_GP_FRIEND,ASS_GP_USERGET_FRIENDLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
        SendCount++;
    }
    memcpy_s(bBuffer,sizeof(MSG_GP_O_UserGetFriendList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_UserGetFriendList_Head));
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_UserGetFriendList_Head),MDM_GP_FRIEND,ASS_GP_USERGET_FRIENDLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
    
    SafeDeleteArray(pHandleResult->FriendData);
    return true;
}



 ///��������Լ�  ����
bool Friend::UserShieldRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_UserShield))
    {
        return false;
    }

    DL_I_HALL_UserShield DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_UserShield));


    WriteLog("�û������Լ�  �û�ID=%d,%d--(0-����  1--ȡ������)",DL_Data._data.UserID);
    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_USERSHIELD,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


///�û������Լ����ݿ���
bool Friend::UserShieldResponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_UserShield* pData = (DL_O_HALL_UserShield*)pResultData;
    int sendret=_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_FRIEND,ASS_GP_USER_SHIELD,pResultData->uHandleRusult,pResultData->dwHandleID);
    WriteLog("������ι���  ���ݴ�С=%d",sendret);

    return true;
}

//�û���ȡ������Ϣ  ����
bool Friend::UserGetUserInfoRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_UserGetFriendList))    ///���û�ȡ�����б�������ṹ��
    {
        return false;
    }

    DL_I_HALL_UserGetFriendList DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_UserGetFriendList));


    WriteLog("�û���ȡ������Ϣ  ����  �û�ID=%d",DL_Data._data.UserID);
    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_USER_GETUSERINFO,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


///�û���ȡ������Ϣ ���ݿ���
bool Friend::UserGetUserInfoResponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_UserGetUserInfo* pData = (DL_O_HALL_UserGetUserInfo*)pResultData;
    int sendret=_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_FRIEND,ASS_GP_USERINFO,pResultData->uHandleRusult,pResultData->dwHandleID);
    WriteLog("�û���ȡ������Ϣ  ���ݴ�С=%d",sendret);

    return true;
}