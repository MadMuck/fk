/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

#include "StdAfx.h"
#include "HNClub.h"
#include "GameLogonManage.h"
#include "commonuse.h"

CHNClub::CHNClub(CGameLogonManage* pLogonManage)
	:_pLogonManage(pLogonManage)
{
	
}

CHNClub::~CHNClub(void)
{

}


bool CHNClub::OnNetMessage(NetMessageHead* pNetHead,void* pData,UINT uSize,ULONG uAccessIP,UINT uIndex,DWORD dwHandleID)
{
	if (!_pLogonManage) 
	{
		return true;
	}

	if (MDM_GP_CLUB != pNetHead->bMainID)
	{
		return true;
	}

	switch(pNetHead->bAssistantID)
	{
	case ASS_GP_CREATE_CLUB:
		{
			return createClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_DISSMISS_CLUB:
		{
			return dissmissClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_JOIN_CLUB:
		{
			return joinClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_USERLIST:
		{
			return getUserListRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_TALK:
		{
			return talkInClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_ROOMLIST:
		{
			return getRoomListRequest(pData,uSize,uIndex,dwHandleID);   //���ֲ������б�
		}break;
	case ASS_GP_CLUB_CREATEROOM:
		{
			return buyDeskInClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_CHANGENAME:
		{
			return changeNameRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_KICKUSER:
		{
			return kickUserRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_LIST:
		{
			return getClubListRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_REVIEW_LIST:
		{
			return getReviewListRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_MASTER_OPTION:
		{
			return masterOptionRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_CLUB_NOTICE:
		{
			return setClubNoticeRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_ENTER_CLUB:
		{
			return enterClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_LEAVE_CLUB:
		{
			return leaveClubRequest(pData,uSize,uIndex,dwHandleID);
		}break;
	case ASS_GP_GET_BUYDESKRECORD:
		{
			return getBuyDeskRecordRequest(pData,uSize,uIndex,dwHandleID);
		}break;
    case ASS_GP_ADD_CLUBPLAYINFO:   //����¥�㣨�淨��
        {
            return clubAddPlayInfo(pData, uSize, uIndex, dwHandleID);
        }break;
    case ASS_GP_GET_PLAYINFOLIST:    //��ȡ¥�㣨�淨���б�
        {
            WriteLog("�յ� 143--27��Ϣ+��ȡ¥�㣨�淨���б�");
            return clubGetPlayInfoList(pData, uSize, uIndex, dwHandleID);
        }break;
    case ASS_GP_DEL_PLAYINFO:           //ɾ��¥�㣨�淨��
        {
            return clubDelPlayInfo(pData, uSize, uIndex, dwHandleID);
        }break;
    case ASS_GP_CLUBUSERHEADURLLIST:    //���ֲ����ͷ���ַ
        {
            return clubUserHeadURLList(pData, uSize, uIndex, dwHandleID);
        }break;
    case ASS_GP_USER_ENTERCLUBDESK:     //��ҽ�����ֲ�����
        {
            return UserEnterClubDesk(pData, uSize, uIndex, dwHandleID);
        }break;
    case ASS_GP_USER_EXCLUSION:             //�ų⹦��
        {
            return UserExclusion(pData, uSize, uIndex, dwHandleID);
        }break;    
     case ASS_GP_GET_EXCLUSION_TABLE:    //��ȡ����ų��
        {
            return ClubGetUserExclusionTable(pData, uSize, uIndex, dwHandleID);
        }break;    
    case ASS_GP_CLUB_UPLOWPOINTS:            //���ֲ����·�
        {
            return UpLowPointsRequest(pData,uSize,uIndex,dwHandleID);
        }break;
    case ASS_GP_CLUB_SEEKUSER:               ///�������
        {
            return ClubSeekUserRequest(pData,uSize,uIndex,dwHandleID);
        }break;
    case ASS_GP_USERINTO_CLUB:             ///���ֲ���������
        {
            return UserIntoClubRequest(pData,uSize,uIndex,dwHandleID);
        }
    case ASS_GP_STATISTIC_DATA:         ///��ȡͳ������
        {
            return GetStatisticDataRequest(pData,uSize,uIndex,dwHandleID);
        }
    case ASS_GP_PAIHANGBANG:
        {
            return ClubPaihangbangRequest(pData,uSize,uIndex,dwHandleID);    //���ֲ����а�
        }
    case ASS_GP_CLUB_OPERATION:       
        {
            return ClubOperationRequest(pData,uSize,uIndex,dwHandleID);    //���ֲ���Ӫ״��
        }
    case ASS_GP_CLUB_OFF_ON:
        {
            return ClubOFFOrONReques(pData,uSize,uIndex,dwHandleID);       //���ֲ�������ر�
        }
    case ASS_GP_CLUB_CHANGE_NOTICE:
        {
            return ClubChangeGroupNoticeReques(pData,uSize,uIndex,dwHandleID);       //���ֲ��޸�¥�㹫�������
        }
	default:
		break;
	}

	return true ;
}

bool CHNClub::OnDataBaseResult(DataBaseResultLine* pResultData)
{
	if (!_pLogonManage) 
	{
		return true;
	}

	switch(pResultData->uHandleKind)
	{
	case DTK_GP_CREATE_CLUB:
		{
			createClubResponse(pResultData);
		}break;	
	case DTK_GP_DISSMISS_CLUB:
		{
			dissmissClubResponse(pResultData);
		}break;	
	case DTK_GP_JOIN_CLUB:
		{
			joinClubResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_USERLIST:
		{
			getUserListResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_ROOMLIST:
		{
			getRoomListResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_CREATEROOM:
		{
			buyDeskInClubResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_CHANGENAME:
		{
			changeNameResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_KICKUSER:
		{
			kickUserResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_STATISTICS:
		{
			//createClubResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_LIST:
		{
			getClubListResponse(pResultData);
		}break;	
	case DTK_GP_REVIEW_LIST:
		{
			getReviewListResponse(pResultData);
		}break;	
	case DTK_GP_MASTER_OPTION:
		{
			masterOptionResponse(pResultData);
		}break;	
	case DTK_GP_CLUB_NOTICE:
		{
			setClubNoticeResponse(pResultData);
		}break;	
	case DTK_GP_ENTER_CLUB:
		{
			enterClubResponse(pResultData);
		}break;	
	case DTK_GP_LEAVE_CLUB:
		{
			leaveClubResponse(pResultData);
		}break;
	case DTK_GP_GET_DESKRECORD:
		{
			getBuyDeskRecordResponse(pResultData);
		}break;
    case DTK_GP_CLUB_ADD_PLAYINFO:      //���Ӿ��ֲ�¥�㣨�淨��  ���ݿ�������
        {
            clubAddPlayInfoReponse(pResultData);
        }
        break;
    case DTK_GP_CLUB_GET_PLAYINFO_LIST:   //��ȡ���ֲ�¥�㣨�淨���б�   ���ݿ�������
        {
            clubGetPlayInfoListResponse(pResultData);
        }
        break;
    case DTK_GP_CLUB_DEL_PLAYINFO:
        {
            clubDelPlayInfoReponse(pResultData);   //���ֲ�ɾ��¥�㣨�淨��   ���ݿ�������
        }
        break;
    case DTK_GP_CLUB_USERHEADURL_LIST:
        {
            clubUserHeadURLListReponse(pResultData);  //���ֲ����ͷ���б�  ���ݿ�������
        }
        break;
    case DTK_GP_CLUB_USER_ENTERCLUBDESK:
        {
            UserEnterClubDeskReponse(pResultData);       //��ҽ�����ֲ����䴦�����
        }break;
    case DTK_GP_CLUB_USER_EXCLUSION:
        {
            UserExclusionReponse(pResultData);              //�ų⹦��  ���ݿ⴦�����
        }break;
    case DTK_GP_CLUB_GET_EXCLUSIONTABLE:
        {
            ClubGetUserExclusionTableReponse(pResultData);      //���ֲ�������ȡ�ų��  ���ݿ⴦�����
        }break;
    case DTK_GP_UPLOW_POINTS:
        {
            UpLowPointsResponse(pResultData);                          //���ֲ����·ֹ���    ���ݿ⴦�����
        }break;
    case DTK_GP_CLUB_SEEKUSER:
        {
            ClubSeekUserReponse(pResultData);                          //���ֲ�������ҹ���    ���ݿ⴦�����
        }break;
    case DTK_GP_USERINTO_CLUB:
        {
            UserIntoClubReponse(pResultData);                          //���ֲ�����    ���ݿ⴦�����
        }break;
    case DTK_GP_GETSTATISTICDATA:                               
        {
            GetStatisticDataReponse(pResultData);                    ///ͳ������    ���ݿ⴦�����
        }break;
    case DTK_GP_GETPAIHANGBANG:
        {
            GetPaihangbang(pResultData);                    ///���ֲ����а�    ���ݿ⴦�����
        }break;
    case DTK_GP_CLUBOPERATION:
        {
           ClubOperationReponse(pResultData);      ///���ֲ���Ӫ״��  ���ݿ⴦�����
        }break;
    case DTK_GP_CLUBOFFORON:
        {
            ClubOFFOrONReponse(pResultData);     ///���ֲ��������߹ر�   ���ݿ⴦�����
        }break;
    case DTK_GP_CLUBCHANGEGROUPNOTICE:
        {
            ClubChangeGroupNoticeReponse(pResultData);  ///���ֲ��޸�¥�㹫��
        }break;
	default:
		return true;
	}

	return true;
}

	
bool CHNClub::createClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_CreateClub))
	{
        WriteLog("createClubRequest Size Err");
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CREATE_CLUB, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_CreateClub DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_CreateClub));
	DL_Data.iUserID = pUser->UserID;

	//string str_temp1(DL_Data._data.szClubName);
	//bool bLimite = _pLogonManage->m_HNFilter.censor(str_temp1);
	//if (bLimite)
	//{
	//	MSG_GP_O_CreateClub data;
	//	memset(&data,0,sizeof(MSG_GP_O_CreateClub));
	//	_pLogonManage->m_TCPSocket.SendData(uIndex, &data,sizeof(MSG_GP_O_CreateClub),MDM_GP_CLUB,ASS_GP_CREATE_CLUB,ERR_GP_NAME_LIMITE,0);
	//	return true;
	//}

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CREATE_CLUB,uIndex,dwHandleID);//�ύ���ݿ�


	return true;
}
	
bool CHNClub::dissmissClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_DissmissClub))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_DISSMISS_CLUB, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_DissmissClub DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_DissmissClub));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_DISSMISS_CLUB,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::joinClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)	
{
	if (uSize != sizeof(MSG_GP_I_JoinClub))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_JOIN_CLUB, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_JoinClub DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_JoinClub));
	DL_Data.iUserID = pUser->UserID;
	 
	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_JOIN_CLUB,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::getUserListRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_UserList))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_TALK, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_UserList DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_UserList));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_USERLIST,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::talkInClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_Talk))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_TALK, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	MSG_GP_I_Club_Talk	*p = (MSG_GP_I_Club_Talk*)pData;
	MSG_GP_O_Club_Talk _data;
	_data.iClubID = p->iClubID;
	_data.iUserID = pUser->UserID;
	strcpy_s(_data.szTalk,p->szTalk);

	string str_temp(_data.szTalk);
	_pLogonManage->m_HNFilter.censor(str_temp,false);
	strcpy(_data.szTalk,str_temp.c_str());

	_pLogonManage->m_TCPSocket.SendDataUnion(p->iClubID,&_data,sizeof(MSG_GP_O_Club_Talk),MDM_GP_CLUB,ASS_GP_CLUB_TALK,0);
	
	return true;
}

bool CHNClub::getRoomListRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_RoomList))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_TALK, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_RoomList DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_RoomList));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_ROOMLIST,uIndex,dwHandleID);//�ύ���ݿ�


	return true;
}

bool CHNClub::buyDeskInClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_BuyDesk))
	{
		return false;
	}

	DL_I_HALL_Club_BuyDesk DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_BuyDesk));

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_CREATEROOM,uIndex,dwHandleID);//�ύ���ݿ�


	return true;
}

bool CHNClub::changeNameRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_ChangeName))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_CHANGENAME, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_ChangeName DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_ChangeName));
	DL_Data.iUserID = pUser->UserID;

	string str_temp1(DL_Data._data.szNewClubName);
	bool bLimite = _pLogonManage->m_HNFilter.censor(str_temp1);
	if (bLimite)
	{
		MSG_GP_O_CreateClub data;
		memset(&data,0,sizeof(MSG_GP_O_CreateClub));
		_pLogonManage->m_TCPSocket.SendData(uIndex, &data,sizeof(MSG_GP_O_CreateClub),MDM_GP_CLUB,ASS_GP_CREATE_CLUB,ERR_GP_NAME_LIMITE,0);
		return true;
	}

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_CHANGENAME,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::kickUserRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_KickUser))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_KICKUSER, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_KickUser DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_KickUser));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_KICKUSER,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::getClubListRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    WriteLog("getClubListRequest");
	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_LIST, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_List DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_LIST,uIndex,dwHandleID);//�ύ���ݿ�


	return true;
}

bool CHNClub::getReviewListRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_ReviewList))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_REVIEW_LIST, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_ReviewList DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_ReviewList));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_REVIEW_LIST,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::masterOptionRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_MasterOpt))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_MASTER_OPTION, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_MasterOpt DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_MasterOpt));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_MASTER_OPTION,uIndex,dwHandleID);//�ύ���ݿ�


	return true;
}

bool CHNClub::setClubNoticeRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_Notice))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_NOTICE, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_Notice DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_Notice));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_NOTICE,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::enterClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_EnterClub))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_ENTER_CLUB, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_EnterClub DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_EnterClub));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_ENTER_CLUB,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::leaveClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_LeaveClub))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_LEAVE_CLUB, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_LeaveClub DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_LeaveClub));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_LEAVE_CLUB,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::getBuyDeskRecordRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
	if (uSize != sizeof(MSG_GP_I_Club_BuyDeskRecord))
	{
		return false;
	}

	LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

	if (!pUser)
	{
		_pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_GET_BUYDESKRECORD, ERR_GP_USER_NOT_FOUND, dwHandleID);
		return true;
	}

	DL_I_HALL_Club_GetRecord DL_Data;
	memset(&DL_Data, 0, sizeof(DL_Data));
	memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_Club_BuyDeskRecord));
	DL_Data.iUserID = pUser->UserID;

	_pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_GET_DESKRECORD,uIndex,dwHandleID);//�ύ���ݿ�

	return true;
}

bool CHNClub::createClubResponse(DataBaseResultLine* pResultData)
{
    WriteLog("createClubResponse");
	DL_O_HALL_CreateClub* pData = (DL_O_HALL_CreateClub*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CREATE_CLUB,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)
	{
		_pLogonManage->m_TCPSocket.UnionAddUser(pData->_data.iClubID,pResultData->uIndex);
	}

	return true;
}


bool CHNClub::dissmissClubResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_DissmissClub* pData = (DL_O_HALL_DissmissClub*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_DISSMISS_CLUB,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (pResultData->uHandleRusult == ERR_GP_CLUB_REQUEST_SUCCESS)
	{
		//֪ͨȺ���Ա��ɢ��Ϣ
		_pLogonManage->m_TCPSocket.SendDataBatch(&pData->_data, sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_DISSMISS_CLUB_NOTIFY,0);
		//ɾ��Ⱥ���Ա��½��¼
		_pLogonManage->m_TCPSocket.UnionRemoveAll(pData->_data.iClubID);

		if (pData->iDissmissDeskCount > 0)	//��ɢ����
		{
			for (int i=0;i<pData->iDissmissDeskCount;i++)
			{
				_pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pData->_NoticeData[i].iRoomID,&pData->_NoticeData[i],sizeof(MSG_MG_R_ClubDissmissDesk),MDM_MG_CLUB,ASS_MG_CLUB_DISSMISSDESK,0,0);
			}
			
			SafeDeleteArray(pData->_NoticeData);
		}
	}

	return true;
}

bool CHNClub::joinClubResponse(DataBaseResultLine* pResultData)
{
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,MDM_GP_CLUB,ASS_GP_JOIN_CLUB,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)	//֪ͨ������������Ϣ
	{
		DL_O_HALL_JoinClub *pHandleResult= (DL_O_HALL_JoinClub*)pResultData;

		int iSocketID = _pLogonManage->GetIndexByID(pHandleResult->iMasterID);

		if (iSocketID == -1)
		{
			return true;
		}
		_pLogonManage->m_TCPSocket.SendData(iSocketID, &pHandleResult->_UserDate, sizeof(pHandleResult->_UserDate), MDM_GP_CLUB,ASS_GP_JOIN_CLUB_TOMASTER,pResultData->uHandleRusult,0);
	}
	

	return true;
}

bool CHNClub::getUserListResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_UserList* pHandleResult= (DL_O_HALL_Club_UserList*)pResultData;
	if(!pHandleResult)
	{
		return false;
	}

	char bBuffer[MAX_SEND_SIZE];
	memset(bBuffer,0,sizeof(bBuffer));
	int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_UserList_Head))/sizeof(MSG_GP_O_Club_UserList_Data);
	int SendCount = 0;
	int SendTotalcount = 0;

	while(SendCount*iMax < pHandleResult->_data.iUserNum)
	{
		int PreSend = (pHandleResult->_data.iUserNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.iUserNum-SendCount*iMax);
		memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_UserList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_UserList_Head));
		for (int i = 0;i<PreSend;i++)
		{
			memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_UserList_Head)+i*sizeof(MSG_GP_O_Club_UserList_Data),sizeof(MSG_GP_O_Club_UserList_Data),&pHandleResult->_UserData[i+SendCount*iMax],sizeof(MSG_GP_O_Club_UserList_Data));
		}
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_UserList_Head)+sizeof(MSG_GP_O_Club_UserList_Data)*PreSend,MDM_GP_CLUB,ASS_GP_CLUB_USERLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
		SendCount++;
	}
	memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_UserList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_UserList_Head));
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_UserList_Head),MDM_GP_CLUB,ASS_GP_CLUB_USERLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

	SafeDeleteArray(pHandleResult->_UserData);

	return true;
}

bool CHNClub::getRoomListResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_RoomList* pHandleResult= (DL_O_HALL_Club_RoomList*)pResultData;
	if(!pHandleResult)
	{
		return false;
	}

	char bBuffer[MAX_SEND_SIZE];
	memset(bBuffer,0,sizeof(bBuffer));
	int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_RoomList_Head))/sizeof(MSG_GP_O_Club_RoomList_Data_NEW);
	int SendCount = 0;
	int SendTotalcount = 0;

	while(SendCount*iMax < pHandleResult->_data.iRoomNum)
	{
		int PreSend = (pHandleResult->_data.iRoomNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.iRoomNum-SendCount*iMax);
		memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_RoomList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_RoomList_Head));
		for (int i = 0;i<PreSend;i++)
		{
			memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_RoomList_Head)+i*sizeof(MSG_GP_O_Club_RoomList_Data_NEW),sizeof(MSG_GP_O_Club_RoomList_Data_NEW),&pHandleResult->_RoomData[i+SendCount*iMax],sizeof(MSG_GP_O_Club_RoomList_Data_NEW));
		}
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_RoomList_Head)+sizeof(MSG_GP_O_Club_RoomList_Data_NEW)*PreSend,MDM_GP_CLUB,ASS_GP_CLUB_ROOMLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
		SendCount++;
	}
	memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_RoomList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_RoomList_Head));
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_RoomList_Head),MDM_GP_CLUB,ASS_GP_CLUB_ROOMLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

	SafeDeleteArray(pHandleResult->_RoomData);
	return true;
}

bool CHNClub::buyDeskInClubResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_BuyDesk* pHandleResult= (DL_O_HALL_Club_BuyDesk*)pResultData;
	if(!pHandleResult)
	{
		return false;
	}

	if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)   //��������ɹ���֪ͨGserver
	{
		MSG_MG_S_CLUB_BUY_DESK_NOTICE outdata;
		outdata.iDeskID = pHandleResult->iDeskID;
		outdata.iRoomID = pHandleResult->iRoomID;
		outdata.iJewels = pHandleResult->iJewels;
		outdata.iGameID = pHandleResult->iGameID;
		memcpy_s(&outdata._data,sizeof(MSG_GP_O_Club_BuyDesk),&pHandleResult->_data,sizeof(MSG_GP_O_Club_BuyDesk));
		
		_pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pHandleResult->iRoomID,&outdata,sizeof(MSG_MG_S_CLUB_BUY_DESK_NOTICE),MDM_MG_CLUB,ASS_MG_CLUB_BUYDESK,0,0);
	}
	else
	{
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pHandleResult->_data, sizeof(pHandleResult->_data),MDM_GP_CLUB,ASS_GP_CLUB_CREATEROOM, pResultData->uHandleRusult, pResultData->dwHandleID);
	}

	return true;
}

bool CHNClub::changeNameResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_ChangeName* pData = (DL_O_HALL_ChangeName*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_CHANGENAME,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)
	{
		_pLogonManage->m_TCPSocket.SendDataUnion(pData->_data.iClubID,&pData->_data, sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_CLUB_NAME_UPDATE,0);
	}

	return true;
}

bool CHNClub::kickUserResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_KickUser* pData = (DL_O_HALL_Club_KickUser*)pResultData;

	if (0 == pResultData->uHandleRusult || 4 == pResultData->uHandleRusult)
	{ 
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_KICKUSER,ERR_GP_CLUB_REQUEST_SUCCESS,pResultData->dwHandleID);

		int iSocketID = _pLogonManage->GetIndexByID(pData->_data.iTargetID);

		if (iSocketID != -1)
		{
			_pLogonManage->m_TCPSocket.SendData(iSocketID, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_KICKUSER_TAR,ERR_GP_CLUB_REQUEST_SUCCESS,0);
			_pLogonManage->m_TCPSocket.UnionRemoveUser(pData->_data.iClubID,iSocketID);
		}
		
		_pLogonManage->m_TCPSocket.SendDataUnion(pData->_data.iClubID,&pData->_TarData, sizeof(pData->_TarData),MDM_GP_CLUB,ASS_GP_CLUB_USERCHANGE,0);

		if (pData->iDissmissDeskCount > 0)	//��ɢ����
		{
			for (int i=0;i<pData->iDissmissDeskCount;i++)
			{
				_pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pData->_NoticeData[i].iRoomID,&pData->_NoticeData[i],sizeof(MSG_MG_R_ClubDissmissDesk),MDM_MG_CLUB,ASS_MG_CLUB_DISSMISSDESK,0,0);
			}

			SafeDeleteArray(pData->_NoticeData);
		}
	}
	else
	{
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_KICKUSER,pResultData->uHandleRusult,pResultData->dwHandleID);
	}

	return true;
}

bool CHNClub::getClubListResponse(DataBaseResultLine* pResultData)
{
    WriteLog("getClubListResponse");
	DL_O_HALL_Club_List* pHandleResult= (DL_O_HALL_Club_List*)pResultData;
	if(!pHandleResult)
	{
		return false;
	}

	char bBuffer[MAX_SEND_SIZE];
	memset(bBuffer,0,sizeof(bBuffer));
	int iMax = (MAX_SEND_SIZE-24)/sizeof(MSG_GP_O_Club_List);
	int SendCount = 0;
	int SendTotalcount = 0;

	while(SendCount*iMax < pHandleResult->iCount)
	{
		int PreSend = (pHandleResult->iCount-SendCount*iMax)>iMax?iMax:(pHandleResult->iCount-SendCount*iMax);
		for (int i = 0;i<PreSend;i++)
		{
			memcpy_s(bBuffer+i*sizeof(MSG_GP_O_Club_List),sizeof(MSG_GP_O_Club_List),&pHandleResult->_data[i+SendCount*iMax],sizeof(MSG_GP_O_Club_List));
			_pLogonManage->m_TCPSocket.UnionAddUser(pHandleResult->_data[i+SendCount*iMax].iClubID,pResultData->uIndex);
		}
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_List)*PreSend,MDM_GP_CLUB,ASS_GP_CLUB_LIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
		SendCount++;
	}
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, MDM_GP_CLUB,ASS_GP_CLUB_LIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

	SafeDeleteArray(pHandleResult->_data);

	return true;
}

bool CHNClub::getReviewListResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_ReviewList* pHandleResult= (DL_O_HALL_Club_ReviewList*)pResultData;
	if(!pHandleResult)
	{
		return false;
	}

	char bBuffer[MAX_SEND_SIZE];
	memset(bBuffer,0,sizeof(bBuffer));
	int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_ReviewList_Head))/sizeof(MSG_GP_O_Club_ReviewList_Data);
	int SendCount = 0;
	int SendTotalcount = 0;

	while(SendCount*iMax < pHandleResult->_HeadData.iUserNum)
	{
		int PreSend = (pHandleResult->_HeadData.iUserNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_HeadData.iUserNum-SendCount*iMax);
		memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_ReviewList_Head),&pHandleResult->_HeadData,sizeof(MSG_GP_O_Club_ReviewList_Head));
		for (int i = 0;i<PreSend;i++)
		{
			memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_ReviewList_Head)+i*sizeof(MSG_GP_O_Club_ReviewList_Data),sizeof(MSG_GP_O_Club_ReviewList_Data),&pHandleResult->_Data[i+SendCount*iMax],sizeof(MSG_GP_O_Club_ReviewList_Data));
		}
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_ReviewList_Head)+sizeof(MSG_GP_O_Club_ReviewList_Data)*PreSend,MDM_GP_CLUB,ASS_GP_REVIEW_LIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
		SendCount++;
	}
	memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_ReviewList_Head),&pHandleResult->_HeadData,sizeof(MSG_GP_O_Club_ReviewList_Head));
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_ReviewList_Head),MDM_GP_CLUB,ASS_GP_REVIEW_LIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

	SafeDeleteArray(pHandleResult->_Data);
	return true;
}

bool CHNClub::masterOptionResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_MasterOpt* pData = (DL_O_HALL_Club_MasterOpt*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_Data, sizeof(pData->_Data), MDM_GP_CLUB,ASS_GP_MASTER_OPTION,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)
	{
		int iSocketID = _pLogonManage->GetIndexByID(pData->_Data.iTargetID);

		if (pData->_Data.bOptType == 0)		//ͬ��
		{
			if (iSocketID != -1)
			{
				_pLogonManage->m_TCPSocket.SendData(iSocketID, &pData->_ClubData, sizeof(pData->_ClubData), MDM_GP_CLUB,ASS_GP_CLUB_JOINRESULT,0,0);
				_pLogonManage->m_TCPSocket.UnionAddUser(pData->_Data.iClubID,iSocketID);
			}

			_pLogonManage->m_TCPSocket.SendDataUnion(pData->_Data.iClubID,&pData->_TarData, sizeof(pData->_TarData),MDM_GP_CLUB,ASS_GP_CLUB_USERCHANGE,0);
		}
		else if (pData->_Data.bOptType == 1 || pData->_Data.bOptType == 2)			//�ܾ�
		{
			if (iSocketID != -1)
			{
				_pLogonManage->m_TCPSocket.SendData(iSocketID, &pData->_ClubData, sizeof(pData->_ClubData), MDM_GP_CLUB,ASS_GP_CLUB_JOINRESULT,1,0);
			}
		}
		

	}


	return true;
}

bool CHNClub::setClubNoticeResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_Notice* pData = (DL_O_HALL_Club_Notice*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_NOTICE,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)
	{
		_pLogonManage->m_TCPSocket.SendDataUnion(pData->_data.iClubID,&pData->_data, sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_CLUB_NOTICE_UPDATE,0);
	}
	return true;
}

bool CHNClub::enterClubResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_EnterClub* pData = (DL_O_HALL_Club_EnterClub*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_ENTER_CLUB,pResultData->uHandleRusult,pResultData->dwHandleID);

	/*if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)
	{
		_pLogonManage->m_TCPSocket.UnionAddUser(pData->_data.iClubID,pResultData->uIndex);
	}*/

	return true;
}

bool CHNClub::leaveClubResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_LeaveClub* pData = (DL_O_HALL_Club_LeaveClub*)pResultData;
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_LEAVE_CLUB,pResultData->uHandleRusult,pResultData->dwHandleID);

	if (pResultData->uHandleRusult == ERR_GP_CLUB_REQUEST_SUCCESS)
	{
		//ɾ���ó�Ա����
		_pLogonManage->m_TCPSocket.UnionRemoveUser(pData->_data.iClubID,pResultData->uIndex);
		//֪ͨȺ���Ա�˳���Ϣ
		_pLogonManage->m_TCPSocket.SendDataUnion(pData->_data.iClubID,&pData->_UserData, sizeof(pData->_UserData),MDM_GP_CLUB,ASS_GP_CLUB_USERCHANGE,0);
		
	}

	return true;
}






bool CHNClub::OnHandleClubBuyDeskResult(NetMessageHead *pNetHead, void* pData, UINT uSize, ULONG uAccessIP, UINT uIndex, DWORD dwHandleID)
{
	if(uSize != sizeof(MSG_MG_S_CLUB_BUY_DESK_NOTICE))
		return false;
	MSG_MG_S_CLUB_BUY_DESK_NOTICE* pReciveData = (MSG_MG_S_CLUB_BUY_DESK_NOTICE*)pData;
	if (!pReciveData)
		return true;

	LPUSER p = _pLogonManage->GetUserByID(pReciveData->_data.iUserID);
	if (!p)
	{
		return true;
	}
	if (pReciveData->bSuccess)
	{
		//_pLogonManage->m_TCPSocket.SendData(p->iSocketIndex,&pReciveData->_data,sizeof(pReciveData->_data),MDM_GP_CLUB,ASS_GP_CLUB_CREATEROOM,0,0);
        WriteLog("�����ɹ�  ���ͻ��˷���143---30��Ϣ���Ӻ���=%s,GroupID=%d",pReciveData->_data._RoomData.szDeskPass,pReciveData->_data.GroupID);
        MSG_GP_O_UserEnterClubDesk  data;
        memset(&data,0,sizeof(data));
        int retB;
        memcpy_s(data.szDeskPass,sizeof(data.szDeskPass),pReciveData->_data._RoomData.szDeskPass,sizeof(data.szDeskPass));
        retB=_pLogonManage->m_TCPSocket.SendData(p->iSocketIndex,&data,sizeof(data),MDM_GP_CLUB,ASS_GP_USER_ENTERCLUBDESK,0,0);
        WriteLog("retB=%d",retB);
		MSG_GP_O_Club_RoomChange _RoomChange;
        _RoomChange.GroupID=pReciveData->_data.GroupID;
		_RoomChange.bCreate = true;
		_RoomChange.iClub = pReciveData->_data.iClubID;
		memcpy_s(&_RoomChange._data,sizeof(MSG_GP_O_Club_RoomList_Data),&pReciveData->_data._RoomData,sizeof(MSG_GP_O_Club_RoomList_Data));
        _RoomChange._data.bAllowEnter = true;
        _RoomChange._data.bIsPlay = false;
		_pLogonManage->m_TCPSocket.SendDataUnion(pReciveData->_data.iClubID,&_RoomChange, sizeof(_RoomChange),MDM_GP_CLUB,ASS_GP_CLUB_ROOMCHANGE,0);
	}
	else  //����ʧ��
    {
        WriteLog("���ֲ���������ʧ��");
        MSG_GP_O_UserEnterClubDesk  data;
        memset(&data,0,sizeof(data));
		_pLogonManage->m_TCPSocket.SendData(p->iSocketIndex,&data,sizeof(data),MDM_GP_CLUB,ASS_GP_USER_ENTERCLUBDESK,9,0);
    }
	return true;
}

bool CHNClub::OnHandleClubClearDeskResult(NetMessageHead *pNetHead, void* pData, UINT uSize, ULONG uAccessIP, UINT uIndex, DWORD dwHandleID)
{
	if(uSize != sizeof(MSG_GP_O_Club_RoomChange))
		return false;
	MSG_GP_O_Club_RoomChange* pReciveData = (MSG_GP_O_Club_RoomChange*)pData;
	if (!pReciveData)
		return true;

	_pLogonManage->m_TCPSocket.SendDataUnion(pReciveData->iClub,pReciveData, sizeof(MSG_GP_O_Club_RoomChange),MDM_GP_CLUB,ASS_GP_CLUB_ROOMCHANGE,0);

	return true;
}

bool CHNClub::getBuyDeskRecordResponse(DataBaseResultLine* pResultData)
{
	DL_O_HALL_Club_GetRecord* pHandleResult= (DL_O_HALL_Club_GetRecord*)pResultData;
	if(!pHandleResult)
	{
		return false;
	}

	char bBuffer[MAX_SEND_SIZE];
	memset(bBuffer,0,sizeof(bBuffer));
	int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_BuyDeskRecord_Head))/sizeof(MSG_GP_O_Club_BuyDeskRecord_Data);
	int SendCount = 0;
	int SendTotalcount = 0;
	 
	while(SendCount*iMax < pHandleResult->_HeadData.iDataNum)
	{
		int PreSend = (pHandleResult->_HeadData.iDataNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_HeadData.iDataNum-SendCount*iMax);
		memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_BuyDeskRecord_Head),&pHandleResult->_HeadData,sizeof(MSG_GP_O_Club_BuyDeskRecord_Head));
		for (int i = 0;i<PreSend;i++)
		{
			memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_BuyDeskRecord_Head)+i*sizeof(MSG_GP_O_Club_BuyDeskRecord_Data),sizeof(MSG_GP_O_Club_BuyDeskRecord_Data),&pHandleResult->_Data[i+SendCount*iMax],sizeof(MSG_GP_O_Club_BuyDeskRecord_Data));
		}
		_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_BuyDeskRecord_Head)+sizeof(MSG_GP_O_Club_BuyDeskRecord_Data)*PreSend,MDM_GP_CLUB,ASS_GP_GET_BUYDESKRECORD, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
		SendCount++;
	}
	memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_BuyDeskRecord_Head),&pHandleResult->_HeadData,sizeof(MSG_GP_O_Club_BuyDeskRecord_Head));
	_pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_BuyDeskRecord_Head),MDM_GP_CLUB,ASS_GP_GET_BUYDESKRECORD, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

	SafeDeleteArray(pHandleResult->_Data);

	return true;
}

//��ȡ���ֲ�¥�㣨�淨���б�
bool CHNClub::clubGetPlayInfoList(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    WriteLog("clubGetPlayInfoList");
    if(uSize != sizeof(MSG_GP_I_GetClubPlayInfo)) return false;

    MSG_GP_I_GetClubPlayInfo *pInData = (MSG_GP_I_GetClubPlayInfo*)pData;

    DL_I_HALL_GetClubPlayInfo inData;
    inData.inData = *pInData;

    _pLogonManage->m_SQLDataManage.PushLine(&inData.DataBaseLineHead, sizeof(inData), DTK_GP_CLUB_GET_PLAYINFO_LIST, uIndex, 0);

    return true;
}

//���ֲ�����¥�㣨�淨��
bool CHNClub::clubAddPlayInfo(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if(uSize != sizeof(MSG_GP_I_AddClubPlayInfo)) return false;
    MSG_GP_I_AddClubPlayInfo *pInData = (MSG_GP_I_AddClubPlayInfo*)pData;

    DL_I_HALL_AddClubPlayInfo inData;
    inData.inData = *pInData;

    _pLogonManage->m_SQLDataManage.PushLine(&inData.DataBaseLineHead, sizeof(inData), DTK_GP_CLUB_ADD_PLAYINFO, uIndex, 0);

    return true;
}

//���ֲ�ɾ��¥�㣨�淨��
bool CHNClub::clubDelPlayInfo(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if(uSize != sizeof(MSG_GP_I_DelClubPlayInfo)) return false;
    MSG_GP_I_DelClubPlayInfo *pInData = (MSG_GP_I_DelClubPlayInfo*)pData;


    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_DEL_PLAYINFO, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_HALL_DelClubPlayInfo inData;
    inData.inData = *pInData;
    inData.UserID=pUser->UserID;
    _pLogonManage->m_SQLDataManage.PushLine(&inData.DataBaseLineHead, sizeof(inData), DTK_GP_CLUB_DEL_PLAYINFO, uIndex, 0);

    return true;
}

//���ֲ�����¥�㣨�淨��  ���ݿ⴦�����
bool CHNClub::clubAddPlayInfoReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_AddClubPlayInfo *pOutData = (DL_O_HALL_AddClubPlayInfo*)pResultData;
   
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,MDM_GP_CLUB,ASS_GP_ADD_CLUBPLAYINFO, pResultData->uHandleRusult, 0);

    if(pResultData->uHandleRusult == 0)
    {
        _pLogonManage->m_TCPSocket.SendDataUnion(pOutData->outData.data.iClubID, &pOutData->outData, sizeof(pOutData->outData), MDM_GP_CLUB, ASS_GP_UPDATE_CLUBPLAYINFO, 0);
        if(2 == pOutData->outData.iType)
        {
            for (int i=0;i<pOutData->DeskNum;i++)
            {
                _pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pOutData->DeskData[i].iRoomID,&pOutData->DeskData[i],sizeof(MSG_MG_R_ClubDissmissDesk),MDM_MG_CLUB,ASS_MG_CLUB_DISSMISSDESK,0,0);
                //֪ͨ��Ϸ��ɢ����
            }

            SafeDeleteArray(pOutData->DeskData);
        }
    }

    return true;
}

//��ȡ���ֲ�¥�㣨�淨���б�  ���ݿ⴦�����
bool CHNClub::clubGetPlayInfoListResponse(DataBaseResultLine* pResultData)
{
    WriteLog("�ظ�");
    DL_O_HALL_GetClubPlayInfo* pHandleResult= (DL_O_HALL_GetClubPlayInfo*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_GetClubPlayInfo))/sizeof(MSG_GP_O_GetClubPlayInfo);
    int SendCount = 0;
    int SendTotalcount = 0;

    while(SendCount*iMax < pHandleResult->iNumber)
    {
        int PreSend = (pHandleResult->iNumber-SendCount*iMax)>iMax?iMax:(pHandleResult->iNumber-SendCount*iMax);
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+i*sizeof(MSG_GP_O_GetClubPlayInfo),sizeof(MSG_GP_O_GetClubPlayInfo),&pHandleResult->outData[i+SendCount*iMax],sizeof(MSG_GP_O_GetClubPlayInfo));
        }
        _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_GetClubPlayInfo)*PreSend,MDM_GP_CLUB,ASS_GP_GET_PLAYINFOLIST, 0, 0);
        SendCount++;
    }
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,MDM_GP_CLUB,ASS_GP_GET_PLAYINFOLIST, 0, 0);

    SafeDeleteArray(pHandleResult->outData);
}

//���ֲ�ɾ��¥�㣨�淨��  ���ݿ⴦�����
bool CHNClub::clubDelPlayInfoReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_DelClubPlayInfo *pOutData = (DL_O_HALL_DelClubPlayInfo*)pResultData;

    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,MDM_GP_CLUB,ASS_GP_DEL_PLAYINFO, pResultData->uHandleRusult, 0);
    WriteLog("���ֲ�ɾ��Ⱥ Ӧ�� SendData GroupID=%d",pOutData->outData.data.GroupID);
    if(pResultData->uHandleRusult == 0)
    {
        _pLogonManage->m_TCPSocket.SendDataUnion(pOutData->outData.data.iClubID, &pOutData->outData, sizeof(pOutData->outData), MDM_GP_CLUB, ASS_GP_UPDATE_CLUBPLAYINFO, 0);
        if (pOutData->iDissmissDeskCount > 0)	//��ɢ����
        {
            for (int i=0;i<pOutData->iDissmissDeskCount;i++)
            {
                _pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pOutData->_NoticeData[i].iRoomID,&pOutData->_NoticeData[i],
                sizeof(MSG_MG_R_ClubDissmissDesk),MDM_MG_CLUB,ASS_MG_CLUB_DISSMISSDESK,0,0);
            }

            SafeDeleteArray(pOutData->_NoticeData);
        }
    }

    return true;
}



//���ֲ����ͷ���б� ����
bool CHNClub::clubUserHeadURLList(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if(uSize != sizeof(MSG_GP_I_UserHeadURLList)) return false;
    MSG_GP_I_UserHeadURLList *pInData = (MSG_GP_I_UserHeadURLList*)pData;


    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUBUSERHEADURLLIST, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_HALL_UserHeadURLList inData;
    inData.inData = *pInData;
    inData.UserID=pUser->UserID;
    _pLogonManage->m_SQLDataManage.PushLine(&inData.DataBaseLineHead, sizeof(inData), DTK_GP_CLUB_USERHEADURL_LIST, uIndex, 0);

    return true;
}


///���ֲ����ͷ���ַ  ���ݿ⴦�����  ���ͻ��˷�����Ϣ
bool CHNClub::clubUserHeadURLListReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_Club_UserHeadURLList* pHandleResult= (DL_O_HALL_Club_UserHeadURLList*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_UserHeadURLList_Head))/sizeof(MSG_GP_O_Club_UserHeadURLList_Data);
    int SendCount = 0;
    int SendTotalcount = 0;

    while(SendCount*iMax < pHandleResult->_data.UserHeadURLNum)
    {
        int PreSend = (pHandleResult->_data.UserHeadURLNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.UserHeadURLNum-SendCount*iMax);
        memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_UserHeadURLList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_UserHeadURLList_Head));
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_UserHeadURLList_Head)+i*sizeof(MSG_GP_O_Club_UserHeadURLList_Data),sizeof(MSG_GP_O_Club_UserHeadURLList_Data),
            &pHandleResult->_RoomData[i+SendCount*iMax],sizeof(MSG_GP_O_Club_UserHeadURLList_Data));
        }
        int ret = _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_UserHeadURLList_Head)+sizeof(MSG_GP_O_Club_UserHeadURLList_Data)*PreSend,MDM_GP_CLUB,ASS_GP_CLUBUSERHEADURLLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
        WriteLog("ret=%d",ret);
        SendCount++;
    }
    memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_UserHeadURLList_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_UserHeadURLList_Head));
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_UserHeadURLList_Head),MDM_GP_CLUB,ASS_GP_CLUBUSERHEADURLLIST, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

    SafeDeleteArray(pHandleResult->_RoomData);
    return true;
}


//��ҽ�����ֲ�����  ���� 143--30��Ϣ
bool CHNClub::UserEnterClubDesk(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if(uSize != sizeof(MSG_GP_I_UserEnterClubDesk)) return false;
    MSG_GP_I_UserEnterClubDesk *pInData = (MSG_GP_I_UserEnterClubDesk*)pData;


    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_USER_ENTERCLUBDESK, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_HALL_UserEnterClubDesk  inData;
    inData.inData = *pInData;
    inData.UserID=pUser->UserID;
    _pLogonManage->m_SQLDataManage.PushLine(&inData.DataBaseLineHead, sizeof(inData), DTK_GP_CLUB_USER_ENTERCLUBDESK, uIndex, 0);
    
    return true;
}

///143---30��Ϣ ��ҽ�����ֲ�����  ���ݿ⴦�����

bool CHNClub::UserEnterClubDeskReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_Club_BuyDesk* pHandleResult= (DL_O_HALL_Club_BuyDesk*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }
    WriteLog("143---30��Ϣ ��ҽ�����ֲ�����  ���ݿ⴦�����pResultData->uHandleRusult=%d",pResultData->uHandleRusult);
    if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)   //��������ɹ���֪ͨGserver
    {
        MSG_MG_S_CLUB_BUY_DESK_NOTICE outdata;
        outdata.iDeskID = pHandleResult->iDeskID;
        outdata.iRoomID = pHandleResult->iRoomID;
        outdata.iJewels = pHandleResult->iJewels;
        outdata.iGameID = pHandleResult->iGameID;
        memcpy_s(&outdata._data,sizeof(MSG_GP_O_Club_BuyDesk),&pHandleResult->_data,sizeof(MSG_GP_O_Club_BuyDesk));

        _pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pHandleResult->iRoomID,&outdata,sizeof(MSG_MG_S_CLUB_BUY_DESK_NOTICE),MDM_MG_CLUB,ASS_MG_CLUB_BUYDESK,0,0);
    }
    else
    {
        MSG_GP_O_UserEnterClubDesk  data;
        int retA;
       memcpy_s(data.szDeskPass,sizeof(data.szDeskPass),pHandleResult->_data._RoomData.szDeskPass,sizeof(data.szDeskPass));
        
       retA =  _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &data, sizeof(data),MDM_GP_CLUB,ASS_GP_USER_ENTERCLUBDESK, pResultData->uHandleRusult, pResultData->dwHandleID);
       WriteLog("retA=%d",retA);
    }

    return true;
}

///�ų⹦��   ����
bool CHNClub::UserExclusion(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    WriteLog("�յ�  143---31����");
    if(uSize != sizeof(MSG_GP_I_UserExclusion)) return false;
    MSG_GP_I_UserExclusion *pInData = (MSG_GP_I_UserExclusion*)pData;


    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_USER_EXCLUSION,ERR_GP_USER_NOT_FOUND , dwHandleID);
        return true;
    }
    DL_I_HALL_UserExclusion  inData;
    inData.indata = *pInData;
    inData.UserID=pUser->UserID;
    _pLogonManage->m_SQLDataManage.PushLine(&inData.DataBaseLineHead, sizeof(inData), DTK_GP_CLUB_USER_EXCLUSION, uIndex, 0);

    return true;
}


//�ų⹦��  ���ݿ⴦�����
bool CHNClub::UserExclusionReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_UserExclusion *pOutData = (DL_O_HALL_UserExclusion*)pResultData;

   _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,&pOutData->indata,sizeof(pOutData->indata),MDM_GP_CLUB,ASS_GP_USER_EXCLUSION, pResultData->uHandleRusult, 0);
     
    return true;
}


///��ȡ���ֲ��ų��б� ����
bool CHNClub::ClubGetUserExclusionTable(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_GetExclusionTable))
    {
        return false;
    }

    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_GET_EXCLUSION_TABLE, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }

    DL_I_HALL_Club_GetExclusionTable DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_GetExclusionTable));
    DL_Data.iUserID = pUser->UserID;

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_GET_EXCLUSIONTABLE,uIndex,dwHandleID);//�ύ���ݿ�


    return true;
}


///���ֲ�������ȡ�ų��  ���ݿ�������
bool CHNClub::ClubGetUserExclusionTableReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_Club_GetExclusionTable* pHandleResult= (DL_O_HALL_Club_GetExclusionTable*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_GetExclusionTable_Head))/sizeof(MSG_GP_O_Club_GetExclusionTable);
    int SendCount = 0;
    int SendTotalcount = 0;

    while(SendCount*iMax < pHandleResult->_Head.UserNum)
    {
        int PreSend = (pHandleResult->_Head.UserNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_Head.UserNum-SendCount*iMax);
        memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_GetExclusionTable_Head),&pHandleResult->_Head,sizeof(MSG_GP_O_Club_GetExclusionTable_Head));
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_GetExclusionTable_Head)+i*sizeof(MSG_GP_O_Club_GetExclusionTable),sizeof(MSG_GP_O_Club_GetExclusionTable),&pHandleResult->_data[i+SendCount*iMax],sizeof(MSG_GP_O_Club_GetExclusionTable));
        }
        _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_GetExclusionTable_Head)+sizeof(MSG_GP_O_Club_GetExclusionTable)*PreSend,MDM_GP_CLUB,ASS_GP_GET_EXCLUSION_TABLE, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
        SendCount++;
    }
    memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_GetExclusionTable_Head),&pHandleResult->_Head,sizeof(MSG_GP_O_Club_GetExclusionTable_Head));
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_GetExclusionTable_Head),MDM_GP_CLUB,ASS_GP_GET_EXCLUSION_TABLE, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

    SafeDeleteArray(pHandleResult->_data);
    return true;
}

///���ֲ����·ֹ���
bool CHNClub::UpLowPointsRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_UpLowPoints))
    {   
        return false;
    }

    DL_I_ClubUpLowPoints DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_UpLowPoints));

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_UPLOW_POINTS,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


///���ֲ����·ֹ��� ���ݿ⴦�����
bool CHNClub::UpLowPointsResponse(DataBaseResultLine* pResultData)
{
    DL_O_ClubUpLowPoints* pData = (DL_O_ClubUpLowPoints*)pResultData;

     WriteLog("UpLowPointsResponse::uIndex:%d,UserID:%d,TargetUserID:%d",pResultData->uIndex,pData->_data.iUserID,pData->_data.iTargetUserID);
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,&pData->_data,sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_CLUB_UPLOWPOINTS,pResultData->uHandleRusult,0);

    if(pData->bIsPlay)   //����Ϸ��
    {
        _pLogonManage->m_pGameManageModule->m_LogonManage.SendData(pData->_Notice.iRoomID,&pData->_Notice,sizeof(MSG_GP_O_UpLowPointsNotice),MDM_MG_CLUB,ASS_MG_CLUB_UPLOWPOINTNOTICE,0,0);
    }
    else
    {
        if(pData->_data.iUserID != pData->_data.iTargetUserID)
        {
            if(_pLogonManage->IsUserAlreadyLogon(pData->_data.iTargetUserID))
            {
                LPUSER pUser = _pLogonManage->GetUserByID(pData->_data.iTargetUserID);  //֪ͨĿ���û�
                _pLogonManage->m_TCPSocket.SendData(pUser->iSocketIndex,&pData->_data,sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_CLUB_UPLOWPOINTS,pResultData->uHandleRusult,0);
            } 
        }
    }

    return true;
}

///���ֲ��������  ����
bool CHNClub::ClubSeekUserRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_ClubSeeKUser))
    {   
        return false;
    }
    WriteLog("�յ� 143--34��Ϣ  �������ֲ����");
    DL_I_ClubSeekUserID DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_ClubSeeKUser));

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUB_SEEKUSER,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


///���ֲ��������  ���ݿɴ������
bool CHNClub::ClubSeekUserReponse(DataBaseResultLine* pResultData)
{
    DL_O_ClubSeekUser *pOutData = (DL_O_ClubSeekUser*)pResultData;
    
    int retA = _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex,&pOutData->_data,sizeof(pOutData->_data),MDM_GP_CLUB,ASS_GP_CLUB_SEEKUSER,pResultData->uHandleRusult, pResultData->dwHandleID);
    WriteLog("���ֲ�������� ���ݿ⴦�����  ���ͻ��˷���143---34��Ϣ pResultData->uHandleRusult=%d,retA=%d",pResultData->uHandleRusult,retA);
    return true;
}


///���ֲ�����  ����
bool CHNClub::UserIntoClubRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_UserIntoClub))
    {   
        return false;
    }
    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_USERINTO_CLUB, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_UserIntoClub DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    DL_Data.MasterID=pUser->UserID;
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_UserIntoClub));

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_USERINTO_CLUB,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}

///���ֲ�����   ���ݿ⴦�����
bool CHNClub::UserIntoClubReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_UserIntoClub* pData = (DL_O_HALL_UserIntoClub*)pResultData;
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_Data, sizeof(pData->_Data), MDM_GP_CLUB,ASS_GP_USERINTO_CLUB,pResultData->uHandleRusult,pResultData->dwHandleID);

    if (ERR_GP_CLUB_REQUEST_SUCCESS == pResultData->uHandleRusult)
    {
        int iSocketID = _pLogonManage->GetIndexByID(pData->_Data.iTargetID);

        if (pData->_Data.bOptType == 0)		//ͬ��
        {
            if (iSocketID != -1)
            {
                _pLogonManage->m_TCPSocket.SendData(iSocketID, &pData->_ClubData, sizeof(pData->_ClubData), MDM_GP_CLUB,ASS_GP_CLUB_JOINRESULT,0,0);
                _pLogonManage->m_TCPSocket.UnionAddUser(pData->_Data.iClubID,iSocketID);
            }

            _pLogonManage->m_TCPSocket.SendDataUnion(pData->_Data.iClubID,&pData->_TarData, sizeof(pData->_TarData),MDM_GP_CLUB,ASS_GP_CLUB_USERCHANGE,0);
        }
        else if (pData->_Data.bOptType == 1 || pData->_Data.bOptType == 2)			//�ܾ�
        {
            WriteLog("�������  �����Ķ�����");
            if (iSocketID != -1)
            {
                _pLogonManage->m_TCPSocket.SendData(iSocketID, &pData->_ClubData, sizeof(pData->_ClubData), MDM_GP_CLUB,ASS_GP_CLUB_JOINRESULT,1,0);
            }
        }

    }
    return true;
}



 ///��ȡͳ������  ����
bool CHNClub::GetStatisticDataRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_GetStatisticData))
    {   
        return false;
    }
    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_STATISTIC_DATA, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_GetStatisticData DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_GetStatisticData));

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_GETSTATISTICDATA,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}

///ͳ������  ���ݿ�������
bool CHNClub::GetStatisticDataReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_GetStatisticData* pHandleResult= (DL_O_HALL_GetStatisticData*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head))/sizeof(MSG_GP_O_ClubGetStatisticData);
    int SendCount = 0;
    int SendTotalcount = 0;

    while(SendCount*iMax < pHandleResult->_data.UserNum)
    {
        int PreSend = (pHandleResult->_data.UserNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.UserNum-SendCount*iMax);
        memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head));
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head)+i*sizeof(MSG_GP_O_ClubGetStatisticData),sizeof(MSG_GP_O_ClubGetStatisticData),&pHandleResult->_UserData[i+SendCount*iMax],sizeof(MSG_GP_O_ClubGetStatisticData));
        }
        _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head)+sizeof(MSG_GP_O_ClubGetStatisticData)*PreSend,MDM_GP_CLUB,ASS_GP_STATISTIC_DATA, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
        SendCount++;
    }
    memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head));
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_ClubGetStatisticData_Head),MDM_GP_CLUB,ASS_GP_STATISTIC_DATA, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

    SafeDeleteArray(pHandleResult->_UserData);

    return true;
}

///���ֲ����а�  ���� 
bool CHNClub::ClubPaihangbangRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_GetPaihangbang))
    {   
        return false;
    }
    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_PAIHANGBANG, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_GetPaihangbang DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_GetPaihangbang));

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_GETPAIHANGBANG,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}

///���ֲ����а� ���ݿ⴦�����
bool CHNClub::GetPaihangbang(DataBaseResultLine* pResultData)
{
    DL_O_HALL_GetPaihangbang* pHandleResult= (DL_O_HALL_GetPaihangbang*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_GetPaihangbang_Head))/sizeof(MSG_GP_O_ClubGetPaihangbang_Data);
    int SendCount = 0;
    int SendTotalcount = 0;

    while(SendCount*iMax < pHandleResult->_data.UserNum)
    {
        int PreSend = (pHandleResult->_data.UserNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.UserNum-SendCount*iMax);
        memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_GetPaihangbang_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_GetPaihangbang_Head));
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_GetPaihangbang_Head)+i*sizeof(MSG_GP_O_ClubGetPaihangbang_Data),sizeof(MSG_GP_O_ClubGetPaihangbang_Data),&pHandleResult->_UserData[i+SendCount*iMax],sizeof(MSG_GP_O_ClubGetPaihangbang_Data));
        }
        _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_GetPaihangbang_Head)+sizeof(MSG_GP_O_ClubGetPaihangbang_Data)*PreSend,MDM_GP_CLUB,ASS_GP_PAIHANGBANG, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
        SendCount++;
    }
    memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_GetPaihangbang_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_GetPaihangbang_Head));
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_GetPaihangbang_Head),MDM_GP_CLUB,ASS_GP_PAIHANGBANG, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

    SafeDeleteArray(pHandleResult->_UserData);

    return true;
}


///���ֲ���Ӫ״��  ����
bool CHNClub::ClubOperationRequest(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_GetExclusionTable))    ///����ṹ�帴�ô˽ṹ��
    {   
        return false;
    }
    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_OPERATION, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_HALL_Club_GetExclusionTable DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_GetExclusionTable));
    DL_Data.iUserID = pUser->UserID;

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUBOPERATION,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


///���ֲ���Ӫ״�� ���ݿ⴦�����
bool CHNClub::ClubOperationReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_ClubOperation* pHandleResult= (DL_O_HALL_ClubOperation*)pResultData;
    if(!pHandleResult)
    {
        return false;
    }

    char bBuffer[MAX_SEND_SIZE];
    memset(bBuffer,0,sizeof(bBuffer));
    int iMax = (MAX_SEND_SIZE-24-sizeof(MSG_GP_O_Club_Operation_Head))/sizeof(MSG_GP_O_Club_Operation_Data);
    int SendCount = 0;
    int SendTotalcount = 0;

    while(SendCount*iMax < pHandleResult->_data.IDataNum)
    {
        int PreSend = (pHandleResult->_data.IDataNum-SendCount*iMax)>iMax?iMax:(pHandleResult->_data.IDataNum-SendCount*iMax);
        memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_Operation_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_Operation_Head));
        for (int i = 0;i<PreSend;i++)
        {
            memcpy_s(bBuffer+sizeof(MSG_GP_O_Club_Operation_Head)+i*sizeof(MSG_GP_O_Club_Operation_Data),sizeof(MSG_GP_O_Club_Operation_Data),&pHandleResult->_UserData[i+SendCount*iMax],sizeof(MSG_GP_O_Club_Operation_Data));
        }
        int ret = _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_Operation_Head)+sizeof(MSG_GP_O_Club_Operation_Data)*PreSend,MDM_GP_CLUB,ASS_GP_CLUB_OPERATION, ERR_GP_CLUB_REQUEST_SUCCESS, 0);
        WriteLog("���ͻ��˷�������  ���ݴ�С=%d",ret);
        SendCount++;
    }
    memcpy_s(bBuffer,sizeof(MSG_GP_O_Club_Operation_Head),&pHandleResult->_data,sizeof(MSG_GP_O_Club_Operation_Head));
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, bBuffer, sizeof(MSG_GP_O_Club_Operation_Head),MDM_GP_CLUB,ASS_GP_CLUB_OPERATION, ERR_GP_CLUB_REQUEST_SUCCESS, 0);

    SafeDeleteArray(pHandleResult->_UserData);

    return true;
}

///���ֲ����ܿ������߹ر� ����
bool CHNClub::ClubOFFOrONReques(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_ClubOFFOrON))    
    {   
        return false;
    }
    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_OFF_ON, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_HALL_Club_OFFOrON DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_ClubOFFOrON));
 

    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUBOFFORON,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}


///���ֲ�������ر����ݿ⴦�����
bool CHNClub::ClubOFFOrONReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_Club_OFFOrON* pData = (DL_O_HALL_Club_OFFOrON*)pResultData;
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_OFF_ON,pResultData->uHandleRusult,pResultData->dwHandleID);
    if(0 == pResultData->uHandleRusult)
    {
        //֪ͨ���ֲ�������Ա  ���ֲ�������ر�
        _pLogonManage->m_TCPSocket.SendDataUnion(pData->_data.iClubID,&pData->_data, sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_CLUB_OFF_ON,0);
    }
    return true;
}

//�޸�¥�㹫�������  ����
bool CHNClub::ClubChangeGroupNoticeReques(void* pData,UINT uSize,UINT uIndex,DWORD dwHandleID)
{
    if (uSize != sizeof(MSG_GP_I_ClubChangeNotice))    
    {   
        return false;
    }
    LPUSER pUser = _pLogonManage->GetUserBySockIdx(uIndex);

    if (!pUser)
    {
        _pLogonManage->m_TCPSocket.SendData(uIndex,MDM_GP_CLUB,ASS_GP_CLUB_CHANGE_NOTICE, ERR_GP_USER_NOT_FOUND, dwHandleID);
        return true;
    }
    DL_I_HALL_Club_ChangeGroupNotice DL_Data;
    memset(&DL_Data, 0, sizeof(DL_Data));
    memcpy(&DL_Data._data, pData, sizeof(MSG_GP_I_ClubChangeNotice));


    _pLogonManage->m_SQLDataManage.PushLine(&DL_Data.DataBaseLineHead,sizeof(DL_Data),DTK_GP_CLUBCHANGEGROUPNOTICE,uIndex,dwHandleID);//�ύ���ݿ�

    return true;
}

///�޸�¥�㹫�洦�����
bool CHNClub::ClubChangeGroupNoticeReponse(DataBaseResultLine* pResultData)
{
    DL_O_HALL_Club_ChangeGroupNotice* pData = (DL_O_HALL_Club_ChangeGroupNotice*)pResultData;
    _pLogonManage->m_TCPSocket.SendData(pResultData->uIndex, &pData->_data, sizeof(pData->_data), MDM_GP_CLUB,ASS_GP_CLUB_CHANGE_NOTICE,pResultData->uHandleRusult,pResultData->dwHandleID);
    if(0 == pResultData->uHandleRusult)
    {
        //֪ͨ���ֲ�������Ա  
        _pLogonManage->m_TCPSocket.SendDataUnion(pData->_data.ClubID,&pData->_data, sizeof(pData->_data),MDM_GP_CLUB,ASS_GP_CLUB_CHANGE_NOTICE,0);
    }
    return true;
}