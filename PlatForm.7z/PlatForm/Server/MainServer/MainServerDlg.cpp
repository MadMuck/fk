/****************************************************************************
Copyright (c) 2014-2016 Beijing TianRuiDiAn Network Technology Co.,Ltd.
Copyright (c) 2014-2016 ShenZhen Redbird Network Polytron Technologies Inc.

http://www.hotniao.com

All of the content of the software, including code, pictures,
resources, are original. For unauthorized users, the company
reserves the right to pursue its legal liability.
****************************************************************************/

// CenterServerDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "MainServer.h"
#include "MainServerDlg.h"
#include "BuildTime.h"

#include "MD5.h"
#include "yxyDES.h"

#define IDM_TRAY_NOTIFY_MSG (WM_USER +17)

// ��ʱ��id����
enum M_TIMER_ID
{
	// ���ش���
	TIMER_HIDE_WINDOW   = 1,

	// ���������Ϣ
	TIMER_CHECK_MESSAGE = 2,

	// ֤����
	TIMER_CHECK_LICENCE = 3,
};


CString GetCPUID()

{

	CString CPUID;

	unsigned long s1,s2;

	unsigned char vendor_id[]="------------";

	char sel;

	sel='1';

	CString VernderID;

	CString MyCpuID,CPUID1,CPUID2;

	switch(sel)

	{

	case '1':

		__asm{

			xor eax,eax      //eax=0:ȡVendor��Ϣ

				cpuid    //ȡcpu idָ�����Ring3��ʹ��

				mov dword ptr vendor_id,ebx

				mov dword ptr vendor_id[+4],edx

				mov dword ptr vendor_id[+8],ecx

		}

		VernderID.Format("%s-",vendor_id);

		__asm{

			mov eax,01h   //eax=1:ȡCPU���к�

				xor edx,edx

				cpuid

				mov s1,edx

				mov s2,eax

		}

		CPUID1.Format("%08X%08X",s1,s2);

		__asm{

			mov eax,03h

				xor ecx,ecx

				xor edx,edx

				cpuid

				mov s1,edx

				mov s2,ecx

		}

		CPUID2.Format("%08X%08X",s1,s2);

		break;

	case '2':

		{

			__asm{

				mov ecx,119h

					rdmsr

					or eax,00200000h

					wrmsr

			}

		}

		AfxMessageBox("CPU id is disabled.");

		break;

	}

	MyCpuID = CPUID1+CPUID2;

	CPUID = MyCpuID;

	return CPUID;

}

DWORD GetHarddiskNum()  
{  
	char cVolume[256];                                         //   
	char cFileSysName[256];   
	DWORD dwSerialNum;                                          //Ӳ�����к�   
	DWORD dwFileNameLength;   
	DWORD dwFileSysFlag;   

	::GetVolumeInformation("C://", cVolume, 256, &dwSerialNum, &dwFileNameLength,   
		&dwFileSysFlag, cFileSysName, 256);  

	return dwSerialNum;  
} 

static unsigned __stdcall LicenseMessage(LPVOID pThreadData)
{
	CString strcpuid;
	strcpuid.Format(_T("%u"),GetHarddiskNum());

	CString s;
	s.Format("��ã����ķ�����֤�鼴�����ڣ������������ϵ��\n\n�뽫���»����뷢�͸������̣���ȡע�����ļ���\n\n%s\n\n",strcpuid.GetBuffer());

	DWORD cfgHandle=cfgOpenFile("HNGameGate.BCF");
	if(cfgHandle<0x10)
	{
		_endthreadex(0);
		return 0;
	}
	string srvDomain = cfgGetValue(cfgHandle,"MailSet","ServerDomain","");
	string userName = cfgGetValue(cfgHandle,"MailSet","SenderUserName","");
	string password = cfgGetValue(cfgHandle,"MailSet","SenderPassword","");
	string targetEmail = cfgGetValue(cfgHandle,"MailSet","TargetEmail","");
	cfgClose(cfgHandle);

	CSmtp smtp(25,srvDomain,userName,password,targetEmail,"������֤���������!",s.GetBuffer());
	smtp.SendEmail_Ex();

	_endthreadex(0);
	return 0;
}

bool checkLicense()
{
	return true;
	CString strcpuid;
	strcpuid.Format(_T("%u"),GetHarddiskNum());
	
	unsigned char szMDTemp[16];
	MD5_CTX Md5;
	Md5.MD5Update((unsigned char *)strcpuid.GetBuffer(),strcpuid.GetLength());
	Md5.MD5Final(szMDTemp);

	char m_szMD5Pass[50];
	for (int i = 0; i < 16; i ++) 
		wsprintf(&m_szMD5Pass[i * 2], "%02x", szMDTemp[i] );
	CString StrMd5CpuID = m_szMD5Pass;

	DWORD cfgHandle=cfgOpenFile("HNGameGate.BCF");
	if(cfgHandle<0x10)
		return false;
	CString license = cfgGetValue(cfgHandle,"GateServer","License","");
	cfgClose(cfgHandle);

	yxyDES des;
	string key = strcpuid.GetBuffer();
	des.InitializeKey(key);


	des.DecryptAnyLength(license.GetBuffer());
	string strtmp = des.GetPlaintextAnyLength();
	string lsecpuid;
	string date;
	if (strtmp.length() == 40)
	{
		lsecpuid = strtmp.substr(0, 32);
		date = strtmp.substr(32, 40);
	}



	string lcs = m_szMD5Pass;

	CTime tmnow = CTime::GetCurrentTime();
	string strNow = tmnow.Format("%Y%m%d").GetBuffer();


	if (lcs == lsecpuid &&  strNow <= date)
	{
		if(atoi(date.c_str()) - atoi(strNow.c_str()) <= 3)
		{
			::_beginthreadex(NULL,0,LicenseMessage,NULL,0,NULL);
		}
		return true;
	}
	else
	{
		CString s;
		s.Format("���ķ�����δע����ѹ��ڣ������������ϵ��\n\n�뽫���»����뷢�͸������̣���ȡע�����ļ���\n\n%s\n\n",strcpuid.GetBuffer());
		MessageBox(NULL, s,"��ʾ",MB_ICONERROR);

		s="�������Ѹ��Ƶ����ļ������У�ֱ��Ctrl+Vճ�������룡";
		MessageBox(NULL, s,"��ʾ",MB_ICONINFORMATION);

		OpenClipboard(NULL);
		EmptyClipboard();
		HANDLE hData=GlobalAlloc(GMEM_MOVEABLE, strcpuid.GetLength()+5); 
		if (hData==NULL)  
		{ 
			CloseClipboard(); 
			return TRUE; 
		}
		LPTSTR szMemName=(LPTSTR)GlobalLock(hData); 
		lstrcpy(szMemName,strcpuid); 
		SetClipboardData(CF_TEXT,hData); 
		GlobalUnlock(hData);  
		GlobalFree(hData); 
		CloseClipboard(); 
		return false;
	}

}

void OutputFun(char* message)
{
	CString msg = message;
	CMainServerDlg* p = (CMainServerDlg*)AfxGetApp()->m_pMainWnd ;
	p->OutputFun(msg);
}

void CMainServerDlg::OutputFun(const CString & message)
{
	m_listSysRunInfo.DisplayMsg(COutputDisplay::Message, message);
}

CMainServerDlg::CMainServerDlg(CWnd* pParent /*=NULL*/)
	:CDialog(IDD_MAINSERVER_DIALOG, pParent),m_TrayIcon(10)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_ListShortNotice.clear();
}

void CMainServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_SYS_RUN_INFO, m_listSysRunInfo);
}

BEGIN_MESSAGE_MAP(CMainServerDlg, CDialog)
	ON_WM_CREATE()////////////
	ON_WM_SIZE()//////////
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_WM_SYSCOMMAND()
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_MESSAGE(IDM_TRAY_NOTIFY_MSG,OnTrayIconNotify)///////////
	ON_BN_CLICKED(IDC_BTNNEWS, &CMainServerDlg::OnBnClickedBtnnews)
	ON_REGISTERED_MESSAGE(WM_CREATETRAYBAR, OnCreateTray)
	ON_WM_TIMER()
END_MESSAGE_MAP()


// ��������
int CMainServerDlg::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
#define APP_TITLEe "MServer"
	
	// ϵͳ�ڲ�����
	if (CDialog::OnCreate(lpCreateStruct) == -1)
	{
		return -1;
	}
	//if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,CRect(0,0,0,0),this,AFX_IDW_PANE_FIRST,NULL))	return -1;

	if(!checkLicense())
	{
		PostQuitMessage(0);
		ExitProcess(0);
		return 0;
	}

	SetTimer(M_TIMER_ID::TIMER_CHECK_LICENCE, 2*60*60*1000, NULL);

	// ����������ͼ��
	HICON hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_TrayIcon.SetNotifyWnd(this, IDM_TRAY_NOTIFY_MSG);
	m_TrayIcon.SetIcon(hIcon, APP_TITLEe);
	
	//m_TrayIcon.ShowBalloonTip("��������MainServer������ϵͳ�����Ժ�...   ",APP_TITLEe);
	SetIcon(hIcon, FALSE);
	DestroyIcon(hIcon);

	m_TrayIcon.ShowBalloonTip("����������ϵͳ�ɹ�", APP_TITLEe);
	ShowWindow(SW_SHOW);
	CenterWindow();
	return 0;
}
//������ͼ����Ϣ
LRESULT CMainServerDlg::OnTrayIconNotify(WPARAM wID, LPARAM lEvent)
{
	switch (lEvent)
	{
	// ˫���¼�
	case WM_LBUTTONDBLCLK:
		{
			ShowWindow(SW_SHOW);
			//PostQuitMessage(0);
			return 1;
		}
	}
	return 0;
}
// λ����Ϣ
void CMainServerDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialog::OnSize(nType, cx, cy);
	if (nType == SIZE_MINIMIZED)
	{
		ShowWindow(SW_HIDE);
	}
}

// CCenterServerDlg ��Ϣ��������

BOOL CMainServerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	// ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��
	
	SetTimer(M_TIMER_ID::TIMER_HIDE_WINDOW, 2000, NULL);

	ManageInfoStruct Init;
	memset(&Init, 0, sizeof(Init));
	
	// ��ʼ������
	if (!m_GameLogon.InitService(&Init))
	{
		OutputFun("��ʼ��������ʧ�ܣ�");
		AfxMessageBox("InitService Error !");
		return false;
	}
	
	// ��������
	UINT	errCode;
	if (!m_GameLogon.StartService(errCode))
	{
		CString stip;
		stip.Format("Start Service Failed ,Error Code:%X",errCode);
		OutputFun(stip);
		AfxMessageBox(stip);
		return false;
	}

	// ���ӷ�ֹ�˻�ͬʱ��½
	::Sleep(2000);
	bool bres=m_GameLogon.m_LogonManage.m_SQLDataManage.m_pEngineSink->setStoredProc("SP_ClearLoginRecord",true);
	if(0!=bres)
	{
		return 0;
	}

	m_GameLogon.m_LogonManage.m_SQLDataManage.m_pEngineSink->addInputParameter("@ZID",m_GameLogon.m_LogonManage.m_ID);
	if(0 != m_GameLogon.m_LogonManage.m_SQLDataManage.m_pEngineSink->execStoredProc())
	{
		m_GameLogon.m_LogonManage.m_SQLDataManage.m_pEngineSink->closeRecord();
		return 0;
	}
	m_GameLogon.m_LogonManage.m_SQLDataManage.m_pEngineSink->closeRecord();

	CString s;
	s.Format("MServer�����ɹ� ֧���������:%d Port:%d   Spe:110 Tec:29001  ��ͨ����  �������� ",
		m_GameLogon.m_LogonManage.m_uMaxPeople,m_GameLogon.m_LogonManage.m_nPort );

	OutputFun(s);
	
	CString scaption;
	GetWindowText(s);
	scaption.Format("%s v%d.%d.%d %s",s,VER_MAIN,VER_MIDDLE,VER_RESVERSE,VER_BUILDTIME);
	SetWindowText(scaption);

	return TRUE;  // ���������˿ؼ��Ľ��㣬���򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
// �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
// �⽫�ɿ���Զ���ɡ�
void CMainServerDlg::OnPaint() 
{
	if (IsIconic())
	{
		// ���ڻ��Ƶ��豸������
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{	
		// ���ڻ��Ƶ��豸������
		CPaintDC dc(this); 

		// ͸����, ��Ȼ��, �����ı�����ɫ
		dc.SetBkMode(TRANSPARENT);

		// ��ɫ
		dc.SetTextColor(RGB(255, 255, 255));
		dc.DrawText(TMLcopyright,lstrlen(TMLcopyright),CRect(2,457,720,836),DT_TOP|DT_RIGHT|DT_NOCLIP|DT_SINGLELINE);
		
		// ��ɫ
		dc.SetTextColor(RGB(200, 200, 200));
		dc.DrawText(TMLcopyright,lstrlen(TMLcopyright),CRect(1,456,720,836),DT_TOP|DT_RIGHT|DT_NOCLIP|DT_SINGLELINE);
		
		// ��ɫ
		dc.SetTextColor(RGB(0, 0, 0));
		dc.DrawText(TMLcopyright,lstrlen(TMLcopyright),CRect(0,455,720,836),DT_TOP|DT_RIGHT|DT_NOCLIP|DT_SINGLELINE);
		CDialog::OnPaint();
	}
}

// ���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ
HCURSOR CMainServerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMainServerDlg::OnDestroy()
{
	m_GameLogon.UnInitService();
	CDialog::OnDestroy();

	// TODO: �ڴ�������Ϣ�����������
}

void CMainServerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

	switch(nID)
	{
	case SC_CLOSE:
		//		server.Stop();
		KillTimer(M_TIMER_ID::TIMER_HIDE_WINDOW);
		CDialog::OnSysCommand(nID, lParam);
		return;
	}

	CDialog::OnSysCommand(nID, lParam);
}

void CMainServerDlg::OnBnClickedOk()
{
	//	server.Stop();
	KillTimer(M_TIMER_ID::TIMER_HIDE_WINDOW);
	OnOK();
}


void CMainServerDlg::OnBnClickedBtnnews()
{
	DWORD cfgHandle=cfgOpenFile("ShortNotice.bcf");

	int iOnOff = cfgGetValue(cfgHandle,"ShortNotice","OnOff", 0);
	int inum   = cfgGetValue(cfgHandle,"ShortNotice","num", 0);
	if (iOnOff == 1 && inum > 0)
	{	
		TCHAR str[MAX_PATH];
		m_ListShortNotice.empty();
		for (int i = 0; i < inum; ++i)
		{
			wsprintf(str, "News%d", i+1);
			CString msg = cfgGetValue(cfgHandle,"ShortNotice",str,"");

			if (msg.IsEmpty())
			{
				continue;
			}
			m_ListShortNotice.push_back(msg);
		}

		KillTimer(M_TIMER_ID::TIMER_CHECK_MESSAGE);
		SetTimer(M_TIMER_ID::TIMER_CHECK_MESSAGE, 2000, NULL);

		cfgClose(cfgHandle);
	}
}

LRESULT CMainServerDlg::OnCreateTray(WPARAM wp, LPARAM lp)
{
#define APP_TITLE "������MainServer"
	m_TrayIcon.SetIcon(AfxGetApp()->LoadIcon(IDR_MAINFRAME),APP_TITLE,TRUE);
	return 0;
}

void CMainServerDlg::OnTimer(UINT_PTR nIDEvent)
{
	switch (nIDEvent)
	{
	case M_TIMER_ID::TIMER_HIDE_WINDOW:
		{
			KillTimer(M_TIMER_ID::TIMER_HIDE_WINDOW);
			this->ShowWindow(SW_HIDE);
		}
		break;
	case M_TIMER_ID::TIMER_CHECK_MESSAGE:
		{
			if(!m_ListShortNotice.empty())
			{
				MSG_GR_RS_NormalTalk news;
				ZeroMemory(&news,sizeof(MSG_GR_RS_NormalTalk));
				wsprintf(news.szMessage, "%s", m_ListShortNotice.front());
				news.iLength = m_ListShortNotice.front().GetLength() + 1;
				
				// �������ʾ����
				m_ListShortNotice.pop_front();
				m_GameLogon.m_LogonManage.m_TCPSocket.SendDataBatch(&news, sizeof(MSG_GR_RS_NormalTalk) - sizeof(news.szMessage) + news.iLength + 1, MDM_GP_MESSAGE, ASS_GP_NEWS_SYSMSG, 0);
			}
			else
			{
				KillTimer(M_TIMER_ID::TIMER_CHECK_MESSAGE);
			}
		}
		break;
	case M_TIMER_ID::TIMER_CHECK_LICENCE:
		if(!checkLicense())
		{
			KillTimer(3);
			PostQuitMessage(0);
			ExitProcess(0);
			break;
		}
	default:
		;
	}

	CDialog::OnTimer(nIDEvent);
}
