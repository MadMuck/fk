//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Auto_AI.rc
//
#define IDD_AUTO_AI_DIALOG              102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_GAME_ROOM                   129
#define IDD_GAME_FRAME                  131
#define IDD_DIALOG_TASKLIST             134
#define IDD_DIALOG_TASK_EDIT            135
#define IDD_DIALOG_MSGINFO              136
#define IDC_EDIT_STATIC                 1068
#define IDC_STATIC_LOGINCOUNT           1069
#define IDC_EDIT_LOGINCOUNT             1070
#define IDC_STATIC_HEADNAME             1071
#define IDC_EDIT_HEADNAME               1072
#define IDC_STATIC_BEGINNO              1073
#define IDC_EDIT_BEGINNO                1074
#define IDC_STATIC_CHECKOUT             1075
#define IDC_EDIT_CHECKOUT               1076
#define IDC_STATIC_CHECKIN              1077
#define IDC_EDIT_CHECKIN                1078
#define IDC_STATIC_ONDESKROBOTNO        1079
#define IDC_EDIT_ONEDESKROBOTNO         1080
#define IDC_CHECK_ALLOWROBOTWITHPLAYER  1083
#define IDC_BUTTON_LOGIN                1084
#define IDC_BUTTON_CANCEL               1085
#define IDC_BUTTON_MIN                  1086
#define IDC_BUTTON_CLOSE                1087
#define IDC_BUTTON_SAVE                 1088
#define IDC_BUTTON_RESET                1089
#define IDC_STATIC_MSERVERINFO          1090
#define IDC_EDIT_MSERVERINFO            1091
#define IDC_EDIT_ROOMMSg                1098
#define IDC_EDIT_MSGINFO                1098
#define IDC_EDIT_KEEPINDESK             1099
#define IDC_STATIC_KEEPINDESK           1100
#define IDC_STATIC_GAMEENDLEAVE         1101
#define IDC_EDIT_GAMEENDLEAVE           1102
#define IDC_BUTTON_STATUS               1103
#define IDC_STATIC_ROOMNAME             1107
#define IDC_STATIC_TIP                  1107
#define IDC_STATIC_ROOM                 1108
#define IDC_STATIC_TIMEFISHGAME         1109
#define IDC_EDIT_TIMEFISHGAME           1110
#define IDC_STATIC_TASKINFO             1111
#define IDC_BUTTON_TASKLIST             1114
#define IDC_LIST_TASKLIST               1115
#define IDC_COMBO_HOUR                  1117
#define IDC_STATIC_HOUR                 1118
#define IDC_STATIC_MINITUE              1119
#define IDC_COMBO_MINUTE                1120
#define IDC_STATIC_LOGONCOUNT           1121
#define IDC_EDIT_CHECKOUT2              1124
#define IDC_STATIC_FISHGAMELEAVE        1126
#define IDC_EDIT_FISHGAMELEAVE          1127
#define IDC_STATIC_WAITTIME             1128
#define IDC_EDIT_WAITTIME               1129
#define IDC_STATIC_AINUMBER             1130
#define IDC_EDIT_AINUMBER               1131
#define IDC_CHECK_ALLOWWITHPLAYER       1132
#define IDC_BUTTON_ADDTASK              1134
#define IDC_BUTTON_DELTASK              1135
#define IDC_BUTTON_MODTASK              1136
#define IDC_EDIT_CHECKIN2               1137
#define IDC_BUTTON_HALLINFO             1138
#define IDC_BUTTON_ROOMINFO             1139
#define IDC_CHECK_ERRORINFO             1140
#define IDC_CHECK_STOPUPDATEINFO        1141
#define IDC_LIST_STATUS                 1142
#define IDC_CHECK_STOPSTATUS            1143
#define IDC_STATIC_LOGINSTATUS          1144
#define IDC_EDIT_CHECKBEGINNO           1145
#define IDC_EDIT_CHECKENDNO             1146
#define IDC_BUTTON1                     1147
#define IDC_STATIC_TILEHEAD             -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1148
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
